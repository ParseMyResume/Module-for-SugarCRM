<?php
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2009 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

$manifest = array (
		  'acceptable_sugar_versions' =>   array (),
		  'acceptable_sugar_flavors' =>   array('CE', 'PRO','ENT'),
		  'readme'=>'Parse My Resume CE 6.5 for SugarCRM Community Edition 6.5. Please visit our website at www.ParseMyResume.com for updated news and information regarding Parse My Resume.',
		  'key'=>'Parse My Resume',
		  'author' => 'ParseMyResume',
		  'description' => 'Parse My Resume Module to Upload Resume and extracted details and direclty store to Leads.',
		  'icon' => '',
		  'is_uninstallable' => true,
		  'name' => 'ParseMyResume',
		  'published_date' => '2012-11-30 16:37:00',
		  'type' => 'module',
		  'version' => '1.1 ',
		  'remove_tables' => 'prompt',
 );
		  
$installdefs = array (
  'id' => 'ParseMyResume',
    'pre_execute'=>array(
        0 => '<basepath>/actions/pre_install_actions.php',
    ),
    'post_execute'=>array(
        0 => '<basepath>/actions/post_install_actions.php',
    ),
    'pre_uninstall'=>array(
        0 => '<basepath>/actions/pre_uninstall_actions.php',
    ),
    'post_uninstall'=>array(
        0 => '<basepath>/actions/post_uninstall_actions.php',
    ),
	'pre_execute'=>array(
		0 => '<basepath>/script/pre_execute.php',
	),
	'post_uninstall' => array(
		0=>'<basepath>/script/post_uninstall.php',
	 ),
  

	
    'language'=> array(
        array(
			'from'=> '<basepath>/language/application.fr_FR.php',
			'to_module'=> 'application',
			'language'=>'fr_FR'
		),
		array(
			'from'=> '<basepath>/language/application.en_us.php',
			'to_module'=> 'application',
			'language'=>'en_us'
		),
		array(
			'from'=> '<basepath>/language/application.es_es.php',
			'to_module'=> 'application',
			'language'=>'es_es'
		),
		array(
			'from'=> '<basepath>/language/editcustomfields.fr_FR.php',
			'to_module'=> 'EditCustomFields',
			'language'=>'fr_FR'
		),
		array(
			'from'=> '<basepath>/language/editcustomfields.en_us.php',
			'to_module'=> 'EditCustomFields',
			'language'=>'en_us'
		),
		array(
			'from'=> '<basepath>/language/editcustomfields.es_es.php',
			'to_module'=> 'EditCustomFields',
			'language'=>'es_es'
		),
		array(
			'from'=> '<basepath>/language/modulebuilder.fr_FR.php',
			'to_module'=> 'ModuleBuilder',
			'language'=>'fr_FR'
		),
		array(
			'from'=> '<basepath>/language/modulebuilder.en_us.php',
			'to_module'=> 'ModuleBuilder',
			'language'=>'en_us'
		),
		array(
			'from'=> '<basepath>/language/modulebuilder.en_us.php',
			'to_module'=> 'ModuleBuilder',
			'language'=>'en_us'
		),
		array(
          'from'=> '<basepath>/language/administration.fr_FR.php',
          'to_module'=> 'Administration',
          'language'=>'fr_FR'
        ),
        array(
          'from'=> '<basepath>/language/administration.es_es.php',
          'to_module'=> 'Administration',
          'language'=>'es_es'
        ),
        
        array(
          'from'=> '<basepath>/language/administration.en_us.php',
          'to_module'=> 'Administration',
          'language'=>'en_us'
        ),
		array (
		  'from' => '<basepath>/application/app_strings.php',
		  'to_module' => 'application',
		  'language' => 'en_us',
		),
	   array (
		  'from' => '<basepath>/Schedulers/custom.lang.php',
		  'to_module' => 'Schedulers',
		  'language' => 'en_us',
		),
	   array (
		  'from' => '<basepath>/modules/ParseMyResume/language/en_us.lang.php',
		  'to_module' => 'ParseMyResume',
		  'language' => 'en_us',
		),
    ),

 
    'copy' => array(
		array (
			'from' => '<basepath>/modules/ParseMyResume/',
			'to' => 'modules/ParseMyResume',
		 ),
	    array (
		'from' => '<basepath>/Schedulers/_AddJobsHere.php',
		'to' => 'custom/modules/Schedulers/_AddJobsHere.php',
	    ),
        array('from'=> '<basepath>/new_files/icons/offshore.gif',
              'to'=> 'themes/default/images/offshore.gif',
        ),
        array('from'=> '<basepath>/new_files/custom/OffshorePhoto/OffshorePhoto.php',
              'to'=> 'custom/OffshorePhoto/OffshorePhoto.php',
        ),
        array('from'=> '<basepath>/new_files/custom/OffshorePhoto/phpThumb/',
              'to'=> 'custom/OffshorePhoto/phpThumb/',
        ),
        array('from'=> '<basepath>/new_files/include/SugarFields/Fields/Photo/',
              'to'=> 'include/SugarFields/Fields/Photo/',
        ),
        array('from'=> '<basepath>/new_files/modules/DynamicFields/templates/Fields/TemplatePhoto.php',
              'to'=> 'modules/DynamicFields/templates/Fields/TemplatePhoto.php',
        ),
        array('from'=> '<basepath>/new_files/modules/DynamicFields/templates/Fields/Forms/photo.php',
              'to'=> 'modules/DynamicFields/templates/Fields/Forms/photo.php',
        ),
        array('from'=> '<basepath>/new_files/modules/DynamicFields/templates/Fields/Forms/photo.tpl',
              'to'=> 'modules/DynamicFields/templates/Fields/Forms/photo.tpl',
        ),
        array('from'=> '<basepath>/new_files/custom/include/MVC/View/views/view.list.php',
              'to'=> 'custom/include/MVC/View/views/view.list.php',
        ),
        array('from'=> '<basepath>/new_files/custom/OffshorePhoto/include/ListView/ListViewGeneric.tpl',
              'to'=> 'custom/OffshorePhoto/include/ListView/ListViewGeneric.tpl',
        ),
        array('from'=> '<basepath>/new_files/include/generic/SugarWidgets/SugarWidgetSubPanelDetailViewOffshorePhoto.php',
              'to'=> 'include/generic/SugarWidgets/SugarWidgetSubPanelDetailViewOffshorePhoto.php',
        ),
      
        
    ),
    
    'administration'=> array(
        array(
            'from'=>'<basepath>/administration/offshorephoto_options.php',
        ),
    ),
  
	 'beans' => 
	  array (
		0 => 
		array (
		  'module' => 'ParseMyResume',
		  'class' => 'ParseMyResume',
		  'path' => 'modules/ParseMyResume/ParseMyResume.php',
		  'tab' => true,
		),
  ),

  
);