<?php
$app_list_strings['moduleList']['ParseMyResume'] = 'Parse My Resume';
?>