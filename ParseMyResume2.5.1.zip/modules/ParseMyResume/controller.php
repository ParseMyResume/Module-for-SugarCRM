<?php
/*********************************************************************************
 * ParseMyResume is helping SugarCRM customers to insert Resumes into ATS. 
 * ParseMyResume Copyright (C) 2011  - 2013 ParseMyResume.
 * 
 * This program is free/Subscription based  software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY ParseMyResume, ParseMyResume DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact ParseMyResume. headquarters at Suite 13, C-134, Phase 8
 * Industrial Area, Mohali, Punjab, 160062 India. or at email address support@parsemyresume.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 ********************************************************************************/
class ParseMyResumeController extends SugarController{
	function ParseMyResumeController(){
		parent::SugarController();
	}
		
	function action_editviewss()
	{
	
		if(is_admin($GLOBALS['current_user']) || $_REQUEST['record'] == $GLOBALS['current_user']->id) 
			$this->view = 'edit';
		else
			sugar_die("Unauthorized access to employees.");
		return true;
	}
	function action_editview()
	{
	}
	
	function action_lead()
	{
		include "modules/ParseMyResume/class.recruiter.php";	
		include "modules/ParseMyResume/leadstore.php";
		include "modules/ParseMyResume/class.ParseMyResume.php";
		require_once('data/SugarBean.php');
		
		$thisSugarBean = new SugarBean();
		$key = $_REQUEST['resumeCountry'];
		$query2="UPDATE `ParseMyResume_info` set countrykey='{$key}' where id=1";
		$filename = $_FILES["resumecontent"]["name"];
		$source = $_FILES["resumecontent"]["tmp_name"];
		$run_query2=$thisSugarBean->db->query($query2,true);
		$type=explode(".",$_FILES['resumecontent']['name']);
		if($type[1]=="zip")
		{
			if(isset($_POST['filesubmitted']))
			{
				echo $dir = "modules/ParseMyResume/data/".$filename;		
				move_uploaded_file($source,$dir);
				$dir2="modules/ParseMyResume/data";
				$handle = opendir($dir2);
				SugarApplication::redirect("index.php?module=ParseMyResume&action=zipMsg");
			}
		}
		else
		{
				if(isset($_POST['filesubmitted'])) 
				{	 
					include "modules/ParseMyResume/singleLead.php";
					$upload_result='';		
					$upload= new Recruiter();
					$upload_result = $upload->SaveUplodedFile(); 
					$id=savelead($upload_result);
					
					//exit;
					if(is_array($id))
					{
					 
							$id=$id['id'].",".$id['linkID'];
							SugarApplication::redirect("index.php?module=ParseMyResume&action=errorMsg&errorcode=".$id);
						
					}
					else if($id==1001 || $id==1002 || $id==1003 || $id==1005 || $id==1010 || $id==1015 || $id==1000 || $id==112)
					{
						SugarApplication::redirect("index.php?module=ParseMyResume&action=errorMsg&errorcode=".$id);
					}
					else if(empty($id))
					{
						$id=000;
						SugarApplication::redirect("index.php?module=ParseMyResume&action=errorMsg&errorcode=".$id);
					}
					else
					{
						
						SugarApplication::redirect("index.php?module=Leads&offset=1&stamp=1352983420026423300&return_module=Leads&action=DetailView&record=".$id);
					}
				}	
		}
	//exit(); 
	}
	function action_fieldMapping(){
		$this->view='fieldMapping';
	} 
	function action_semi_AdministerMetadata() {
		$this->view = 'semi_administermetadata';
	}
	function action_semi_aboutus() 
	{
	  
	}
	function action_emailIntegration()
	{
	}
		
		
	function action_uploadResume()	
	{
	}
	function action_mappingData()	
	{
		require_once('data/SugarBean.php');
		$thisSugarBean = new SugarBean();
		$lead_struct="DESCRIBE leads"; 
		$lead_result=$thisSugarBean->db->query($lead_struct,true);
		$row = $lead_result->fetch_assoc(); 

		 while($row2 = $lead_result->fetch_assoc())
		  {
			if($row2['Field']=="first_name" || $row2['Field']=="last_name" || $row2['Field']=="status")
			{
			}
			else
			{
			$leaddata[]=$row2['Field'];
			$lead_datatype[]=$row2['Type'];
			}
		
		  }
		$lead_custm_struct="DESCRIBE leads_cstm"; 
		$lead_custm_struct_result=$thisSugarBean->db->query($lead_custm_struct,true);
		$rowResult = $lead_custm_struct_result->fetch_assoc(); 
		$countElement=count($leaddata); 
		 while($rowResult = $lead_custm_struct_result->fetch_assoc())
		  {
			$lead_custmdata[$countElement]=$rowResult['Field'];
			$lead_custm_datatype[$countElement]=$rowResult['Type'];
			$countElement++;
		  }
		 
			foreach($_POST as $key=>$value)
			{
				if($value== 'on')
				{	
				
					$name="ctl04_".$key;
					foreach($_POST as $key2=>$value1)
					{
						 if($key2==$name)
						{
							if($value1!="Select")
							{
								$ParseMyResume_field=$key;
								if(isset($leaddata[$value1]))
								{
								$sugarField=$leaddata[$value1];
								$sugarFieldSize=$lead_datatype[$value1];
								}
								else if(isset($lead_custmdata[$value1]))
								{
								$sugarField=$lead_custmdata[$value1];
								$sugarFieldSize=$lead_custm_datatype[$value1];
								}
								if($ParseMyResume_field=="Email" || $ParseMyResume_field=="FirstName" || $ParseMyResume_field=="LastName")
								{
									$filed[]=$ParseMyResume_field;
								}
								else
								{
								
								$filed[]=$ParseMyResume_field;
							
							$qry1 = "SELECT ParseMyResume_field
		FROM `ParseMyResume_field_mapping` where ParseMyResume_field = '{$ParseMyResume_field}'";	
							$run_query1=$thisSugarBean->db->query($qry1,true);
						   $res=$run_query1->fetch_assoc();
							 $key=$res['ParseMyResume_field'];
							if($key=='')
							{
							  $qry2 = "insert into ParseMyResume_field_mapping( ParseMyResume_field) values ('{$ParseMyResume_field}')";
							  $runQuery=$thisSugarBean->db->query($qry2,true); 
							}
								$query="update `ParseMyResume_field_mapping` set sugar_field='{$sugarField}',sugar_field_size='{$sugarFieldSize}' where ParseMyResume_field='{$ParseMyResume_field}'";
								$runQuery=$thisSugarBean->db->query($query,true); 
								//echo $query;
								//echo "<hr>";
								//exit();
								}
							}
							
						}
					}
				}
				
			}
			$string="";
			foreach($filed as $value)
			{
				$string.="ParseMyResume_field!='".$value."' AND ";
			}
			$string=rtrim($string," AND ");
			$query="update `ParseMyResume_field_mapping` set sugar_field=' ',sugar_field_size=' ' where {$string};";
			$runQuery=$thisSugarBean->db->query($query,true); 			
			$mapping="update `ParseMyResume_info` set map_field='1'";
			$thisSugarBean->db->query($mapping,true); 
			echo "<table cellpadding=3 cellsapcing=3><tr><td><img src=\"modules/ParseMyResume/images/ticck.jpg\" height=30 width=30></td><td><font color=\'black\'><b>Successfully Done Field Mapping.....</b></td></tr></table>";
			exit();
		
	}
	
	function action_userkey()
	{
	
		require_once('data/SugarBean.php');
		$thisSugarBean = new SugarBean();
		$query1="select * from ParseMyResume_info";
		$run_query1=$thisSugarBean->db->query($query1,true);
		$res=$run_query1->fetch_assoc();
		if(empty($res['userkey']))
		{
			$url=$_POST['src'];
			$string=file_get_contents($url);
			$data=urldecode($string);
			$pos = strrpos($data, "ctl00_hdnSugar");
			if(!empty($pos))
				{
					$userKey = substr($data,$pos+23,11);
					$query2="UPDATE `ParseMyResume_info` set userkey='{$userKey}' where id=1";
					$run_query2=$thisSugarBean->db->query($query2,true);	
				}
		}
	
	}
	function action_parsing()
	{
	$this->view='parsing';
	}
	function action_mailData()
	{
		foreach($_POST as $key=>$value)
		{
			if($value=="on")
			{
				$ssl=$key;
			}
		} 
		$host=$_POST['host'];
		$password=$_POST['password'];
		$user=$_POST['email'];
		$port=$_POST['port'];
		$map=$_POST['map'];
		require_once('data/SugarBean.php');
		$thisSugarBean = new SugarBean();
		$query="UPDATE `ParseMyResume_info` set email='{$user}',host='{$host}',port='{$port}',map='{$map}',`ssl`='{$ssl}',password='{$password}' where id=1";
		$run_query1=$thisSugarBean->db->query($query,true);
		$query1="select * from ParseMyResume_info";
		$run_query2=$thisSugarBean->db->query($query1,true);
		$res=$run_query2->fetch_assoc();
		$password=$res['password'];
		$user=$res['email'];
		$port=$res['port'];
		$map=$res['map']; 
		if(!empty($res['ssl']))
		{
			$ssl=$res['ssl'];
			$host="{".$res['host'].":".$port."/".$map."/".$ssl."/novalidate-cert}INBOX";
		}
		else
		{
			//$host="{box797.bluehost.com:993/imap}INBOX";
			$host="{".$res['host'].":".$port."/".$map."/novalidate-cert}INBOX";
		}
			//echo $host; 
			
		include('modules/ParseMyResume/class.reader.php');
		$mbox = new AReader($host, $user, $password);
		//print_r($mbox);
		//exit();
		if (!$mbox->Connect()) 
			{
				echo ("Can't connect: " . imap_last_error() ."\n");
				//die('Unable to establish connection with mailbox');
				echo "<table cellpadding=3 cellsapcing=3><tr><td><img src=\"modules/ParseMyResume/images/cross.jpg\" height=20 width=20></td><td>".$user."</td></tr><tr><td colspan=2><b> Unable to establish connection with mailbox . Kindly Provide Valid Credentials </b></td></tr></table>";
				exit();
			}
		else
			{
				echo " <table cellpadding=10 cellsapcing=10><tr><td><img src=\"modules/ParseMyResume/images/ticck.jpg\" height=30 width=30></td><td>".$user."</td></tr><tr><td><b>Connection Done</b></td><td></td></tr><tr>*Note : Set ParseMyResume_Mailbox_Parsing Cron Job. <a href=\"index.php?module=Schedulers&action=EditView\">Click Here</a></td><td></td> </tr></table>";
				exit();
			}
		//SugarApplication::redirect("index.php?module=ParseMyResume&action=uploadResume");
	
	}
	function action_zipMsg()
	{
	
	}
	function action_errorMsg()
	{
	
	}
	function action_help()
	{
	}
	function action_helpmail()
	{ 
	$subject="Sugar Crm Error";
	$message=" Dear ParseMyResume Team \n  I am ".$_POST['uname'].". My Email Id is".$_POST['uemail']."<br> USERKEY:".$_POST['userkey'].".<br>Problem:".$_POST['msg']." <br>My Sugar Crm PHP info given below.<br>";
	$headers  = 'MIME-Version: 1.0' . "\r\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	// Additional headers
	$headers .= 'To: mail2anjalikashyap@gmail.com . "\r\n"';
	$headers .= 'From:anjalikashyap14484@gmail.com' . "\r\n";
	// Mail it
	mail('mail2anjalikashyap@gmail.com', $subject, $message, $headers);
	echo "<table border=2 style=\"border-color:'red';border-style:'solid';\"><tr>
	 <td><h3><font color='green'>Thanks for Contact. Support will connect with you with in 24 hours</td></tr></table>";
	}
	protected function action_delete()
	{
		if($_REQUEST['record'] != $GLOBALS['current_user']->id && $GLOBALS['current_user']->isAdminForModule('Users'))
		{
			$u = new User();
			$u->retrieve($_REQUEST['record']);
			$u->deleted = 1;
			$u->status = 'Inactive';
			$u->employee_status = 'Terminated';
			$u->save();
			$GLOBALS['log']->info("User id: {$GLOBALS['current_user']->id} deleted user record: {$_REQUEST['record']}");

			
				SugarApplication::redirect("index.php?module=Employees&action=index");
		}
		else 
			sugar_die("Unauthorized access to administration.");
	}
	
}
?>