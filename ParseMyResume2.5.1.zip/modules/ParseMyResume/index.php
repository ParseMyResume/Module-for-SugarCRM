<script src="http://sugarcrm.rchilli.com/js/jquery.js"></script> 
<script language="javascript">
function getContentFromIframe(obj)
{
    $.ajax({
	 type:"POST",
	 url:"index.php?module=ParseMyResume&action=userkey",
	 data:{src:obj.src},
	 success:function(data)
	 {
		//alert(data);
	 }
	});
    //Do whatever you need with the content    

}
</script>

<body onLoad="getContentFromIframe(document.getElementById('myframe'))">
<?php 

		require_once('data/SugarBean.php');
		$thisSugarBean = new SugarBean();
		$query1="select * from ParseMyResume_info";
		$run_query1=$thisSugarBean->db->query($query1,true);
		$res=$run_query1->fetch_assoc();
		
		if(!empty($res['macid']))
		{
			$searchArray = array(":", "-");
			$replaceArray = array("", "");
			$macid = str_replace($searchArray ,$replaceArray,$res['macid']);
			$section=file_get_contents("http://sugarcrm.rchilli.com/testRchilliEnCrypt_131348phase.aspx?q=".$macid) ;
			
			$data=urldecode($section);
			$pos = strrpos($data, "Hiddenfield1");
			//echo $pos;
		
			if(!empty($pos))
				{
					$id = substr($data,$pos+13);
					$macid=explode("\"",$id);
					//echo $macid[1]; 
					$signpos = strrpos($data, "hfValid");
					$signpos = substr($data,$signpos+12);
					$signpos=explode("\"",$signpos);
					$signup=$signpos[1];
				
						if($signup=="true" || $signup=="TRUE" || $signup=="True")
						{
							$fnamepos = strrpos($data, "hfName");
							$fnamepos = substr($data,$fnamepos+12);
							$fnamepos=explode("\"",$fnamepos);
							$fname=$fnamepos[1];
							$fEmailpos = strrpos($data, "hfEmail");
							$fEmailpos = substr($data,$fEmailpos+12);
							$fEmailpos =explode("\"",$fEmailpos);
							$Email=$fEmailpos[1];
							$fUserKeypos = strrpos($data, "hfUserKey");
							$fUserKeypos = substr($data,$fUserKeypos+12);
							$fUserKeypos =explode("\"",$fUserKeypos);
							$UserKey=$fUserKeypos[1];
							$fPlanTypepos = strrpos($data, "hfPlanType");
							$fPlanTypepos = substr($data,$fPlanTypepos+12);
							$fPlanTypepos =explode("\"",$fPlanTypepos);
							$PlanType=$fPlanTypepos[1];
							$fDateOfExpiry = strrpos($data, "hfDateOfExpiry");
							$fDateOfExpiry = substr($data,$fDateOfExpiry+18);
							$fDateOfExpiry =explode("\"",$fDateOfExpiry);
							$DateOfExpiry=$fDateOfExpiry[1];
							$creditpos = strrpos($data,"hfCredit");
							$creditpos = substr($data,$creditpos+12);
							$creditpos =explode("\"",$creditpos);
							$credit=$creditpos[1];
							$sql="UPDATE `ParseMyResume_info` set userkey='{$UserKey}',username='{$fname}',credits='{$credit}',date_of_expire='{$DateOfExpiry}',planType='{$PlanType}',res_email='{$Email}' where id=1";
							$query2=$thisSugarBean->db->query($sql,true);
							echo "<center><table><tr><td><image src=\"modules/ParseMyResume/images/ParseMyResume.png\"><td height=\"79\"  class=\"bodytxt\" style=\"text-align:right;padding-right:10px\" colspan=\"2\"></td></tr>
							<tr><td align=\"left\">
							<span style=\"color:#C12126;font-size:Large;font-weight:bold;\" class=\"links\" id=\"ctl00_topnav_WelcomAndCurrentPlan1_lblwelecome\">Welcome </span><span style=\"color:#C12126;font-size:Large;font-weight:bold;\" class=\"links\" id=\"ctl00_topnav_WelcomAndCurrentPlan1_lblPersonname\">".$fname."</span>
&nbsp;&nbsp;&nbsp;<span id=\"ctl00_topnav_WelcomAndCurrentPlan1_lblMsg\"></span></td></tr>
<tr><td>
<div style=\"color: #c12126;font-size:Large;\" id=\"ctl00_topnav_WelcomAndCurrentPlan1_dtrial\"><br><b>Current Plan: </b>".rtrim($PlanType)."<b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Pending Credits:</b>".$credit."<b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Expiry Date: </b>".$DateOfExpiry."</div>

            </td></tr><tr><td align=\"left\"><br><span style=\"font-size:Large;font-weight:bold;\"> To Recharge your Account click <a target=\"_blank\" href=\"http://sugarcrm.rchilli.com/Registration.aspx?q=".urlencode($macid[1])."\">here</span></a></td></tr>";
						}
						else
						{
							echo 
								"<center>
									<img src=\"modules/ParseMyResume/images/ParseMyResume.png\"><br><br>
									
									<font Size=\"4\" face=\"comic sans ms\">You are not Registered yet.<br> To Register Please 
									<a target=\"_blank\" href=\"http://sugarcrm.rchilli.com/Registration.aspx?q=".urlencode($macid[1])."\">Click Here.</a></font><br><br><br>
								<font Size=\"2\" color=\"red\">*After Registration Please Reload the page.</font></center>";
						}
		
					
				}
		}
		
/* 	echo "<center><Iframe id=\"myframe\" src=\"http://sugarcrm.ParseMyResume.com/Registration.aspx?q=".urlencode($macid[1])."\" width=\"1024\" height=\"720\" onLoad=\"getContentFromIframe(document.getElementById('myframe'))\"></Iframe></center>";
	echo "<center><image src=\"modules/ParseMyResume/images/logo.gif\"></center>"; */
	?>
	</body>