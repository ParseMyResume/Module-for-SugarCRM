<?php
/*********************************************************************************
 * ParseMyResume is helping SugarCRM customers to insert Resumes into ATS. 
 * ParseMyResume Copyright (C) 2011  - 2013 ParseMyResume.
 * 
 * This program is free/Subscription based  software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY ParseMyResume, ParseMyResume DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact ParseMyResume. headquarters at Suite 13, C-134, Phase 8
 * Industrial Area, Mohali, Punjab, 160062 India. or at email address support@parsemyresume.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 ********************************************************************************/
function save($upload_result, $file_name)
{
 
		if(isset($upload_result['errorcode']))
		{
			return $upload_result['errorcode'];
		}
		else if(empty($upload_result['Email']))
		{

			return 112; //Email id blank  Error Code 112
		}
		else
		{
			 require_once('data/SugarBean.php');
			 $thisSugarBean = new SugarBean();
			 $emailAdd=$upload_result['Email'];
			 if(!empty($emailAdd))
			 {
				 $emailAddress="select * from email_addresses where email_address='{$emailAdd}';";
				 $result=$thisSugarBean->db->query($emailAddress,true);
				 $Result =$result->fetch_row();
				 if(empty($Result))
				 {
						 $uuidQuery="select UUID()";
							 $uuid=$thisSugarBean->db->query($uuidQuery,true);
							 $uuidResult = $uuid->fetch_row(); 
							 $id=$uuidResult[0];
							 $date=date("Y-m-d H:i:s");
							 $sugarQuery="select * from ParseMyResume_field_mapping";
							 $sugarRes=$thisSugarBean->db->query($sugarQuery,true);
							 $queryUpdate = "INSERT INTO `leads` (`id`,`date_entered`, `date_modified`,";
								
								while ($sugar = $sugarRes->fetch_assoc())
									{
									    if(strlen(trim($sugar['sugar_field'])) >0)
										 {
												$str=strlen($sugar['sugar_field']);
												$customfiled=substr($sugar['sugar_field'],$str-2,2);
												$customfiled=strstr($customfiled,"_c");
												if(empty($customfiled))
												{
													 $ParseMyResumeData[]=$sugar['ParseMyResume_field'];
													 $varchar=strstr($sugar['sugar_field_size'],"varchar");
													 $char=strstr($sugar['sugar_field_size'],"char");
													 $dateType=strstr($sugar['sugar_field_size'],"date");
													//echo $pos;
													if(!empty($varchar))
													{
														$size=explode("(",$varchar);
														$ParseMyResumeDataSize[$sugar['ParseMyResume_field']]=$size[1];
													}
													else if(!empty($char))
													{
														$size=explode("(",$char);
														$ParseMyResumeDataSize[$sugar['ParseMyResume_field']]=$size[1];	
													}
													else if(!empty($dateType))
													{
														$ParseMyResumeDate[$sugar['ParseMyResume_field']]="date";	
													}
													
																	
												$queryUpdate.="`".$sugar['sugar_field']."`,";
												} 
											}
							
									} 
								
								
										$queryUpdate=rtrim($queryUpdate,",").")VALUES ('{$id}','{$date}','{$date}',";
										$num=count($ParseMyResumeData);
										$sugarQuery2="select * from ParseMyResume_field_mapping";
										$sugarRes2=$thisSugarBean->db->query($sugarQuery2,true);
										for($i=0;$i<$num;$i++)
										{
											foreach($ParseMyResumeDataSize as $key=>$value)
											{
												if($ParseMyResumeData[$i]==$key)
													{
														$upload_result[$ParseMyResumeData[$i]]=substr($upload_result[$ParseMyResumeData[$i]],0,$value); 
													}
											}
											if(!empty($ParseMyResumeDate))
											{
												foreach($ParseMyResumeDate as $field=>$fvalue)
												{	
														if($ParseMyResumeData[$i]==$field)
														{
																$originalDate=explode("/",$upload_result[$ParseMyResumeData[$i]]);
																
																if($originalDate[1]<10)
																{
																	$originalDate[1]="0".$originalDate[1];
																}
																if($originalDate[0]<10)
																{
																	$originalDate[0]="0".$originalDate[0];
																}
																$upload_result[$ParseMyResumeData[$i]]=$originalDate[2].":".$originalDate[1].":".$originalDate[0];
																
														}									
												}
											}
											
											$queryUpdate.="'".$upload_result[$ParseMyResumeData[$i]]."',";
							
										} 
											$queryUpdate=rtrim($queryUpdate,",").");";
						
											$thisSugarBean->db->query($queryUpdate,true); 
											
							
							/**..............................................Custom Lead Table......................................**/
							$sugarQuery_c="select * from ParseMyResume_field_mapping";
							$sugarRes_c=$thisSugarBean->db->query($sugarQuery_c,true);
							$queryUpdate_c = "INSERT INTO `leads_cstm` (`id_c`,";
							$text_data_len['tinytext'] = '85';
							$text_data_len['text'] = '15845';
							$text_data_len['mediumtext'] = '5592405';
							$text_data_len['longtext'] = '1431655765';
								
								while ($sugar_c = $sugarRes_c->fetch_assoc())
									{
										if(!empty($sugar_c['sugar_field']))
										{
											$str=strlen($sugar_c['sugar_field']);
											$customfiled_c=substr($sugar_c['sugar_field'],$str-2,2);
											$customfiled_c=strstr($customfiled_c,"_c");
											if(!empty($customfiled_c))
											{
												$ParseMyResumeData_c[]=$sugar_c['ParseMyResume_field'];
												$varchar_c=strstr($sugar_c['sugar_field_size'],"varchar");
												$char_c=strstr($sugar_c['sugar_field_size'],"char");
												
												$sugar_c['ParseMyResume_field']."===".$sugar_c['sugar_field_size'];
												
												if($sugar_c['sugar_field_size']=='tinytext' || $sugar_c['sugar_field_size']=='text' || $sugar_c['sugar_field_size']=='mediumtext' || $sugar_c['sugar_field_size']=='longtext'){
													$ParseMyResumeType_len[] = $sugar_c['sugar_field_size'];
												}else if(substr($sugar_c['sugar_field_size'],0,7) == 'varchar'){
													$str_var = str_replace("varchar(","",$sugar_c['sugar_field_size']);
													$str_var = str_replace(")","",$str_var);
													$ParseMyResumeType_len[] = $str_var;
													//echo " ----".$str_var;
												}else{
													$ParseMyResumeType_len[] = '';
												}
													
												//echo '<br>';
												
												
												//echo $pos;
												if(!empty($varchar_c))
												{
													$size_c=explode("(",$varchar_c);
													$ParseMyResumeDataSize_c[$sugar_c['ParseMyResume_field']]=$size_c[1];
												}
												else if(!empty($char_c))
												{
													$size_c=explode("(",$char_c);
													$ParseMyResumeDataSize_c[$sugar_c['ParseMyResume_field']]=$size_c[1];	
												}
												else if(!empty($dateType_c))
												{
													$ParseMyResumeDate_c[$sugar_c['ParseMyResume_field']]="date";	
												}		
																
												$queryUpdate_c.="`".$sugar_c['sugar_field']."`,";
											}
										}
							
				                    } 
										$queryUpdate_c=rtrim($queryUpdate_c,",").")VALUES ('{$id}',";
										$num_c=count($ParseMyResumeData_c);
										for($i_c=0;$i_c<$num_c;$i_c++)
										{
											foreach($ParseMyResumeDataSize_c as $key_c=>$value_c)
											{  
												if($ParseMyResumeData_c[$i_c]==$key_c && $ParseMyResumeData_c[$i_c]!=='CandidateImageData')
												{  
													$upload_result[$ParseMyResumeData_c[$i_c]]=substr($upload_result[$ParseMyResumeData_c[$i_c]], 0,$value_c); 
													
												}
											}
											foreach($ParseMyResumeDate_c as $field_c=>$fvalue_c)
											{	
												if($ParseMyResumeData_c[$i]==$field_c)
												{
													$originalDate=explode("/",$upload_result[$ParseMyResumeData[$i]]);
													if($originalDate[1]<10)
													{
														$originalDate[1]="0".$originalDate[1];
													}
													if($originalDate[0]<10)
													{
														$originalDate[0]="0".$originalDate[0];
													}
													$upload_result[$ParseMyResumeData[$i]]=$originalDate[2].":".$originalDate[1].":".$originalDate[0];
												}									
											}
											//CandidateImageFormat
										   if($ParseMyResumeData_c[$i_c]=='CandidateImageData')
										   {
												$img_type = $upload_result['CandidateImageFormat'];
												$im = $upload_result['CandidateImageData'];
												if(strlen($im)>20)
												{
													$img = str_replace('data:image/jpeg;base64,', '', $im);
													$img = str_replace(' ', '+', $img);
													$data = base64_decode($img);
													$file = "custom/OffshorePhoto/phpThumb/images/Leads_{$id}.".$img_type;
													$success = file_put_contents($file, $data);
													//header('Content-Type: image/'.$img_type);
													$upload_result[$ParseMyResumeData_c[$i_c]] = "Leads_{$id}.".$img_type;
												}else{
													$upload_result[$ParseMyResumeData_c[$i_c]] = '';
												}
										   }
										   /*
											echo $ln;
													echo '<br>';		
												 if($ln!='')					
												   $field_value=	addslashes(substr($sugar_c['sugar_field'],0,$ln));	
												   else
													$field_value =addslashes($sugar_c['sugar_field']);		
													echo $field_value;
													echo '<br>';
													*/
											if($ParseMyResumeType_len[$i_c]=='tinytext' || $ParseMyResumeType_len[$i_c]=='text' || $ParseMyResumeType_len[$i_c]=='mediumtext' || $ParseMyResumeType_len[$i_c]=='longtext'){
												$output = preg_replace('/[^(\x20-\x7F)]*/','', $upload_result[$ParseMyResumeData_c[$i_c]]);
												
												
												$queryUpdate_c.="'".addslashes(htmlspecialchars(substr($output,0,$text_data_len[$ParseMyResumeType_len[$i_c]])))."',";
												//echo $text_data_len[$ParseMyResumeType_len[$i_c]]."===";echo '<br>';
											}else if(strlen($ParseMyResumeType_len[$i_c])>0){
												$queryUpdate_c.="'".addslashes(substr(trim($upload_result[$ParseMyResumeData_c[$i_c]]),0,strlen($ParseMyResumeType_len[$i_c])))."',";
												//echo addslashes(substr(trim($upload_result[$ParseMyResumeData_c[$i_c]]),0,strlen($ParseMyResumeType_len[$i_c])));
												//echo "-------------------------------------------------------<br><br>";
											}else{
												$queryUpdate_c.="'".addslashes($upload_result[$ParseMyResumeData_c[$i_c]])."',";
										}
				} 
											$queryUpdate_c=rtrim($queryUpdate_c,",").");";


											$thisSugarBean->db->query($queryUpdate_c,true); 
						/**********************************************************************************************Email Store"*******************************/
						
							
							 $email=$upload_result['Email'];
							 $capEmail=strtoupper($email);
							 $emailQuery="INSERT INTO `email_addresses` (`id`, `email_address`, `email_address_caps`, `invalid_email`, `opt_out`, `date_created`, `date_modified`, `deleted`) VALUES ('{$id}', '{$email}', '{$capEmail}','0','0','{$date}','{$date}', '0');";
							 $thisSugarBean->db->query($emailQuery,true); 
							 $emailbeanQuery="INSERT INTO `email_addr_bean_rel` (`id`, `email_address_id`, `bean_id`, `bean_module`, `primary_address`, `reply_to_address`, `date_created`, `date_modified`, `deleted`) VALUES ('{$id}','{$id}', '{$id}', 'Leads', '0', '0','{$date}','{$date}', '0');";
							 $thisSugarBean->db->query($emailbeanQuery,true); 
				
		 /** code  to add attachment with note **/				 
			$note = new Note();
			$note->modified_user_id = 1;
			$note->created_by = 1;
			$note->assigned_user_id = 1;
			$note->name = $file_name;
			$note->parent_type = "Leads";
			$note->parent_id = $id;
			$note->filename = 'modules/ParseMyResume/data/resume/'.$file_name; //your file name goes here
			$note->file_mime_type = mime_type($file_name);   // your file's mime type goes here
			$note->save();
			 
		 	$dest = $GLOBALS['sugar_config']['upload_dir'].$note->id; 
			if (!is_file($dest)) {
				move_uploaded_file($note->filename, $dest);
			} 
	//		echo '<pre>';
	//		print_r($note); exit;
			/** end code to save attachment **/	
	
				
				
							 
							 return $id;
						
						
					}
					else
					{
					
					 return 1000;  //Lead already Exist  Error Code 1000;
					}
			}
			
		
	}
 }
 function mime_type($filename) {

        $mime_types = array(

            'txt' => 'text/plain',
            'htm' => 'text/html',
            'html' => 'text/html',
            'php' => 'text/html',
            'css' => 'text/css',
            'js' => 'application/javascript',
            'json' => 'application/json',
            'xml' => 'application/xml',
            'swf' => 'application/x-shockwave-flash',
            'flv' => 'video/x-flv',

            // images
            'png' => 'image/png',
            'jpe' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'jpg' => 'image/jpeg',
            'gif' => 'image/gif',
            'bmp' => 'image/bmp',
            'ico' => 'image/vnd.microsoft.icon',
            'tiff' => 'image/tiff',
            'tif' => 'image/tiff',
            'svg' => 'image/svg+xml',
            'svgz' => 'image/svg+xml',

            // archives
            'zip' => 'application/zip',
            'rar' => 'application/x-rar-compressed',
            'exe' => 'application/x-msdownload',
            'msi' => 'application/x-msdownload',
            'cab' => 'application/vnd.ms-cab-compressed',

            // audio/video
            'mp3' => 'audio/mpeg',
            'qt' => 'video/quicktime',
            'mov' => 'video/quicktime',

            // adobe
            'pdf' => 'application/pdf',
            'psd' => 'image/vnd.adobe.photoshop',
            'ai' => 'application/postscript',
            'eps' => 'application/postscript',
            'ps' => 'application/postscript',

            // ms office
            'doc' => 'application/msword',
            'rtf' => 'application/rtf',
            'xls' => 'application/vnd.ms-excel',
            'ppt' => 'application/vnd.ms-powerpoint',

            // open office
            'odt' => 'application/vnd.oasis.opendocument.text',
            'ods' => 'application/vnd.oasis.opendocument.spreadsheet',
        );

        $ext = strtolower(array_pop(explode('.',$filename)));
        if (array_key_exists($ext, $mime_types)) {
            return $mime_types[$ext];
        }
        elseif (function_exists('finfo_open')) {
            $finfo = finfo_open(FILEINFO_MIME);
            $mimetype = finfo_file($finfo, $filename);
            finfo_close($finfo);
            return $mimetype;
        }
        else {
            return 'application/octet-stream';
        }
    }


?>