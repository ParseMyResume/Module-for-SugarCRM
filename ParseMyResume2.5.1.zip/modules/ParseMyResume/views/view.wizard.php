<?php
/*********************************************************************************
 * ParseMyResume is helping SugarCRM customers to insert Resumes into ATS. 
 * ParseMyResume Copyright (C) 2011  - 2013 ParseMyResume.
 * 
 * This program is free/Subscription based  software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY ParseMyResume, ParseMyResume DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact ParseMyResume. headquarters at Suite 13, C-134, Phase 8
 * Industrial Area, Mohali, Punjab, 160062 India. or at email address support@parsemyresume.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 ********************************************************************************/
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

class ViewWizard extends SugarView
{
	/**
	 * Constructor for the view, it runs the constructor of SugarWirelessView and
	 * sets the footer option to true (it is off in the SugarWirelessView constructor)
	 */
	public function __construct()
	{
		parent::SugarView();

        $this->options['show_header'] = false;
        $this->options['show_footer'] = false;
        $this->options['show_javascript'] = false;
	}

	/**
	 * @see SugarView::display()
	 */
	public function display()
    {
        global $mod_strings, $current_user, $locale, $sugar_config, $app_list_strings, $sugar_version;
		echo "sdcjk";
		
	}

    /**
     * Function to sort currencies in array alphabetically, except for US Dollar which must remain as first element
     * in the array.
     *
     * @param array $currenciesArray Array of currencies to sortecho "dkj
     * @return array|string Array of sorted currencies with the US Dollar as the first
     */
    public function correctCurrenciesSymbolsSort($currenciesArray)
    {
        $baseCurrencyId = '-99';
        $newCurrenciesArray = array ();

        $newCurrenciesArray[] = $currenciesArray[$baseCurrencyId]['symbol'];
        array_shift($currenciesArray);
        $currenciesArray = array_csort($currenciesArray);
        foreach ($currenciesArray as $value)
        {
            $newCurrenciesArray[] = $value['symbol'];
        }
        return $this->pushCurrencyArrayToString($newCurrenciesArray);
    }

    /**
     * Generates javascript array from a php array
     *
     * @see correctCurrenciesSymbolsSort
     * @param $array
     * @return array|string Javascript code snippet of currencies array
     */
    public function pushCurrencyArrayToString($array)
    {
        $return = '';
        foreach($array as $key => $value)
        {
            $return .= "currencies[{$key}] = '{$value}';\n";
        }
        return $return;
    }
}

