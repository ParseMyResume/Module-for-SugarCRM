<?php
/*********************************************************************************
 * ParseMyResume is helping SugarCRM customers to insert Resumes into ATS. 
 * ParseMyResume Copyright (C) 2011  - 2013 ParseMyResume.
 * 
 * This program is free/Subscription based  software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY ParseMyResume, ParseMyResume DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact ParseMyResume. headquarters at Suite 13, C-134, Phase 8
 * Industrial Area, Mohali, Punjab, 160062 India. or at email address support@parsemyresume.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 ********************************************************************************/
 	ini_set('display_errors', 0);
	class AReader {
		var $host;
		var $login;
		var $password;
		var $mbox;
		var $struct;
		var $emails_quan = 0; // inbox (or any other box) emails quantity
		var $current_email_index = 0; // current email index
		var $current_attach_index = 2; // current attachment index
		var $attachment = '';
		var $attachment_filename = '';
		var $processed_emails;
		var $attachment_types = array('ATTACHMENT', 'INLINE');		
		
		function AReader($host, $login, $password) {
			$this->host = $host;
			$this->login = $login;
			$this->password = $password;			
		}
		
		function Connect() {
			$this->mbox = imap_open($this->host, $this->login, $this->password);
			
			if (empty($this->mbox))	
			{
				return false;
			} else {
				$this->emails_quan = imap_num_msg($this->mbox);
				return true;
			}
		}
		
		function FetchMail() {
			if (empty($this->mbox) || $this->emails_quan == $this->current_email_index) {
				return false;
			}
						
			$this->current_email_index++;
			$this->current_attach_index = 2;
			$headers = imap_headerinfo($this->mbox, $this->current_email_index);
			$this->struct = imap_fetchstructure($this->mbox, $this->current_email_index);
			//echo "<pre>";
			//print_r($this->struct);
			if($headers->Unseen == 'U') {
				$this->struct = imap_fetchstructure($this->mbox, $this->current_email_index);
				
				/*For old format*/
				//$this->body =  imap_qprint(imap_fetchbody($this->mbox, $this->current_email_index,'1.1'));
				
				$this->body =  imap_qprint(imap_fetchbody($this->mbox, $this->current_email_index,'1'));
				
				$xml = trim($this->body);
		
				$xmlDoc = new DOMDocument();
				$xmlDoc->loadXML($xml);
				if(!$xmlDoc->loadXML($xml)){
					echo "Incorrect format - Admin<br>";
					$emailSender = "admin@econn.in";
					$emailReceiver = "admin@econn.in";
					$subject = "Incorrect Format - AgentHire";
					$msg ='<html><body>
								<table width="70%" border="0" cellspacing="1" cellpadding="1" style="background:#CCCCCC;">
					  <tr>
						<td><table border="0" cellpadding="4" cellspacing="4" width="100%" style="border:0px solid #ccc; background:#fff;">
										  <tbody>
										   <tr>
											<td align="center" width="20%" colspan="2" bgcolor="#f4f4f4" style=" color: #040006; font-size: 12px; font-family:Arial, Helvetica, sans-serif"><strong>Incorrect format of message number - '.$this->current_email_index .'</strong></td>
										  </tr>
					</tbody></table></td>
					  </tr>
					</table>
								</body></html>';
						require_once('../PHPMailer/class.phpmailer.php');
					
						$mail             = new PHPMailer();
					
						$body             = eregi_replace("[\]",'',$msg);
					
						$mail->IsSMTP(); // telling the class to use SMTP
					
						$mail->SMTPAuth   = true;                  // enable SMTP authentication
						
						// configuration in config
						$mail->Host       = "ssl://smtp.gmail.com";
						$mail->Port       = 465;                  
						$mail->Username   = "admin@econn.in";
						$mail->Password   = "admin*123";
						
						$mail->SetFrom($emailSender, 'Admin');	
						$mail->Subject    = $subject;	
					
						$mail->MsgHTML($body);
						
						// $email set in config
						$address = $emailReceiver;	
						$arrmail = explode(",", $emailReceiver);
						foreach ($arrmail as $email2) {
						$mail->AddAddress($email2, "Admin");
						}
						$mail->Send();
					
				}
				else{
				
					$x = $xmlDoc->documentElement;
				
					$arr = array();
					foreach ($x->childNodes AS $item)
					{
						$arr[$item->nodeName] = $item->nodeValue;
					}
					$JobPositionSeekerId =  $arr['JobPositionSeekerId'];
					$query = "SELECT user_name FROM user WHERE JobPositionSeekerId = '$JobPositionSeekerId'";
					$mysql = mysql_query($query);
					$result = mysql_fetch_assoc($mysql);
					$userName =  $result['user_name'];
					
					// Make Dir with username
					if(!is_dir("file/".$userName)){
							   mkdir("file/".$userName ,0777,true);
					}
				}
			}
			else {
				echo "No unseen mails are there in Inbox!<br>";
				//return false;
			}
			return true;
			//print_r($arr);
		}
	
		function HasAttachment() {			
			return property_exists($this->struct, 'parts');
		}
		
		function FetchAttachment() {
			$this->attachment = '';
						
			if (empty($this->struct)
				|| !property_exists($this->struct, 'parts')
				|| !array_key_exists($this->current_attach_index - 1, $this->struct->parts)
			) {
				return false;
			}						
			/*echo "<pre>";
			print_r($this->struct->parts);*/
			$parts_count = count($this->struct->parts) + 1;
						
			while (true) {
				if ($this->current_attach_index > $parts_count) {
					return false;
				}
				
				$part = $this->struct->parts[$this->current_attach_index - 1];
				
				if (!property_exists($part, 'disposition') || !in_array($part->disposition, $this->attachment_types)) {
					$this->current_attach_index++;
					continue;
				}
				
				if (!empty($part->parameters)) {
					$parameters = $part->parameters;
					$fattr = 'NAME';
				} else {
					$parameters = $part->dparameters;
					$fattr = 'FILENAME';
				}
				
				foreach ($parameters as $parameter) {
					if ($parameter->attribute == $fattr) {
						$filename = $parameter->value;
					}
				}
				
				if (empty($filename)) {
					$this->current_attach_index++;
					continue;
				}
				
				$decoded = imap_mime_header_decode($filename);
				$filename = '';
				foreach ($decoded as $dec) {					
					if (!empty($dec->text)) {
						$encoding = $dec->charset;
						$fpart = $dec->text;
						$filename .= $fpart;
					}
				}
				
				$this->attachment_filename = $filename;				
								
				$this->attachment = imap_fetchbody($this->mbox, $this->current_email_index, $this->current_attach_index);
				$this->attachment = base64_decode($this->attachment);		//for old format		
				//$this->attachment = quoted_printable_decode($this->attachment);
				//echo $this->attachment;
				$this->current_attach_index++;
				
				if (empty($this->attachment)) {					
					return false;
				}
				
				return true;
			}
			
		}
		
		function SaveAttachment($save_path, $new_filename = '') {
		$this->body =  imap_qprint(imap_fetchbody($this->mbox, $this->current_email_index,'1'));
			$xml = trim($this->body);
			
			$xmlDoc = new DOMDocument();
			$xmlDoc->loadXML($xml);
			
			$x = $xmlDoc->documentElement;
		
			$arr = array();
			foreach ($x->childNodes AS $item)
			{
				$arr[$item->nodeName] = $item->nodeValue;
			}
			if (!empty($this->attachment)) {
				echo $save_to = $save_path.'/'.(!empty($new_filename) ? $new_filename : $this->attachment_filename);
				echo "<br>";
				$bytes_quan = file_put_contents($save_to, $this->attachment);
				if (!empty($bytes_quan)) {
					return $save_to;
				}
			}
			
			return '';
		}
		
		function GetAttachmentFilename() {
			return $this->attachment_filename;
		}
		
		function DeleteMail() {
			if ($this->current_email_index > 0) {
				imap_delete($this->mbox, $this->current_email_index);
			}
		}
		
		function Close() {
			if ($this->mbox) {
				imap_close($this->mbox, CL_EXPUNGE);
			}
		}
		
		function getDirectoryList ($directory,$filter) {
		
			// create an array to hold directory list
			$results = array();
			// create a handler for the directory
			$handler = opendir($directory);
			// open directory and walk through the filenames
			while ($file = readdir($handler)) {
			$explodemainfilename = explode(".",basename($file));
			$countmainexplode = count($explodemainfilename);
			$filterfile = $explodemainfilename[$countmainexplode-1] ;
			if($filterfile == 'zip' && $file != "." && $file != ".."){
				$zip[] = $file;
			}
			else if($file != "." && $file != ".."){
				$dir[] = $file;
			}
			  // if file isn't this directory or its parent, add it to the results
			}
			// tidy up: close the handler
			closedir($handler);
			// done!
			if($filter == 'zip'){
				return $zip;
			}
			else{
				return $dir;
			}
		}
		
		function Zip($source, $destination)
		{
			if (is_string($source)) $source_arr = array($source); // convert it to array
		
			if (!extension_loaded('zip')) {
				return false;
			}
		
			$zip = new ZipArchive();
			if (!$zip->open($destination, ZIPARCHIVE::CREATE)) {
				return false;
			}
		
			foreach ($source_arr as $source)
			{
				//echo $source."<br>";
				if (!file_exists($source)) continue;
				$source = str_replace('\\', '/', realpath($source));
				
				if (is_dir($source) === true)
				{
					$files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($source), RecursiveIteratorIterator::SELF_FIRST);
				
					foreach ($files as $file)
					{
						$file = str_replace('\\', '/', realpath($file));
				
						if (is_dir($file) === true)
						{
							$zip->addEmptyDir(str_replace($source . '/', '', $file . '/'));
						}
						else if (is_file($file) === true)
						{
							$zip->addFromString(str_replace($source . '/', '', $file), file_get_contents($file));
						}
					}
				}
				else if (is_file($source) === true)
				{
					$zip->addFromString(basename($source), file_get_contents($source));
				}
		
			}
		
			return $zip->close();
		
		}	
		
		function delete_directory($dirname) {
		   if (is_dir($dirname))
			  $dir_handle = opendir($dirname);
		   if (!$dir_handle)
			  return false;
		   while($file = readdir($dir_handle)) {
			  if ($file != "." && $file != "..") {
				 if (!is_dir($dirname."/".$file))
					unlink($dirname."/".$file);
				 else
					delete_directory($dirname.'/'.$file);    
			  }
		   }
		   closedir($dir_handle);
		   rmdir($dirname);
		   return true;
		}
	}
 
?>