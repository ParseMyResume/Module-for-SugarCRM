<?php
/*********************************************************************************
 * ParseMyResume is helping SugarCRM customers to insert Resumes into ATS. 
 * ParseMyResume Copyright (C) 2011  - 2013 ParseMyResume.
 * 
 * This program is free/Subscription based  software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY ParseMyResume, ParseMyResume DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact ParseMyResume. headquarters at Suite 13, C-134, Phase 8
 * Industrial Area, Mohali, Punjab, 160062 India. or at email address support@parsemyresume.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 ********************************************************************************/
class ZipProcess
{	
	var $_uploaderror='';
	var $_resumeuploadfile='';
	var $_resumeuploadsucess = "";
	var $_filterfile = "";
	var $_user = "";
	var $_uploaderrorArr= array();
	var $_countfiles='';
	var $_countresumefile=0;
	/**
	* to give report message
	*/
	var $_reportmessage="<table border=1>";
	var $_username;
	var $_totalnooffiles=0;
	var $_curruptfiles=0;
	var $_totalnoofrecordsexcel=0;
	var $_curruptrecordsexcel=0;
	var $_filetype='';
	var $_recordno=0;
	var $_excelfilename='';
	var $_uploadfrombrowser=0;
 function extract()
		{
			include "modules/ParseMyResume/class.recruiter.php";	
			include "modules/ParseMyResume/singleLead.php";
			include "modules/ParseMyResume/class.ParseMyResume.php";   
			$dir2="modules/ParseMyResume/data";
			$handle = opendir($dir2);
			while ($file = readdir($handle)) 
			{
				if($file!="." && $file!="..")
				{
					$pos=strpos($file,".");
					if(!empty($pos))
					{
						$filename=explode(".",$file);
						if($filename[1]=="zip")
						{
							 
							include "modules/ParseMyResume/pclzip.lib.php";
							$archive = new PclZip($dir2."/".$file);
								if (($v_result_list = $archive->extract("modules/ParseMyResume/data/resume")) == 0) 
								{
									$this->_uploaderror .="Zip Cound not extract.<br>Error : ".$archive->errorInfo(true);
									//exit();
								} 
								chmod('modules/ParseMyResume/data/'.$filename[0].'.zip',0777);
								unlink('modules/ParseMyResume/data/'.$filename[0].'.zip');
								$totalfiles=sizeof($v_result_list);
							
								for($i=0;$i<sizeof($v_result_list);$i++)
								{ 
	
										if($v_result_list[$i]["size"] < 17000000)
											{
											 $FileName=$v_result_list[$i]['filename']; 
											$fi=explode(".",$v_result_list[$i]['filename']);
											$fname=explode("/",$fi[0]);
											$flen=count($fname);
												$explodemainfilename = explode(".",basename($v_result_list[$i]['filename']));
												$countmainexplode = count($explodemainfilename);
												$filterfile = $explodemainfilename[$countmainexplode-1] ;
							
												if($filterfile == "rtf" || $filterfile == "doc" || $filterfile == "docx" || $filterfile== "pdf" || $filterfile == "txt" || $filterfile == "html")
													{
														@$stream=fopen($v_result_list[$i]["filename"],'r');
														$content = stream_get_contents($stream);
														$this->_resumeuploadsucess = "yes";
														$this->_filterfile = $filterfile;
														
														if($filterfile == "rtf" || $filterfile == "doc" || $filterfile == "docx" || $filterfile == "txt" || $filterfile == "html" || $filterfile== "pdf")
															{
																
																$upload_result='';		
																$upload= new Recruiter();
																	
					$upload_result=$upload->GetXML($content,basename($v_result_list[$i]['filename']));	
					$upload_result["filepath"] = $v_result_list[$i]['filename']; 
					$upload_result["filetype"] = $filterfile;
					$upload_result["filename"] = $fname[$flen-1].".".$filterfile;
					$msg=saveleadZipEmail($upload_result); 
					
																	if(!empty($msg))
																	{
																		if($msg==112)
																		{
																			$this->_reportmessage.="<tr><td style='padding:0px 5px 0px 5px'>".$fname[$flen-1]."</td><td style='padding:0px 5px 0px 5px'> Email Id Is Blank</td></tr>";
																			$this->_curruptfiles=$this->_curruptfiles+1;
																		}
																		else if($msg==1000)
																		{
																			$this->_reportmessage.="<tr><td style='padding:0px 5px 0px 5px'>".$fname[$flen-1]."</td><td style='padding:0px 5px 0px 5px'>Lead Already Exist</td></tr>";
																			$this->_curruptfiles=$this->_curruptfiles+1;
																		}
																		else if($msg==1001)
																		{
																			$this->_reportmessage.="<tr><td style='padding:0px 5px 0px 5px'>".$fname[$flen-1]."</td><td style='padding:0px 5px 0px 5px'>Invalid Key Please Contact ParseMyResume Support</td></tr>";
																			$this->_curruptfiles=$this->_curruptfiles+1;
																		}
																		else if($msg==1002)
																		{
																			$this->_reportmessage.="<tr><td style='padding:0px 5px 0px 5px'>".$fname[$flen-1]."</td><td style='padding:0px 5px 0px 5px'>Key Expired Please Contact ParseMyResume Support</td></tr>";
																			$this->_curruptfiles=$this->_curruptfiles+1;
																		}
																		else if($msg==1003)
																		{
																			$this->_reportmessage.="<tr><td style='padding:0px 5px 0px 5px'>".$fname[$flen-1]."</td><td style='padding:0px 5px 0px 5px'>Credit Exhausted. Please Contact ParseMyResume Support</td></tr>";
																			$this->_curruptfiles=$this->_curruptfiles+1;
																		}
																		else if($msg==1005)
																		{
																			$this->_reportmessage.="<tr><td style='padding:0px 5px 0px 5px'>".$fname[$flen-1]."</td><td style='padding:0px 5px 0px 5px'>Not Text Content. Please Save in Proper Format</td></tr>";
																			$this->_curruptfiles=$this->_curruptfiles+1;
																		}
																		else if($msg==1010)
																		{
																			$this->_reportmessage.="<tr><td style='padding:0px 5px 0px 5px'>".$fname[$flen-1]."</td><td style='padding:0px 5px 0px 5px'>Corrupt Data.</td></tr>";
																			$this->_curruptfiles=$this->_curruptfiles+1;
																		}
																		else if($msg==1004 || $msg==1007 || $msg==1008 || $msg==1009 || $msg==1011 || $msg==1012 || $msg==1006)
																		{
																			$this->_reportmessage.="<tr><td style='padding:0px 5px 0px 5px'>".$fname[$flen-1]."</td><td style='padding:0px 5px 0px 5px'>Corrupt Data.</td></tr>";
																			$this->_curruptfiles=$this->_curruptfiles+1;
																		}
																		else
																		{
																			$this->_totalnooffiles=$this->_totalnooffiles+1;
																		}
																	}
																	else
																	{
																			$this->_reportmessage.="<tr><td style='padding:0px 5px 0px 5px'>".$fname[$flen-1]."</td><td style='padding:0px 5px 0px 5px'>Corrupt Data.</td></tr>";
																			$this->_curruptfiles=$this->_curruptfiles+1;
																	}
																chmod($FileName,0777);
																unlink($FileName);
																
																
															}
													}
													else
													{
														$this->_reportmessage.="<tr><td style='padding:0px 5px 0px 5px'>".$fname[$flen-1]."</td><td style='padding:0px 5px 0px 5px'>Not Supported format</td></tr>";
														$this->_curruptfiles=$this->_curruptfiles+1;
														chmod($FileName,0777);
														unlink($FileName);
													
													}
											}
								}	
								/*  Remove Directory  */
								for($i=sizeof($v_result_list)-1;$i>=0;$i--)
								{
									if($v_result_list[$i]['crc']==0)
									{
										chmod(rtrim($v_result_list[$i]['filename'],"/"),0777);
										rmdir(rtrim($v_result_list[$i]['filename'],"/"));
									}
									
								}
				$emailBody="<b>Total files:</b>". $totalfiles."<br>"."<b>Incorrect Files:</b>".$this->_curruptfiles."<br><hr>".$this->_reportmessage;
				require_once('include/SugarPHPMailer.php');
				require_once('modules/Administration/Administration.php');
				require_once('data/SugarBean.php');
				$thisSugarBean = new SugarBean();
				$query1="select res_email from ParseMyResume_info where id=1";
				$run_query1=$thisSugarBean->db->query($query1,true);
				$res=$run_query1->fetch_assoc(); 
				$administration  = new Administration();
				$admin_settings  = $administration->retrieveSettings();
				/* echo "<pre>";
				//print_r($admin_settings->settings['notify_fromaddress']);
				/* print_r($admin_settings);
				exit(); */	 
				require_once('include/OutboundEmail/OutboundEmail.php');
				$emailSubject='Sugar Crm Zip Parsing Report';
				$mail = new SugarPHPMailer();
				$mail->Mailer = strtolower($admin_settings->settings['mail_sendtype']);
					if($mail->Mailer == 'smtp')
					{
						$mailserver_url = $admin_settings->settings['mail_smtpserver'];
						$port = $admin_settings->settings['mail_smtpport'];
						$ssltls= $admin_settings->settings['mail_smtpssl'];
						$smtp_auth_req= $admin_settings->settings['mail_smtpauth_req'];
						$smtp_username= $admin_settings->settings['mail_smtpuser'];
						$smtppassword= $admin_settings->settings['mail_smtppass'];
						$toaddress= $res['res_email'];
							$mail->Host = $mailserver_url;
							$mail->Port = $port;
							if (isset($ssltls) && !empty($ssltls)) {
								$mail->protocol = "ssl://";
								if ($ssltls == 1) {
									$mail->SMTPSecure = 'ssl';
								} // if
								if ($ssltls == 2) {
									$mail->SMTPSecure = 'tls';
								} // if
							} else {
								$mail->protocol = "tcp://";
							}
							if ($smtp_auth_req) {
								$mail->SMTPAuth = TRUE;
								$mail->Username = $smtp_username;
								$mail->Password = $smtppassword;
							}
						$mail->Subject = $emailSubject;
						$mail->From = $admin_settings->settings['notify_fromaddress'];
						$mail->FromName= $admin_settings->settings['notify_fromname'];
					    $mail->Sender = $mail->From;
						$mail->AddAddress($toaddress);
						$mail->IsHTML(true);
						$mail->Body =from_html($emailBody);
						$mail->Send();
	
						}
					}
				}
			
  
			}
				
					}
					
				
				
				
		
		}
		
						
}
					

?>