<?php
/*********************************************************************************
 * ParseMyResume is helping SugarCRM customers to insert Resumes into ATS. 
 * ParseMyResume Copyright (C) 2011  - 2013 ParseMyResume.
 * 
 * This program is free/Subscription based  software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY ParseMyResume, ParseMyResume DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact ParseMyResume. headquarters at Suite 13, C-134, Phase 8
 * Industrial Area, Mohali, Punjab, 160062 India. or at email address support@parsemyresume.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 ********************************************************************************/
$module_name = 'ParseMyResume';
$viewdefs = array (
$module_name =>
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          array('customCode'=>'<input title="{$MOD.LBL_DELETE_PROCESS_FILTER_ENTRIES}" accessKey="{$APP.LBL_MAILMERGE_KEY}" class="button" onclick="this.form.return_module.value=\'PM_ProcessManager\'; this.form.return_action.value=\'DetailView\';this.form.action.value=\'DeleteProcessFilterEntries\'" type="submit" name="button" value="{$MOD.LBL_DELETE_PROCESS_FILTER_ENTRIES}">'),
        ),
      ),
      'maxColumns' => '3',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
    ),
    'panels' => 
    array (
      '' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'name',
            'label' => 'LBL_NAME',
          ),
          1 => 
          array (
            'name' => 'status',
            'label' => 'LBL_STATUS',
          ),
         2 => 
          array (
            '' => '',
            '' => '',
          ),  
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'process_object',
            'label' => 'LBL_PROCESS_OBJECT',
          ),
          1 => 
          array (
            'name' => 'start_event',
            'label' => 'LBL_START_EVENT',
          ),
         2 => 
          array (
            '' => '',
            '' => '',
          ),    
        ),

        2=> 
        array (
          0 => 
          array (
            'name' => 'date_entered',
            'customCode' => '{$fields.date_entered.value} {$APP.LBL_BY} {$fields.created_by_name.value}',
            'label' => 'LBL_DATE_ENTERED',
          ),
          1 => 
          array (
            'name' => 'date_modified',
            'customCode' => '{$fields.date_modified.value} {$APP.LBL_BY} {$fields.modified_by_name.value}',
            'label' => 'LBL_DATE_MODIFIED',
          ),
         2 => 
          array (
            '' => '',
            '' => '',
          ),        
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'description',
            'label' => 'LBL_DESCRIPTION',
          ),
        ),
      ),

      'Object Filter Field Values' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'detail_view_field1',
            'label' => 'LBL_PROCESS_OBJECT_FILTER_FIELD1',
          ),
          1 => 
          array (
            'name' => 'detail_view_operator1',
            'label' => 'LBL_CHOOSE_FILTER1',
          ),
          2 => 
          array (
            'name' => 'detail_view_value1',
            'label' => 'LBL_PROCESS_OBJECT_FIELD1_VALUE',
          ),
        ),                                
      ),
           
      
    ),
  ),
)
);
?>
