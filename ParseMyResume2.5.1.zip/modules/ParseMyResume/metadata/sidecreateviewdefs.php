<?php
/*********************************************************************************
 * ParseMyResume is helping SugarCRM customers to insert Resumes into ATS. 
 * ParseMyResume Copyright (C) 2011  - 2013 ParseMyResume.
 * 
 * This program is free/Subscription based  software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY ParseMyResume, ParseMyResume DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact ParseMyResume. headquarters at Suite 13, C-134, Phase 8
 * Industrial Area, Mohali, Punjab, 160062 India. or at email address support@parsemyresume.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 ********************************************************************************/
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');


global $mod_strings;
$viewdefs['ParseMyResume']['SideQuickCreate'] = array(
    'templateMeta' => array('form'=>array('buttons'=>array('HIDDEN'),
							'enctype' => 'multipart/form-data',
    								      'button_location'=>'bottom',
                                          'headerTpl'=>'include/EditView/header.tpl',
                                          'footerTpl'=>'include/EditView/footer.tpl',
                                          ),
							
							'maxColumns' => '1',
							'panelClass'=>'none',
							'labelsOnTop'=>false,
                            'widths' => array(
                                            array('label' => '10', 'field' => '30'),
                                         ),
                        ),
 'panels' =>array (
  'DEFAULT' =>
  array (
    array(
      array('name'=>'Parse Resume',
	  'customCode'=>'
<form  method="post" name="uploadform" enctype="multipart/form-data" >
<tr>
		<td colspan=2>
<input type="hidden" name="filesubmitted" value="yes"></td></tr>
<input type="hidden" value="ParseMyResume" name="module">
<input type="hidden" value="" name="record">
<input type="hidden" value="false" name="isDuplicate">
<input type="hidden" value="lead" name="action">
<input type="hidden" value="Leads" name="return_module">
<input type="hidden" value="DetailView" name="return_action">
<input type="hidden" value="" name="return_id">
<input type="hidden" name="module_tab">
<input type="hidden" name="contact_role">
<input type="hidden" value="Leads" name="relate_to">
<input type="hidden" value="" name="relate_id">
<input type="hidden" value="1" name="offset">
<tr><td> Preferred Country </td></tr>
<tr>
<td><select name="resumeCountry" id="resumeCountry">
   <option value="0">---Country---</option>
   <option value="SRW7P97B75EKS5SE27EM">Australia</option>
   <option value="AK9SQTB248TXG73Q73D5">France</option>
   <option value="MYHNTRY6U5FF8GR3HAVF">India</option>
   <option value="D4BGRZCVPF4UWUMZEYPD">Ireland</option>
   <option value="YYFJRKHGZT6AVUZR9WQE">Netherlands</option>
   <option value="GM6EK7ZGSR6JF7GM6QNG">Singapore</option>
   <option value="SO6EK7ZGSRJF7GA6RICA">SouthAfrica</option>
   <option value="BANKEK7ZGKIOJFGMTHAI">Thailand</option>
   <option value="2HQZ2URZ3C2E9AE87YY3">UK</option>
   <option value="SRW7P97B75EKS5SE27EM">USA Canada</option>
     </select></td>
</tr>

<tr> 
 <td>Upload Resume: </td></tr>
 <tr><td><input name="resumecontent" id="resumecontent" type="file" size="9"></td></tr>
<tr>
<td> <input type="submit" value="upload" id="submit" /> </td> </tr>
</table></form>'),
    ),
    
  ),

 )


);
?>
