
<?php
/*********************************************************************************
 * ParseMyResume is helping SugarCRM customers to insert Resumes into ATS. 
 * ParseMyResume Copyright (C) 2011  - 2013 ParseMyResume.
 * 
 * This program is free/Subscription based  software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY ParseMyResume, ParseMyResume DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact ParseMyResume. headquarters at Suite 13, C-134, Phase 8
 * Industrial Area, Mohali, Punjab, 160062 India. or at email address support@parsemyresume.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 ********************************************************************************/
		require_once('data/SugarBean.php');
		$thisSugarBean = new SugarBean();
		$query1="select * from ParseMyResume_info";
		$run_query2=$thisSugarBean->db->query($query1,true);
		$res=$run_query2->fetch_assoc();
		$password=$res['password'];
		$user=$res['email'];
		$port=$res['port'];
		$ssl=$res['ssl'];
		$map=$res['map'];
		$host="{".$res['host'].":".$port."/".$map."/".$ssl."}INBOX";
		?>
		
<script src="modules/ParseMyResume/js/ajxsmt.js" type="text/javascript"></script>
<style>

</style>

<div style=" width:600px; margin:0px auto; border:1px solid #646464; box-shadow: 0px 0px 10px #646464;">
	<table align="center" cellspacing=10 cellpadding=10 style="width:600px;" > 
<form action="index.php?module=ParseMyResume&action=mailData" method="post" name="uploademail" id="uploademail" enctype="multipart/form-data" onsubmit="xmlhttpPost('index.php?module=ParseMyResume&action=mailData', 'uploademail', 'error_wrapper', '<center><img src=\'modules/ParseMyResume/images/processing.gif\' align=\'center\'></center>'); return false;">
<tr><td colspan=2 align="center"><image src="modules/ParseMyResume/images/ParseMyResume.png"></td></tr>
<tr style="color:white;background-color:#646464;font-size:16pt;height:30px; "> <td colspan="2" style="padding-left:30px;"> Email Integeration</td></tr>
<tr style="color:#284775;background-color:White;"> <td> Select Nearest Country of Resume </td>
<td>  <select selected="selected"; name="resumeCountry" id="resumeCountry" style="width:154px;" >
<option value="0">---Country---</option>



<?php 
		 
		 $selected="select countrykey from ParseMyResume_info";
		  $country_result=$thisSugarBean->db->query($selected,true);
		  while($row2 = $country_result->fetch_assoc())
			{
				$a=$row2['countrykey'];
			}

	  
?>
<?php 
		$countries =array(
							'0' => array('value' => 'SRW7P97B75EKS5SE27EM','text' => 'Australia'),
							'1' => array('value' => 'AK9SQTB248TXG73Q73D5','text' => 'France'),
							'2' => array('value' => 'MYHNTRY6U5FF8GR3HAVF','text' => 'India'),
							'3' => array('value' => 'D4BGRZCVPF4UWUMZEYPD','text' => 'Ireland'),
							'4' => array('value' => 'YYFJRKHGZT6AVUZR9WQE','text' => 'Netherlands'),
							'5' => array('value' => 'GM6EK7ZGSR6JF7GM6QNG','text' => 'Singapore'),
							'6' => array('value' => 'SO6EK7ZGSRJF7GA6RICA','text' => 'SouthAfrica'),
							'7' => array('value' => 'BANKEK7ZGKIOJFGMTHAI','text' => 'Thailand'),
							'8' => array('value' => '2HQZ2URZ3C2E9AE87YY3','text' => 'UK'),
							'9' => array('value' => 'SRW7P97B75EKS5SE27EM','text' => 'USA Canada'),
							
						);
?>
<?php 
foreach( $countries as $marital) { ?>
									<option value=<?php echo $marital['value'] ?> <?php if($marital['value']==$a){?> selected ="selected"<?php }?>><?php echo $marital['text'] ?></option> 
							<?php } ?>
</select></td>

<tr style="color:#284775;background-color:White;"> <td> User Email </td> <td> <input name="email" type="text" value="<?php if(!empty($user)){ echo $user;}?> "  style=" width:210px; height:30px; border:1px solid #646464;"/></td></tr>
<tr style="color:#333333;background-color:#F7F6F3;"> <td> Password </td> <td> <input name="password" type="password" value="<?php if(!empty($password)){  echo $password;}?>"  style=" width:210px; height:30px; border:1px solid #646464;"/></td></tr>
<tr style="color:#284775;background-color:White;"> <td> Email Server  </td> <td> <input name="host"type="text" value="<?php if(!empty($res['host'])){  echo $res['host'];}?>"  style=" width:210px; height:30px; border:1px solid #646464;"/></td></tr>
<tr style="color:#333333;background-color:#F7F6F3;"> <td> Port No </td> <td> <input name="port" type="text" value="<?php if(!empty($port)){ echo $port;}?>"  style=" width:210px; height:30px; border:1px solid #646464;"/></td></tr>
<tr>
  <td>
    <input type="checkbox" name="ssl" id="ssl"  />
    SSL
  </td>
  <td><select name="map"> 
  <option selected="selected" value="IMAP"> IMAP </option>
  <option value="POP3"> POP3 </option>
  </select></td>
</tr>
<tr align="center"style="color:#333333;background-color:#F7F6F3;">
  <td colspan="2"><input name="submit" type="submit" value="submit"/></td>
</tr>
<tr>
<td colspan="2">
<div id="error_wrapper">
    <div id="site_error">
   
    </div>
</div>

</td>
</form>
</table>


</div>

