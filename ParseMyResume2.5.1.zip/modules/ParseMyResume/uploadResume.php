<?php
	require_once('data/SugarBean.php');
	$thisSugarBean = new SugarBean();
	$checkSql="select map_field from ParseMyResume_info where id=1";
	$run_sql=$thisSugarBean->db->query($checkSql,true);
	$result=$run_sql->fetch_assoc();
	if($result['map_field']==0)
	{
		echo "<script> alert(\"* Field Mapping Required for uploading.\")</script>";
		
	}
	else
	{
	?>
<script type="text/javascript">
 function checkFiles()
 {
    var fup = document.getElementById('resumecontent');
    var fileName = fup.value;
    var ext = fileName.substring(fileName.lastIndexOf('.') + 1);
	var countryValue=document.getElementById('resumeCountry').value;
	if(countryValue=='0')
	{
		alert("Please Select Valid Country");
		return false;
	}
	
else if(ext =="doc" || ext=="DOC"|| ext=="DOCX"|| ext=="docx"|| ext=="rtf"|| ext=="RTF"|| ext=="zip"|| ext=="ZIP"||ext=="html"|| ext=="HTML" || ext =="dot" || ext=="DOT" || ext=="TXT"|| ext=="txt"|| ext=="odt"|| ext=="ODT" ||ext=="pdf"|| ext=="PDF")
    {
        return true;
    }
    else
    {
        alert("Upload Supported File");
        return false;
    }
    }
</script>
<?php
		
		$query1="select * from ParseMyResume_info";
		$run_query2=$thisSugarBean->db->query($query1,true);
		$res=$run_query2->fetch_assoc();
		$password=$res['password'];
		$user=$res['email'];
		$port=$res['port'];
		$ssl=$res['ssl'];
		$map=$res['map'];
		$host="{".$res['host'].":".$port."/".$map."/".$ssl."}INBOX";
		?>
		
<script src="modules/ParseMyResume/js/ajxsmt.js" type="text/javascript"></script>
<div style=" width:600px; margin:0px auto; margin-top:38px;">
<table align="center" cellspacing=10 cellpadding=10 style="width:600px;">
<tr>
	<td colspan=2 align="center"><image src="modules/ParseMyResume/images/ParseMyResume.png"></td>
</tr>
</table>
</div>
<div style=" width:600px; margin:0px auto; margin-top:10px; border:1px solid #646464; box-shadow: 0px 0px 10px #646464;">
<form action="index.php?module=ParseMyResume&action=lead" method="post" name="uploadform" enctype="multipart/form-data" >
<table align="center" cellspacing=10 cellpadding=10 style="width:600px;" > 
<tr>
<td colspan="2"style="color:white;background-color:#646464;font-size:16pt;height:30px;padding-left:10px;"> Parsing </td> 
</tr>
<tr>
		<td colspan=2>
		<input type="hidden" name="filesubmitted" value="yes"></td></tr>
<tr style="color:#333333;background-color:#F7F6F3;"> <td valign="top" style="padding-top:6px;padding-left:10px;">Upload Resume: </td><td><input name="resumecontent" id="resumecontent" type="file" size="9">
<p style="color:red;font-size:12px;text-height:font-size">* Supported Formats: (doc , docx, rtf, txt, odt, dot, pdf, html)</p><p style="color:red;font-size:12px;text-height:font-size">&quot;You can also upload zip of resume here&quot;.</p></td></tr>
<tr align="center" style="color:#284775;background-color:White;">
<td>&nbsp;</td><td align="left"><input type="submit" value="upload" id="submit" onclick="return checkFiles();" /> </td> 
</tr>
</table>
</form>

</div>
<?php
}
?>
