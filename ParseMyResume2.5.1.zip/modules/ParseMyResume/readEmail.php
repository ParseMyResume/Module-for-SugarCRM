<?php
/*********************************************************************************
 * ParseMyResume is helping SugarCRM customers to insert Resumes into ATS. 
 * ParseMyResume Copyright (C) 2011  - 2013 ParseMyResume.
 * 
 * This program is free/Subscription based  software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY ParseMyResume, ParseMyResume DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact ParseMyResume. headquarters at Suite 13, C-134, Phase 8
 * Industrial Area, Mohali, Punjab, 160062 India. or at email address support@parsemyresume.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 ********************************************************************************/


class readEmail
{

	function getAttachment()
	{
	
		require_once('modules/ParseMyResume/class.reader.php');
		//$host="{pop.gmail.com:995/pop3/ssl}INBOX"; // pop3host
		//$user="test1@econn.in"; //pop3 login
		//$password="welcome*123"; //pop3 password
		//$user="anjalikashyap14484@gmail.com"; //pop3 login
		//$password="just1000"; //pop3 password
	
		require_once('data/SugarBean.php');
		$thisSugarBean = new SugarBean();
		$query1="select * from ParseMyResume_info";
		$run_query2=$thisSugarBean->db->query($query1,true);
		$res=$run_query2->fetch_assoc();
		$password=$res['password'];
		$user=$res['email'];
		$port=$res['port'];
		$map=$res['map']; 
		if(!empty($res['ssl']))
		{
			$ssl=$res['ssl'];
			$host="{".$res['host'].":".$port."/".$map."/".$ssl."/novalidate-cert}INBOX";
		}
		else
		{
			//$host="{box797.bluehost.com:993/imap}INBOX";
			$host="{".$res['host'].":".$port."/".$map."/novalidate-cert}INBOX";
		}
		$mbox = new AReader($host, $user, $password);
		if (!$mbox->Connect()) 
			{
				echo ("Can't connect: " . imap_last_error() ."\n");
				die('Unable to establish connection with mailbox');
			}
		while ($mbox->FetchMail()) 
		{
			if ($mbox->HasAttachment()) 
			{
			//echo "has attachment";
			//die ();
				while($mbox->FetchAttachment()) {
				$save_to="modules/ParseMyResume/data";
				$data = $mbox->SaveAttachment($save_to);
			} 
		}
		
		//$mbox->DeleteMail();
		}
		require_once('modules/ParseMyResume/class.recruiter.php');	
		require_once('modules/ParseMyResume/singleLead.php');
		require_once('modules/ParseMyResume/class.ParseMyResume.php');
		$diropen = "modules/ParseMyResume/data/";
		$dh = opendir($diropen);
		while (($file = readdir($dh)) !== false) 
		{
				$explodemainfilename = explode(".",basename("modules/ParseMyResume/data/".$file));
				$countmainexplode = sizeof($explodemainfilename);
				$filterfile = $explodemainfilename[$countmainexplode-1];
		//echo filesize("modules/ParseMyResume/data/".$file);
			 if(filesize("modules/ParseMyResume/data/".$file) < 17000000)
			 {
			  
				
				if($filterfile == "rtf" || $filterfile == "doc" || $filterfile == "docx" || $filterfile== "pdf" || $filterfile == "txt" || $filterfile == "html")
				{	
					@$stream=fopen("modules/ParseMyResume/data/".$file,'r');
					$content = stream_get_contents($stream);
					$upload= new Recruiter();		
					$upload_result = $upload->GetXML($content,basename("modules/ParseMyResume/data/".$file));
					$upload_result["filepath"] = "modules/ParseMyResume/data/".$file; 
					$upload_result["filetype"] = $filterfile;
					$upload_result["filename"] = $file;
					chmod('modules/ParseMyResume/data/'.$file,0777);
					$msg=saveleadZipEmail($upload_result);	
					//unlink('modules/ParseMyResume/data/'.$file);
					
				}
			else if($filterfile == "zip" )
			{
				//echo "<span style='color:#FF0000; font-size:14px; padding-left:20px; padding-top:10px;' >Invalid file format. Support .doc, .docx, .rtf, .html or .pdf formats</span>";
				//$this->_uploaderror.= "<span align='center' class='msg'>Invalid file format. Support .doc, .docx, .rtf, .html or .pdf formats</span>";				 
			}
			else
			{
					chmod('modules/ParseMyResume/data/'.$file,0777);
					unlink('modules/ParseMyResume/data/'.$file);
				
			}
			
			}
			else
			{
			 //$this->_uploaderror.= "<span align='center' class='msg'>Invalid file.Please upload file upto 1 MB size</span>";	
		
			}
		
		
	}
	
	}
}
	?>
