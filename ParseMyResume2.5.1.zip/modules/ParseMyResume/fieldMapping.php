<?php
/*********************************************************************************
 * ParseMyResume is helping SugarCRM customers to insert Resumes into ATS. 
 * ParseMyResume Copyright (C) 2011  - 2013 ParseMyResume.
 * 
 * This program is free/Subscription based  software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY ParseMyResume, ParseMyResume DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact ParseMyResume. headquarters at Suite 13, C-134, Phase 8
 * Industrial Area, Mohali, Punjab, 160062 India. or at email address support@parsemyresume.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 ********************************************************************************/?>
<script type='text/javascript'>
function GetSimilarMatchSugar()
{ 
var where_to= confirm("This action will map the similar fields and Sugar CRM. This will reset all your settings which cannot be reverted. Are you sure to proceed?");
 if (where_to== true)
 {
var VarExist="";
var i;
var j;

                ////////////////////////////////////////////Checked////////////////////////////////////////////////////
                 for (i=102;i<=212;i++)
                 {
					if(i==103 || i==119 ||i==105)
					{
					}
					else
					{
				
                           var BoolVal=false;
                           if(i<=212)
                           {
							 
								var a="ctl00_ContentPlaceHolder1_grd_ct_"+i;
                                var text = document.getElementById(a).cells[1].innerHTML;
                                var e =document.getElementById("ct_"+i);
                                var LengthDll= e.options.length; 
						
                                for (j=0;j<LengthDll;j++)
                                {
								
                                    var Reg=new RegExp('[0-9a-z-_\.]*'+text.toLowerCase().replace(" ","")+'[0-9a-z-_\.]*');
                                    if(Reg.test(e.options[j].text.toLowerCase().replace(" ",""))==true)
                                    {
									
                                        var RegCheckExist=new RegExp('[0-9a-z-_\.]*'+e.options[j].text.toLowerCase().replace(" ","")+'[0-9a-z-_\.]*')
                                        if(RegCheckExist.test(VarExist)==false)
                                        {
										
                                            if(e.options[j].text.toLowerCase().replace(" ","")=="status")
                                            {
                                            document.getElementById("ct_"+i).selectedIndex=0;
                                            document.getElementById("ck_"+i).checked=false;
                                            break;
                                            }
                                            VarExist+=e.options[j].text.toLowerCase().replace(" ","")+"`";
                                            document.getElementById("ct_"+i).selectedIndex=j;
                                            document.getElementById("ck_"+i).checked=true;
										
                                            if(document.getElementById("ck_"+i).disabled==true)
                                            {
                                            document.getElementById("ck_"+i).checked=false;
                                            }
                                            BoolVal=true; 
                                            break;
                                        }
                                    }
                                }
                                if(BoolVal==false)
                                {
                                document.getElementById("ct_"+i).selectedIndex=0;
                                document.getElementById("ck_"+i).checked=false;
                                }
             
                           }
						    else
                           {
                                var text = document.getElementById("ctl00_ContentPlaceHolder1_grd_ct_"+i).cells[1].innerHTML;
                                var e =document.getElementById("ct_"+i);
                                var LengthDll= e.options.length;              
                                for (j=0;j<LengthDll;j++)
                                {
                                    var RegExp1=new RegExp('[0-9a-z-_\.]*'+text.toLowerCase().replace(" ","")+'[0-9a-z-_\.]*');
                                    if(RegExp1.test(e.options[j].text.toLowerCase().replace(" ",""))==true)
                                    {
                                        var RegCheckExist=new RegExp('[0-9a-z-_\.]*'+e.options[j].text.toLowerCase().replace(" ","")+'[0-9a-z-_\.]*')
                                        if(RegCheckExist.test(VarExist)==false)
                                        {
                                            if(e.options[j].text.toLowerCase().replace(" ","")=="status")
                                            {
                                            document.getElementById("ct_"+i).selectedIndex=0;
                                            document.getElementById("ck_"+i).checked=false;
                                            break;
                                            }
                                            VarExist+=e.options[j].text.toLowerCase().replace(" ","")+"`";
                                            document.getElementById("ct_"+i).selectedIndex=j;
                                            document.getElementById("ck_"+i).checked=true;
                                            if(document.getElementById("ct_"+i).disabled==true)
                                            {
                                            document.getElementById("ck_"+i).checked=false;
                                            }
                                            BoolVal=true;
                                            break;
                                        }
                                    }
                                }
                                if(BoolVal==false)
                                {
                                document.getElementById("ct_"+i).selectedIndex=0;
                                document.getElementById("ck_"+i).checked=false;
                                }
                          
                           }        
                }
			}
                                  
}   

}
       
       


function CheckUnCheckGridSugar(id)
            {
			
            var strId;
            strId=id.replace("ct_","ck_")
            var DrpId=id;
				if(document.getElementById(id).selectedIndex==0)
				{
				
						document.getElementById(strId).checked=false;
				}
            else
            {
                    document.getElementById(strId).checked=true;
            }
			 
              for (i=102;i<212;i++)
                 { 
                          if(i<241)
                           {
                                if(document.getElementById("ck_"+i).checked==true)
                                {
                                   var VarCheckId="ct_"+i;
								   
                                    if(DrpId!=VarCheckId)
                                    {
                                          if(document.getElementById("ct_"+i).selectedIndex==document.getElementById(id).selectedIndex)
                                          {	
										    if(document.getElementById(id).selectedIndex!=0)
                                              {
                                                alert('This Field is already selected .Please select another field.');
                                                document.getElementById(DrpId).selectedIndex=0;
                                                document.getElementById(strId).checked=false;
                                                return false;
                                              }
                                            
                                          }
                                    }
                                }
                            }
				}
                         
                   
            if(document.getElementById(id).selectedIndex==0)
            {
           
                    document.getElementById(strId).checked=false;
            }
            else
            {
          
                    document.getElementById(strId).checked=true;
                    if(document.getElementById(id).selectedIndex > 0)
                      {
                           var strRow=id.replace("_drpSugar","")
                       //    document.getElementById(strRow).previous_color = document.getElementById(strRow).style.backgroundColor ;
                           document.getElementById(strRow).style.backgroundColor = document.getElementById(strRow).previous_color;
                          
                      }
            }
      }

	  function checkChanged(id,check="")
	  {
			var strId;
            strId=id;
            var DrpId=id.replace("ck_","ct_");
			if(document.getElementById(id).checked==false)
                                {
									document.getElementById(DrpId).selectedIndex=0;
								}
		
	  }

<!---------------------------------------------------------validation of not select drop down value------------------------------------------------------>
function dropdown_Blank()
{
	
	for(i=102;i<=212;i++)
	{
		
		checked=document.getElementById('ck_'+i);
		drop=document.getElementById('ct_'+i).value;
		
		if(checked.checked)
		{
			if(drop=="Select")
			{
				
				document.getElementById('ct_'+i).style.border="solid";
				document.getElementById('ctl00_ContentPlaceHolder1_grd_ct_'+i).style.backgroundColor="red";
				document.getElementById('error_wrapper').innerHTML="Please Map the  field you selected with Sugar CRM field";
				return false;	
				return false;	
			}
			else
			{
				
				document.getElementById('ct_'+i).style.border="";
				document.getElementById('ctl00_ContentPlaceHolder1_grd_ct_'+i).style.backgroundColor="";
				document.getElementById('ct_'+i).style.borderColor="";
					
			}
		}
		
		
	
	}return true;
	
}
function reset_Blank()
{
	
	for(i=102;i<=212;i++)
	{
				if(i==103 || i==119 ||i==105)
					{
					}
				else
				{
					  document.getElementById("ct_"+i).selectedIndex=0;
                      document.getElementById("ck_"+i).checked=false;
				}
	}
}	
<!---------------------------------------------------------end validation of not select drop down value------------------------------------------------------>

<!---------------------------------------------------------validation duplicate value in drop down------------------------------------------------------>
function duplicate_value(selected_Value,selected_id)
{
	for(i=102;i<=212;i++)
	{
		var drop_Value=document.getElementById('ct_'+i).value;
		var drop_id=document.getElementById('ct_'+i).id;
		if(selected_Value=='Select')
		{
			return true;
		}
		else if(selected_Value!='Select'&&drop_Value==selected_Value&&selected_id!=drop_id)
		{
			alert('Please Select Valid Value');
			return false;
		}
		
		
		
	}
}
<!---------------------------------------------------------end validation duplicate value in drop down------------------------------------------------------>
function autoCheck()
{ 

 for(i=102;i<212;i++)
 { 
 
				if(document.getElementById("ct_"+i).selectedIndex==0)
				{
					var sel = document.getElementById("ct_"+i);
						if ((sel.options[sel.selectedIndex].value == 'Email') || (sel.options[sel.selectedIndex].value == 'FirstName') || (sel.options[sel.selectedIndex].value == 'LastName'))
						{
							document.getElementById("ck_"+i).checked=true;
						}
						else
						{
						document.getElementById("ck_"+i).checked=false;
						}
				}
            else
            {
			
                    document.getElementById("ck_"+i).checked=true;

            }
}
}
  function ViewPopSugar()
    {

            confirm('This action will map the similar fields of ParseMyResume and Sugar CRM. This will reset all your settings which cannot be reverted. Are you sure to proceed?', 'ParseMyResume Says', function(r) {
						if(r==true){ GetSimilarMatchSugar();  }});
    }
</script>
<body onLoad="autoCheck()">
<?php
		 require_once('data/SugarBean.php');
		 $thisSugarBean = new SugarBean();
		 $lead_struct="DESCRIBE leads"; 
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc(); 
			 while($row2 = $lead_result->fetch_assoc())
			  {
				if($row2['Field']=="first_name" || $row2['Field']=="last_name" || $row2['Field']=="status")
				{
				}
				else
				{
				$leaddata[]=$row2['Field'];
				$lead_datatype[]=$row2['Type'];
				}
			
			  }				
			 $lead_custm_struct="DESCRIBE leads_cstm "; 
			 $lead_custm_struct_result=$thisSugarBean->db->query($lead_custm_struct,true);
			 $rowResult = $lead_custm_struct_result->fetch_assoc(); 
				 while($rowResult = $lead_custm_struct_result->fetch_assoc())
				  {
					$lead_custmdata[]=$rowResult['Field'];
					$lead_custm_datatype[]=$rowResult['Type'];
				
				  }
			  
			 $countElement=count($leaddata);
			 $countElement2=count($lead_custmdata);
			 $total=$countElement+$countElement2;
			 $option_list="";
			 $savedFieldMap="SELECT * FROM `ParseMyResume_field_mapping`";
			 $savedFieldMap_result=$thisSugarBean->db->query($savedFieldMap,true);
			 
				 while($savedrowResult = $savedFieldMap_result->fetch_assoc())
				  {
					
				  	$saved_data[$savedrowResult['ParseMyResume_field']]=$savedrowResult['sugar_field'];
				  }
				
?>
<?php
 
		 $lead_struct1="select * from ParseMyResume_field_mapping";
 
		 
$lead_result1=$thisSugarBean->db->query($lead_struct1,true);

while($row2 = $lead_result1->fetch_assoc())
			  {
				 $leaddata1[]=$row2['sugar_field'];
			 }
			
	
			  $countMapping=count($leaddata1);
?>
<script src="modules/ParseMyResume/js/ajxsmt.js" type="text/javascript"></script>
<div align="center">
<table class="mGrid" cellspacing="0" cellpadding="4" border="0" id="ctl00_ContentPlaceHolder1_grd" style="color:#999966;border-color:Black;borderstyle:Solid;width:782px;bordercollapse:collapse;">
  <tr>
    <td colspan=2 align="center"><image src="modules/ParseMyResume/images/ParseMyResume.png"></td>
  </tr>
  <tr>
    <td align="center" style="color:white;background-color:#646464;font-size:16pt;height:30px;padding-left:5px;" colspan="2"> Field Mapping </td>
  </tr>
</table>
<form action="index.php?module=ParseMyResume&action=mappingData" method="post" name="uploadform" enctype="multipart/formdata" onsubmit="xmlhttpPost('index.php?module=ParseMyResume&action=mappingData', 'uploadform', 'error_wrapper', '<center><img src=\'modules/ParseMyResume/images/processing.gif\' align=\'center\'></center>'); return false;">
<table class="mGrid" cellspacing="0" cellpadding="4" border="0" id="ctl00_ContentPlaceHolder1_grd" style="color:#999966;border-color:Black;borderstyle:Solid;width:782px;bordercollapse:collapse;">
  <tr>
    <td colspan=2><font color="red">*Mandatory Fields: Email, FirstName, LastName
      </p></td>
    <td colspan=2 align="right" style="padding:10px;"><img  onclick="GetSimilarMatchSugar();" id="ctl00_ContentPlaceHolder1_ImgSugar" src="modules/ParseMyResume/images/get_similar.gif"></td>
  </tr>
  <tr id="PERSONAL DETAILS" style="color:Green;background-color:LightSkyBlue;fontsize:16pt;height:30px;">
    <td align="right"><span  style="display:none;"> </td>
    <td align="left">PERSONAL DETAILS</td>
    <td align="right"></td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_103" style="color:#284775;background-color:White;" disabled="disabled">
    <td align="right"><span >
      <input id="ck_103"  type="checkbox" name="FirstName" checked="checked" disabled="disabled" />
      </span> </span> </td>
    <td align="left">FirstName</td>
    <td align="right"><select name="ctl04_FirstName" id="ct_103" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="FirstName" selected="selected">first_name</option>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_104" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_104" type="checkbox" name="Middlename"   onclick="return checkChanged(this.id);" />
      </span> </td>
    <td align="left">Middlename</td>
    <td align="right"><select name="ctl04_Middlename" id="ct_104" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++)
{
																	
																		if($leaddata[$i]==$saved_data['Middlename'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option value=".$i.">".$leaddata[$i]."</option>";}}
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['Middlename'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_105" style="color:#284775;background-color:White;" disabled="disabled">
    <td align="right"><span  >
      <input id="ck_105"   type="checkbox" name="LastName"  checked  disabled="disabled"/>
      </span> </td>
    <td align="left">LastName</td>
    <td align="right"><select name="ctl04_LastName" id="ct_105" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="LastName" selected="selected">last_Name</option>
      </select></td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_106" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_106" type="checkbox" name="DateOfBirth" onClick="return checkChanged(this.id);" />
      </span> </td>
    <td align="left">DateOfBirth</td>
    <td align="right"><select name="ctl04_DateOfBirth" id="ct_106" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php

$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['DateOfBirth'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option value=".$i.">".$leaddata[$i]."</option>";}}
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['DateOfBirth'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
																

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_107" style="color:#284775;background-color:White;">
    <td align="right"><span >
      <input id="ck_107" type="checkbox" name="Gender" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Gender</td>
    <td align="right"><select name="ctl04_Gender" id="ct_107" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['Gender'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option value=".$i.">".$leaddata[$i]."</option>";}}
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['Gender'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}

?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_108" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_108" type="checkbox" name="PassportNo" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">PassportNo</td>
    <td align="right"><select name="ctl04_PassportNo" id="ct_108" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php

$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['PassportNo'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																		else{echo "<option value=".$i.">".$leaddata[$i]."</option>";}}
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['PassportNo'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
																	

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}

?>
      </select>
    </td>
    <td align="right">
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_109" style="color:#284775;background-color:White;">
    <td align="right"><span >
      <input id="ck_109" type="checkbox" name="LicenseNo" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">LicenseNo</td>
    <td align="right"><select name="ctl04_LicenseNo" id="ct_109" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php

$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['LicenseNo'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option value=".$i.">".$leaddata[$i]."</option>";}}
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['LicenseNo'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_110" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_110" type="checkbox" name="Nationality" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Nationality</td>
    <td align="right"><select name="ctl04_Nationality" id="ct_110" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php

$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['Nationality'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	else{echo "<option value=".$i.">".$leaddata[$i]."</option>";}}
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['Nationality'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_111" style="color:#284775;background-color:White;">
    <td align="right"><span >
      <input id="ck_111" type="checkbox" name="MaritalStatus" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">MaritalStatus</td>
    <td align="right"><select name="ctl04_MaritalStatus" id="ct_111" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['MaritalStatus'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option value=".$i.">".$leaddata[$i]."</option>";}}
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['MaritalStatus'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_112" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_112" type="checkbox" name="FatherName" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">FatherName</td>
    <td align="right"><select name="ctl04_FatherName" id="ct_112" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php

$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['FatherName'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																		else{echo "<option value=".$i.">".$leaddata[$i]."</option>";}}
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['FatherName'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
																	

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
      </select>
    </td>
    <td align="right">
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_113" style="color:#284775;background-color:White;">
    <td align="right"><span >
      <input id="ck_113" type="checkbox" name="MotherName" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">MotherName</td>
    <td align="right"><select name="ctl04_MotherName" id="ct_113" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php

$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['MotherName'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	else{echo "<option value=".$i.">".$leaddata[$i]."</option>";}}
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['MotherName'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_114" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_114" type="checkbox" name="LanguageKnown" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">LanguageKnown</td>
    <td align="right"><select name="ctl04_LanguageKnown" id="ct_114" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php

$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['LanguageKnown'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option value=".$i.">".$leaddata[$i]."</option>";}}
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['LanguageKnown'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_115" style="color:#284775;background-color:White;">
    <td align="right"><span >
      <input id="ck_115" type="checkbox" name="Hobbies" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Hobbies</td>
    <td align="right"><select name="ctl04_Hobbies" id="ct_115" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php

$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['Hobbies'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																
																	else{echo "<option value=".$i.">".$leaddata[$i]."</option>";}}
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['Hobbies'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
      </select>
    </td>
  </tr>

  <tr id="ContactDetail" style="color:Yellow;background-color:LightSkyBlue;fontsize:16pt;height:30px;">
    <td align="right"><span  style="display:none;">
      <input id="ctl00_ContentPlaceHolder1_grd_ct_116_CheckBox1" type="checkbox" name="CONTACT DETAILS" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">CONTACT DETAILS</td>
    <td align="right"></td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_116" style="color:#284775;background-color:White;">
    <td align="right"><span >
      <input id="ck_116" checked type="checkbox" name="Address" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Address</td>
    <td align="right"><select name="ctl04_Address" id="ct_116" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php

$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['Address'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																
						

																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['Address'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_102" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_102" checked type="checkbox" name="City" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">City</td>
    <td align="right"><select name="ctl04_City" id="ct_102" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['City'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}

																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['City'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_117" style="color:#284775;background-color:White;">
    <td align="right"><?php
	 foreach($leaddata1 as $leaddata2){
	if($leaddata2=='primary_address_state'){
		$state='Yes';
	}
	 }

	?>
      <span >
      <input id="ck_117" checked type="checkbox" name="State" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">State</td>
    <td align="right"><select name="ctl04_State" id="ct_117" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['State'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	


																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['State'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
					
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}

?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_118" style="color:#333333;background-color:'white';">
    <td align="right"><?php
	 foreach($leaddata1 as $leaddata2){
	if($leaddata2=='primary_address_postalcode'){
		$postal='Yes';
	}
	 }

	?>
      <span >
      <input id="ck_118" checked type="checkbox" name="ZipCode" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">ZipCode</td>
    <td align="right"><select name="ctl04_ZipCode" id="ct_118" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php

$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['ZipCode'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
													
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['ZipCode'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}

?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_119" style="color:#284775;background-color:White;">
    <td align="right"><span >
      <input id="ck_119" type="checkbox" name="Email"  onclick="return checkChanged(this.id,this);" disabled="disabled" />
      </span> </td>
    <td align="left">Email</td>
    <td align="right"><select name="ctl04_Email" id="ct_119"   style="width:230px;" />
      
      <option value="Email" selected='selected'>Email</option>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_120" style="color:#333333;background-color:'white';">
    <td align="right"><?php
	 foreach($leaddata1 as $leaddata2){
	if($leaddata2=='phone_home'){
		$phone='Yes';
	}
	 }

	?>
      <span >
      <input id="ck_120" checked type="checkbox" name="Phone"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Phone</td>
    <td align="right"><select name="ctl04_Phone" id="ct_120" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php

$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['Phone'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	

																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['Phone'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}

?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_121" style="color:#284775;background-color:White;">
    <td align="right"><?php
	 foreach($leaddata1 as $leaddata2){
	if($leaddata2=='phone_mobile'){
		$mobile='Yes';
	}
	 }

	?>
      <span >
      <input id="ck_121" checked type="checkbox" name="Mobile"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Mobile</td>
    <td align="right"><select name="ctl04_Mobile" id="ct_121" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php

$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['Mobile'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}

																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['Mobile'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}

?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_122" style="color:#333333;background-color:'white';">
    <td align="right"><?php
	 foreach($leaddata1 as $leaddata2){
	if($leaddata2=='phone_fax'){
		$fax='Yes';
	}
	 }

	?>
      <span >
      <input id="ck_122" checked type="checkbox" name="FaxNo" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">FaxNo</td>
    <td align="right"><select name="ctl04_FaxNo" id="ct_122" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php

$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['FaxNo'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}

																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['FaxNo'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
      </select>
    </td>
  </tr>
  <tr id="EDUCATION DETAILS" style="color:Yellow;background-color:LightSkyBlue;fontsize:16pt;height:30px;">
    <td align="right"><span  style="display:none;">
      <input id="ctl00_ContentPlaceHolder1_grd_ct_125_CheckBox1" type="checkbox" name="EDUCATION DETAILS" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">EDUCATION DETAILS</td>
    <td align="right"></td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_123" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_123" type="checkbox" name="Qualification" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Qualification</td>
    <td align="right"><select name="ctl04_Qualification" id="ct_123" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php


$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['Qualification'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}

																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['Qualification'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_124" style="color:#284775;background-color:White;">
    <td align="right"><span >
      <input id="ck_124" type="checkbox" name="University1"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">University1</td>
    <td align="right"><select name="ctl04_University1" id="ct_124" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['University1'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}

																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['University1'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
        
?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_125" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_125" type="checkbox" name="Degree1"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Degree1</td>
    <td align="right"><select name="ctl04_Degree1" id="ct_125" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php

$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['Degree1'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['Degree1'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_126" style="color:#284775;background-color:White;">
    <td align="right"><span >
      <input id="ck_126" type="checkbox" name="Year1" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Year1</td>
    <td align="right"><select name="ctl04_Year1" id="ct_126" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php

$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['Year1'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}

																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['Year1'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_127" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_127" type="checkbox" name="University2" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">University2</td>
    <td align="right"><select name="ctl04_University2" id="ct_127" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php


$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['University2'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}

																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['University2'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}

?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_128" style="color:#284775;background-color:White;">
    <td align="right"><span >
      <input id="ck_128" type="checkbox" name="Degree2"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Degree2</td>
    <td align="right"><select name="ctl04_Degree2" id="ct_128" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['Degree2'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																	if($lead_custmdata[$j]==$saved_data['Degree2'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
															
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_129" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_129" type="checkbox" name="Year2" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Year2</td>
    <td align="right"><select name="ctl04_Year2" id="ct_129" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['Year2'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}

																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['Year2'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_130" style="color:#284775;background-color:White;">
    <td align="right"><span >
      <input id="ck_130" type="checkbox" name="University3" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">University3</td>
    <td align="right"><select name="ctl04_University3" id="ct_130" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php

$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['University3'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}

																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['University3'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_131" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_131" type="checkbox" name="Degree3" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Degree3</td>
    <td align="right"><select name="ctl04_Degree3" id="ct_131" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['Degree3'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}

																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['Degree3'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_132" style="color:#284775;background-color:White;">
    <td align="right"><span >
      <input id="ck_132" type="checkbox" name="Year3" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Year3</td>
    <td align="right"><select name="ctl04_Year3" id="ct_132" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['Year3'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}

																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['Year3'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_133" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_133" type="checkbox" name="Category" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Category</td>
    <td align="right"><select name="ctl04_Category" id="ct_133" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php

$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['Category'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['Category'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_134" style="color:#284775;background-color:White;">
    <td align="right"><span >
      <input id="ck_134" type="checkbox" name="SubCategory" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">SubCategory</td>
    <td align="right"><select name="ctl04_SubCategory" id="ct_134" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php


$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['SubCategory'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['SubCategory'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_135" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_135" type="checkbox" name="Skills"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Skills</td>
    <td align="right"><select name="ctl04_Skills" id="ct_135" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['Skills'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['Skills'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}?>
      </select>
    </td>
  </tr>
  <tr id="EMPLOYMENT DETAILS" style="color:Yellow;background-color:LightSkyBlue;fontsize:16pt;height:30px;">
    <td align="right"><span  style="display:none;">
      <input id="ctl00_ContentPlaceHolder1_grd_ct_139_CheckBox1" type="checkbox" name="EMPLOYMENT DETAILS" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">EMPLOYMENT DETAILS</td>
    <td align="right"><select name="ctl04_EMPLOYMENT DETAILS" id="ctl00_ContentPlaceHolder1_grd_ct_139_DropDownList1" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;display:none;">
        <option value="Select">Select</option>
        <?php


?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_136" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_136" type="checkbox" name="Experience"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Experience</td>
    <td align="right"><select name="ctl04_Experience" id="ct_136" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php

$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['Experience'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}

																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['Experience'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_137" style="color:#284775;background-color:White;">
    <td align="right"><span >
      <input id="ck_137" type="checkbox" name="CurrentEmployer"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">CurrentEmployer</td>
    <td align="right"><select name="ctl04_CurrentEmployer" id="ct_137" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['CurrentEmployer'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['CurrentEmployer'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_138" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_138" type="checkbox" name="JobProfile"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">JobProfile</td>
    <td align="right"><select name="ctl04_JobProfile" id="ct_138" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['JobProfile'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['JobProfile'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																									
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_139" style="color:#284775;background-color:White;">
    <td align="right"><span >
      <input id="ck_139" type="checkbox" name="CurrentSalary"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">CurrentSalary</td>
    <td align="right"><select name="ctl04_CurrentSalary" id="ct_139" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php

$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['CurrentSalary'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['CurrentSalary'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
														
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_140" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_140" type="checkbox" name="ExpectedSalary"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">ExpectedSalary</td>
    <td align="right"><select name="ctl04_ExpectedSalary" id="ct_140" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['ExpectedSalary'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['ExpectedSalary'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_141" style="color:#284775;background-color:White;">
    <td align="right"><span >
      <input id="ck_141" type="checkbox" name="Employer1"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Employer1</td>
    <td align="right"><select name="ctl04_Employer1" id="ct_141" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['Employer1'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['Employer1'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_142" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_142" type="checkbox" name="JobProfile1"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">JobProfile1</td>
    <td align="right"><select name="ctl04_JobProfile1" id="ct_142" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php

$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['JobProfile1'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['JobProfile1'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_143" style="color:#284775;background-color:White;">
    <td align="right"><span >
      <input id="ck_143" type="checkbox" name="JobPeriod1"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">JobPeriod1</td>
    <td align="right"><select name="ctl04_JobPeriod1" id="ct_143" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['JobPeriod1'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){


																		if($lead_custmdata[$j]==$saved_data['JobPeriod1'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																																		
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_144" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_144" type="checkbox" name="JobLocation1" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">JobLocation1</td>
    <td align="right"><select name="ctl04_JobLocation1" id="ct_144" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['JobLocation1'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																	if($lead_custmdata[$j]==$saved_data['JobLocation1'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_145" style="color:#284775;background-color:White;">
    <td align="right"><span >
      <input id="ck_145" type="checkbox" name="StartDate1"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">StartDate1</td>
    <td align="right"><select name="ctl04_StartDate1" id="ct_145" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['StartDate1'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}

																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['StartDate1'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_146" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_146" type="checkbox" name="EndDate1"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">EndDate1</td>
    <td align="right"><select name="ctl04_EndDate1" id="ct_146" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php

$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['EndDate1'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}

																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['EndDate1'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_147" style="color:#284775;background-color:White;">
    <td align="right"><span >
      <input id="ck_147" type="checkbox" name="JobDescription1"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">JobDescription1</td>
    <td align="right"><select name="ctl04_JobDescription1" id="ct_147" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['JobDescription1'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}

																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['JobDescription1'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}
?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_148" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_148" type="checkbox" name="Employer2"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Employer2</td>
    <td align="right"><select name="ctl04_Employer2" id="ct_148" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <option value="1" style="Background:#000000" disabled="disabled">EmailFields</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['Employer2'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}

																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['Employer2'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_149" style="color:#284775;background-color:White;">
    <td align="right"><span >
      <input id="ck_149" type="checkbox" name="JobProfile2"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">JobProfile2</td>
    <td align="right"><select name="ctl04_JobProfile2" id="ct_149" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['JobProfile2'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}

																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['JobProfile2'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_150" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_150" type="checkbox" name="JobPeriod2"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">JobPeriod2</td>
    <td align="right"><select name="ctl04_JobPeriod2" id="ct_150" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['JobPeriod2'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}

																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['JobPeriod2'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_151" style="color:#284775;background-color:White;">
    <td align="right"><span >
      <input id="ck_151" type="checkbox" name="JobLocation2" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">JobLocation2</td>
    <td align="right"><select name="ctl04_JobLocation2" id="ct_151" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['JobLocation2'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}

																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['JobLocation2'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_152" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_152" type="checkbox" name="StartDate2"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">StartDate2</td>
    <td align="right"><select name="ctl04_StartDate2" id="ct_152" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['StartDate2'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['StartDate2'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_153" style="color:#284775;background-color:White;">
    <td align="right"><span >
      <input id="ck_153" type="checkbox" name="EndDate2"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">EndDate2</td>
    <td align="right"><select name="ctl04_EndDate2" id="ct_153" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['EndDate2'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}

																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['EndDate2'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
															
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_154" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_154" type="checkbox" name="JobDescription2"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">JobDescription2</td>
    <td align="right"><select name="ctl04_JobDescription2" id="ct_154" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['JobDescription2'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																	if($lead_custmdata[$j]==$saved_data['JobDescription2'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_155" style="color:#284775;background-color:White;">
    <td align="right"><span >
      <input id="ck_155" type="checkbox" name="Employer3"  onclick="return checkChanged(this.id,this);" />

      </span> </td>
    <td align="left">Employer3</td>
    <td align="right"><select name="ctl04_Employer3" id="ct_155" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['Employer3'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}

																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['Employer3'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_156" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_156" type="checkbox" name="JobProfile3"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">JobProfile3</td>
    <td align="right"><select name="ctl04_JobProfile3" id="ct_156" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['JobProfile3'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['JobProfile3'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_157" style="color:#284775;background-color:White;">
    <td align="right"><span >
      <input id="ck_157" type="checkbox" name="JobPeriod3"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">JobPeriod3</td>
    <td align="right"><select name="ctl04_JobPeriod3" id="ct_157" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['JobPeriod3'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}

																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['JobPeriod3'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_158" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_158" type="checkbox" name="JobLocation3" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">JobLocation3</td>
    <td align="right"><select name="ctl04_JobLocation3" id="ct_158" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['JobLocation3'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['JobLocation3'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_159" style="color:#284775;background-color:White;">
    <td align="right"><span >
      <input id="ck_159" type="checkbox" name="StartDate3"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">StartDate3</td>
    <td align="right"><select name="ctl04_StartDate3" id="ct_159" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['StartDate3'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['StartDate3'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_160" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_160" type="checkbox" name="EndDate3"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">EndDate3</td>
    <td align="right"><select name="ctl04_EndDate3" id="ct_160" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['EndDate3'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['EndDate3'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_161" style="color:#284775;background-color:White;">
    <td align="right"><span >
      <input id="ck_161" type="checkbox" name="JobDescription3"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">JobDescription3</td>
    <td align="right"><select name="ctl04_JobDescription3" id="ct_161" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['JobDescription3'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['JobDescription3'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
	else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_162" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_162" type="checkbox" name="Experience_Year"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Experience_Year</td>
    <td align="right"><select name="ctl04_Experience_Year" id="ct_162" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['Experience_Year'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['Experience_Year'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}

else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_163" style="color:#284775;background-color:White;">
    <td align="right"><span >
      <input id="ck_163" type="checkbox" name="Experience_Months"  onclick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Experience_Months</td>
    <td align="right"><select name="ctl04_Experience_Months" id="ct_163" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['Experience_Months'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['Experience_Months'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
    < </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_164" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_164" type="checkbox" name="GapPeriod" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">GapPeriod</td>
    <td align="right"><select name="ctl04_GapPeriod" id="ct_164" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){
																		if($leaddata[$i]==$saved_data['GapPeriod'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){
																		if($lead_custmdata[$j]==$saved_data['GapPeriod'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  
  
   <tr id="OTHER DETAILS" style="color:Yellow;background-color:LightSkyBlue;fontsize:16pt;height:30px;">
    <td align="right"><span  style="display:none;">
      <input id="ctl00_ContentPlaceHolder1_grd_ct_169_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl69$CheckBox1" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">OTHER DETAILS</td>
    <td align="right"></td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_165" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_165" type="checkbox" name="Objectives" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Objectives</td>
    <td align="right"><select name="ctl04_Objectives" id="ct_165" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['Objectives'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['Objectives'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_166" style="color:#284775;background-color:White;">
    <td align="right"><span >
      <input id="ck_166" type="checkbox" name="Achievements" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Achievements</td>
    <td align="right"><select name="ctl04_Achievements" id="ct_166" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['Achievements'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																		else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['Achievements'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		
																		}
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_167" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_167" type="checkbox" name="References" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">References</td>
    <td align="right"><select name="ctl04_References" id="ct_167" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['References'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['References'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_168" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_168" type="checkbox" name="DetailResume" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">DetailResume</td>
    <td align="right"><select name="ctl04_DetailResume" id="ct_168" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['DetailResume'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['DetailResume'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  
  
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_169" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_169" type="checkbox" name="htmlresume" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">htmlresume</td>
    <td align="right"><select name="ctl04_htmlresume" id="ct_169" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['htmlresume'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['htmlresume'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_170" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_170" type="checkbox" name="WillingToRelocate" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Willing  to relocate(String/  Boolean) </td>
    <td align="right"><select name="ctl04_WillingToRelocate" id="ct_170" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['WillingToRelocate'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['WillingToRelocate'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_171" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_171" type="checkbox" name="JobType" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Job  Type</td>
    <td align="right"><select name="ctl04_JobType" id="ct_171" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['JobType'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['JobType'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>

 <tr id="ctl00_ContentPlaceHolder1_grd_ct_172" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_172" type="checkbox" name="PreferredWorkLocation" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Preferred  Work Location </td>
    <td align="right"><select name="ctl04_PreferredWorkLocation" id="ct_172" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['PreferredWorkLocation'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['PreferredWorkLocation'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  
   <tr id="ctl00_ContentPlaceHolder1_grd_ct_173" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_173" type="checkbox" name="CandidateImageData" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Candidate Picture </td>
    <td align="right"><select name="ctl04_CandidateImageData" id="ct_173" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['CandidateImageData'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['CandidateImageData'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  
  
  
  
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_174" style="color:Yellow;background-color:LightSkyBlue;fontsize:16pt;height:30px;">
    <td align="right"><span  style="display:none;">
       <input id="ck_174" type="checkbox" name="LinkedInLink" onClick="return checkChanged(this.id,this);" />
       <select name="ctl04_LinkedInLink" id="ct_174" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
       </select>
      </span> </td>
    <td align="left">Social Profile</td>
    <td align="right"></td>
  </tr>
  
  
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_175" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_175" type="checkbox" name="LinkedInLink" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">LinkedIn Link</td>
    <td align="right"><select name="ctl04_LinkedInLink" id="ct_175" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['LinkedInLink'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['LinkedInLink'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>



  <tr id="ctl00_ContentPlaceHolder1_grd_ct_176" style="color:#284775;background-color:White;">
    <td align="right"><span >
      <input id="ck_176" type="checkbox" name="LinkedInImageURL" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">LinkedIn Image URL</td>
    <td align="right"><select name="ctl04_LinkedInImageURL" id="ct_176" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['LinkedInImageURL'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																		else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['LinkedInImageURL'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		
																		}
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_178" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_178" type="checkbox" name="LinkedInDesignation" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">LinkedIn Designation</td>
    <td align="right"><select name="ctl04_LinkedInDesignation" id="ct_178" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['LinkedInDesignation'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['LinkedInDesignation'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_179" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_179" type="checkbox" name="LinkedInCompamy" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">LinkedInCompamy</td>
    <td align="right"><select name="ctl04_LinkedInCompamy" id="ct_179" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['LinkedInCompamy'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['LinkedInCompamy'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_180" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_180" type="checkbox" name="LinkedInLocation" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">LinkedIn Location</td>
    <td align="right"><select name="ctl04_LinkedInLocation" id="ct_180" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['LinkedInLocation'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['LinkedInLocation'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>

  <tr id="ctl00_ContentPlaceHolder1_grd_ct_181" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_181" type="checkbox" name="LinkedInMembership" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">LinkedIn Membership</td>
    <td align="right"><select name="ctl04_LinkedInMembership" id="ct_181" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['LinkedInMembership'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['LinkedInMembership'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>

  <tr id="ctl00_ContentPlaceHolder1_grd_ct_182" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_182" type="checkbox" name="FacebookImageURL" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Facebook Image URL</td>
    <td align="right"><select name="ctl04_FacebookImageURL" id="ct_182" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['FacebookImageURL'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['FacebookImageURL'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>

  

  <tr id="ctl00_ContentPlaceHolder1_grd_ct_183" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_183" type="checkbox" name="FacebookName" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Facebook Name</td>
    <td align="right"><select name="ctl04_FacebookName" id="ct_183" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['FacebookName'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['FacebookName'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>

  <tr id="ctl00_ContentPlaceHolder1_grd_ct_184" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_184" type="checkbox" name="FacebookLink" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Facebook Link</td>
    <td align="right"><select name="ctl04_FacebookLink" id="ct_184" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['FacebookLink'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['FacebookLink'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>

  <tr id="ctl00_ContentPlaceHolder1_grd_ct_185" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_185" type="checkbox" name="FacebookGender" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Facebook Gender</td>
    <td align="right"><select name="ctl04_FacebookGender" id="ct_185" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['FacebookGender'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['FacebookGender'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>

  <tr id="ctl00_ContentPlaceHolder1_grd_ct_186" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_186" type="checkbox" name="FacebookEmail" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Facebook Email</td>
    <td align="right"><select name="ctl04_FacebookEmail" id="ct_186" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['FacebookEmail'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['FacebookEmail'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>

  <tr id="ctl00_ContentPlaceHolder1_grd_ct_187" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_187" type="checkbox" name="FacebookTimezone" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Facebook Timezone</td>
    <td align="right"><select name="ctl04_FacebookTimezone" id="ct_187" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['FacebookTimezone'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['FacebookTimezone'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>

  <tr id="ctl00_ContentPlaceHolder1_grd_ct_188" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_188" type="checkbox" name="TwitterImageURL" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Twitter Image URL</td>
    <td align="right"><select name="ctl04_TwitterImageURL" id="ct_188" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['TwitterImageURL'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['TwitterImageURL'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>

  <tr id="ctl00_ContentPlaceHolder1_grd_ct_189" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_189" type="checkbox" name="TwitterLink" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Twitter Link</td>
    <td align="right"><select name="ctl04_TwitterLink" id="ct_189" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['TwitterLink'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['TwitterLink'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
 <tr id="ctl00_ContentPlaceHolder1_grd_ct_211" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_211" type="checkbox" name="TwitterUserid" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Twitter UserId</td>
    <td align="right"><select name="ctl04_TwitterUserid" id="ct_211" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['TwitterUserid'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['TwitterUserid'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_190" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_190" type="checkbox" name="TwitterName" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Twitter Name</td>
    <td align="right"><select name="ctl04_TwitterName" id="ct_190" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['TwitterName'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['TwitterName'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>

  

  <tr id="ctl00_ContentPlaceHolder1_grd_ct_191" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_191" type="checkbox" name="TwitterTotalFriend" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Twitter Total Friend</td>
    <td align="right"><select name="ctl04_TwitterTotalFriend" id="ct_191" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['TwitterTotalFriend'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['TwitterTotalFriend'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  <tr id="ctl00_ContentPlaceHolder1_grd_ct_192" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_192" type="checkbox" name="TwitterFollowers" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Twitter Followers</td>
    <td align="right"><select name="ctl04_TwitterFollowers" id="ct_192" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['TwitterFollowers'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['TwitterFollowers'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>

  <tr id="ctl00_ContentPlaceHolder1_grd_ct_193" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_193" type="checkbox" name="TwitterLocation" onClick="return checkChanged(this.id,this);" />

      </span> </td>
    <td align="left">Twitter Location</td>
    <td align="right"><select name="ctl04_TwitterLocation" id="ct_193" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['TwitterLocation'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	

for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['TwitterLocation'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>

  <tr id="ctl00_ContentPlaceHolder1_grd_ct_194" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_194" type="checkbox" name="TwitterCreatedDate" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Twitter Created Date</td>
    <td align="right"><select name="ctl04_TwitterCreatedDate" id="ct_194" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['TwitterCreatedDate'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['TwitterCreatedDate'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>

  <tr id="ctl00_ContentPlaceHolder1_grd_ct_195" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_195" type="checkbox" name="GoogleImageURL" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Google Image URL</td>
    <td align="right"><select name="ctl04_GoogleImageURL" id="ct_195" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['GoogleImageURL'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['GoogleImageURL'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>

  <tr id="ctl00_ContentPlaceHolder1_grd_ct_196" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_196" type="checkbox" name="GoogleLink" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Google Link</td>
    <td align="right"><select name="ctl04_GoogleLink" id="ct_196" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['GoogleLink'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['GoogleLink'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
  
<tr id="ctl00_ContentPlaceHolder1_grd_ct_197" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_197" type="checkbox" name="GoogleName" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Google Name</td>
    <td align="right"><select name="ctl04_GoogleName" id="ct_197" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['GoogleName'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['GoogleName'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>
<tr id="ctl00_ContentPlaceHolder1_grd_ct_212" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_212" type="checkbox" name="GoogleUserid" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Google UserId</td>
    <td align="right"><select name="ctl04_GoogleUserid" id="ct_212" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['GoogleUserid'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['GoogleUserid'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>



<tr id="ctl00_ContentPlaceHolder1_grd_ct_198" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_198" type="checkbox" name="GoogleKind" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Google Kind</td>
    <td align="right"><select name="ctl04_GoogleKind" id="ct_198" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['GoogleKind'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['GoogleKind'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>

<tr id="ctl00_ContentPlaceHolder1_grd_ct_199" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_199" type="checkbox" name="GoogleGender" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Google Gender</td>
    <td align="right"><select name="ctl04_GoogleGender" id="ct_199" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['GoogleGender'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['GoogleGender'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>

<tr id="ctl00_ContentPlaceHolder1_grd_ct_200" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_200" type="checkbox" name="SkypeImageURL" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Skype  Image URL</td>
    <td align="right"><select name="ctl04_SkypeImageURL" id="ct_200" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['SkypeImageURL'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['SkypeImageURL'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>

<tr id="ctl00_ContentPlaceHolder1_grd_ct_201" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_201" type="checkbox" name="SkypeName" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Skype Name</td>
    <td align="right"><select name="ctl04_SkypeName" id="ct_201" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['SkypeName'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['SkypeName'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>

<tr id="ctl00_ContentPlaceHolder1_grd_ct_202" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_202" type="checkbox" name="SkypeLink" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Skype Link</td>
    <td align="right"><select name="ctl04_SkypeLink" id="ct_202" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['SkypeLink'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['SkypeLink'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>

<tr id="ctl00_ContentPlaceHolder1_grd_ct_203" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_203" type="checkbox" name="YoutubeName" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Youtube Name</td>
    <td align="right"><select name="ctl04_YoutubeName" id="ct_203" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['YoutubeName'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['YoutubeName'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>

<tr id="ctl00_ContentPlaceHolder1_grd_ct_204" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_204" type="checkbox" name="YoutubeImageURl" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Youtube Image URL</td>
    <td align="right"><select name="ctl04_YoutubeImageURl" id="ct_204" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['YoutubeImageURl'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['YoutubeImageURl'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>

<tr id="ctl00_ContentPlaceHolder1_grd_ct_205" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_205" type="checkbox" name="YoutubeLink" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Youtube Link</td>
    <td align="right"><select name="ctl04_YoutubeLink" id="ct_205" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['YoutubeLink'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['YoutubeLink'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>

<tr id="ctl00_ContentPlaceHolder1_grd_ct_206" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_206" type="checkbox" name="PersonalWebsiteName" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Personal  Website Name</td>
    <td align="right"><select name="ctl04_PersonalWebsiteName" id="ct_206" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['PersonalWebsiteName'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['PersonalWebsiteName'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>

<tr id="ctl00_ContentPlaceHolder1_grd_ct_207" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_207" type="checkbox" name="PersonalWebsiteLink" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Personal  Website Link</td>
    <td align="right"><select name="ctl04_PersonalWebsiteLink" id="ct_207" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['PersonalWebsiteLink'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['PersonalWebsiteLink'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>

<tr id="ctl00_ContentPlaceHolder1_grd_ct_208" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_208" type="checkbox" name="PersonalBlogName" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Personal  Blog Name</td>
    <td align="right"><select name="ctl04_PersonalBlogName" id="ct_208" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['PersonalBlogName'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['PersonalBlogName'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>

<tr id="ctl00_ContentPlaceHolder1_grd_ct_209" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_209" type="checkbox" name="PersonalBlogImageURL" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Personal Blog Image URL</td>
    <td align="right"><select name="ctl04_PersonalBlogImageURL" id="ct_209" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['PersonalBlogImageURL'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['PersonalBlogImageURL'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>

<tr id="ctl00_ContentPlaceHolder1_grd_ct_210" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_210" type="checkbox" name="PersonalBlogLink" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Personal Blog Link</td>
    <td align="right"><select name="ctl04_PersonalBlogLink" id="ct_210" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['PersonalBlogLink'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['PersonalBlogLink'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>



<tr id="ctl00_ContentPlaceHolder1_grd_ct_177" style="color:#333333;background-color:'white';">
    <td align="right"><span >
      <input id="ck_177" type="checkbox" name="PersonalWebsiteImageURL" onClick="return checkChanged(this.id,this);" />
      </span> </td>
    <td align="left">Personal Website Image URL</td>
    <td align="right"><select name="ctl04_PersonalWebsiteImageURL" id="ct_177" onChange="return CheckUnCheckGridSugar(this.id);"  style="width:230px;">
        <option value="Select">Select</option>
        <?php
$countElement=count($leaddata);for($i=3;$i<$countElement;$i++){

																		if($leaddata[$i]==$saved_data['PersonalWebsiteImageURL'])
																		{
																			echo "<option selected='selected' value=".$i.">".$leaddata[$i]."</option>";
																		}
																	
																	else{echo "<option  value=".$i.">".$leaddata[$i]."</option>";}} 
																	
for($j=0;$j<$countElement2;$j++){

																		if($lead_custmdata[$j]==$saved_data['PersonalWebsiteImageURL'])
																		{
																			echo "<option selected='selected' value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;
																		}
																	
else {echo "<option value=".$countElement.">".$lead_custmdata[$j]."</option>";$countElement++;}}


?>
      </select>
    </td>
  </tr>

  
  <tr>
    <td colspan=3 align="right"><input type="submit" style="background:url(modules/ParseMyResume/images/save.gif); border:none;background-repeat:no-repeat; width:73px; height:30px; margin-top:7px;" value="" id="submit" onClick="return dropdown_Blank();">
      &nbsp;&nbsp;
      <input type="button" style="background:url(modules/ParseMyResume/images/reset.png); border:none;background-repeat:no-repeat; width:73px; height:30px; margin-top:7px;" value="" id="reset" onClick="return reset_Blank();"></td>
  </tr>
  <tr>
    <td colspan=2><div id="error_wrapper" style="color:red">
        <div id="site_error"> </div>
      </div></td>
  </tr>
</table>
