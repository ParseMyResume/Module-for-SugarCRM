<?php
/*********************************************************************************
 * ParseMyResume is helping SugarCRM customers to insert Resumes into ATS. 
 * ParseMyResume Copyright (C) 2011  - 2013 ParseMyResume.
 * 
 * This program is free/Subscription based  software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY ParseMyResume, ParseMyResume DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact ParseMyResume. headquarters at Suite 13, C-134, Phase 8
 * Industrial Area, Mohali, Punjab, 160062 India. or at email address support@parsemyresume.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 ********************************************************************************/
		 require_once('data/SugarBean.php');
		 $thisSugarBean = new SugarBean();
		 $lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
		 // print_r($option_list);
?>
<div align="center">
<table class="mGrid" cellspacing="0" cellpadding="4" border="0" id="ctl00_ContentPlaceHolder1_grd" style="color:#999966;border-color:Black;border-style:Solid;width:782px;border-collapse:collapse;">

<tr id="ctl00_ContentPlaceHolder1_grd_ct_l02" style="color:Yellow;background-color:LightSkyBlue;font-size:16pt;height:30px;">
<td align="right">
<span onfocus="AssignNot(this.id)" style="display:none;"><input id="ctl00_ContentPlaceHolder1_grd_ct_l02_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl02$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">PERSONAL DETAILS</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl02$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l02_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;display:none;">
</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l03" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l03_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl03$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">FirstName</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl03$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l03_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row2 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row2['Field'].">".$row2['Field']."</option>";
			$i++;
		  }
?>
</select>
</td> 
<td>
</tr>
<tr id="ctl00_ContentPlaceHolder1_grd_ct_l04" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l04_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl04$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">Middlename</td>
<td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl24$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l24_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row2 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row2['Field'].">".$row2['Field']."</option>";
			$i++;
		  }
?>
</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l05" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l05_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl05$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">LastName</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl24$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l24_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>
</select></td>
</tr>
<tr id="ctl00_ContentPlaceHolder1_grd_ct_l06" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l06_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl06$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">DateOfBirth</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl24$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l24_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr>
<tr id="ctl00_ContentPlaceHolder1_grd_ct_l07" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l07_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl07$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">Gender</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl24$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l24_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l08" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l08_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl08$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">PassportNo</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl24$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l24_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td><td align="right">
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l09" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l09_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl09$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">LicenseNo</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl24$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l24_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>

<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>
</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l10" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l10_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl10$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">Nationality</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl24$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l24_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l11" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l11_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl11$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">MaritalStatus</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl24$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l24_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l12" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l12_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl12$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">FatherName</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl24$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l24_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td><td align="right">

</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l13" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l13_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl13$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">MotherName</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl24$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l24_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l14" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l14_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl14$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">LanguageKnown</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl24$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l24_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l15" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l15_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl15$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">Hobbies</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl24$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l24_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l16" style="color:Yellow;background-color:LightSkyBlue;font-size:16pt;height:30px;">
<td align="right">
<span onfocus="AssignNot(this.id)" style="display:none;"><input id="ctl00_ContentPlaceHolder1_grd_ct_l16_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl16$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">CONTACT DETAILS</td><td align="right">
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l17" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l17_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl17$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">Address</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl24$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l24_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td></tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l18" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l18_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl18$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">City</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl24$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l24_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l19" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l19_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl19$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">State</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl24$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l24_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l20" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l20_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl20$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">ZipCode</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl24$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l24_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td></tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l21" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l21_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl21$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">Email</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl24$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l24_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l22" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l22_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl22$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">Phone</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl24$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l24_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l23" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l23_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl23$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">Mobile</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl24$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l24_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l24" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l24_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl24$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">FaxNo</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl24$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l24_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l25" style="color:Yellow;background-color:LightSkyBlue;font-size:16pt;height:30px;">
<td align="right">
<span onfocus="AssignNot(this.id)" style="display:none;"><input id="ctl00_ContentPlaceHolder1_grd_ct_l25_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl25$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">EDUCATION DETAILS</td><td align="right">
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l26" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l26_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl26$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">Qualification</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl26$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l26_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l27" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l27_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl27$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">University1</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl26$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l26_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l28" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l28_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl28$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">Degree1</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl28$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l28_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>
</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l29" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l29_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl29$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">Year1</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl29$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l29_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>
</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l30" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l30_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl30$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">University2</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl30$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l30_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>
</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l31" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l31_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl31$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">Degree2</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl31$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l31_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>
</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l32" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l32_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl32$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">Year2</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl32$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l32_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>
</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l33" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l33_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl33$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">University3</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl33$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l33_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>
</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l34" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l34_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl34$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">Degree3</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl34$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l34_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>
</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l35" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l35_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl35$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">Year3</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl35$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l35_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>


</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l36" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l36_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl36$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">Category</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl36$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l36_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l37" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l37_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl37$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">SubCategory</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl37$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l37_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l38" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l38_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl38$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">Skills</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl38$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l38_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l39" style="color:Yellow;background-color:LightSkyBlue;font-size:16pt;height:30px;">
<td align="right">
<span onfocus="AssignNot(this.id)" style="display:none;"><input id="ctl00_ContentPlaceHolder1_grd_ct_l39_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl39$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">EMPLOYMENT DETAILS</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl39$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l39_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;display:none;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>

</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l40" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l40_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl40$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">Experience</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl40$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l40_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l41" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l41_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl41$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">CurrentEmployer</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl41$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l41_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l42" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l42_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl42$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">JobProfile</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl42$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l42_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>

<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>
</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l43" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l43_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl43$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">CurrentSalary</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl43$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l43_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l44" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l44_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl44$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">ExpectedSalary</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl44$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l44_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l45" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l45_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl45$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">Employer1</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl45$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l45_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l46" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l46_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl46$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">JobProfile1</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl46$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l46_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l47" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l47_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl47$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">JobPeriod1</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl47$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l47_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l48" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l48_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl48$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">JobLocation1</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl48$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l48_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l49" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l49_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl49$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">StartDate1</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl49$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l49_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l50" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l50_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl50$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">EndDate1</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl50$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l50_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l51" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l51_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl51$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">JobDescription1</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl51$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l51_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l52" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l52_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl52$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">Employer2</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl52$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l52_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<option value="1" style="Background:#000000" disabled="disabled">EmailFields</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l53" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l53_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl53$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">JobProfile2</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl53$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l53_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l54" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l54_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl54$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">JobPeriod2</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl54$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l54_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l55" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l55_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl55$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">JobLocation2</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl55$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l55_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l56" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l56_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl56$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">StartDate2</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl56$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l56_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l57" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l57_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl57$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">EndDate2</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl57$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l57_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l58" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l58_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl58$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">JobDescription2</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl58$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l58_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l59" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l59_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl59$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">Employer3</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl59$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l59_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l60" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l60_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl60$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">JobProfile3</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl60$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l60_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l61" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l61_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl61$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">JobPeriod3</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl61$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l61_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l62" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l62_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl62$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">JobLocation3</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl62$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l62_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l63" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l63_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl63$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">StartDate3</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl63$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l63_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l64" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l64_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl64$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">EndDate3</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl64$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l64_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l65" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l65_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl65$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">JobDescription3</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl65$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l65_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>
</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l66" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l66_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl66$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">Experience_Year</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl66$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l66_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l67" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l67_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl67$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">Experience_Months</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl67$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l67_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td><
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l68" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l68_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl68$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">GapPeriod</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl68$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l68_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l69" style="color:Yellow;background-color:LightSkyBlue;font-size:16pt;height:30px;">
<td align="right">
<span onfocus="AssignNot(this.id)" style="display:none;"><input id="ctl00_ContentPlaceHolder1_grd_ct_l69_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl69$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">OTHER DETAILS</td><td align="right">
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l70" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l70_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl70$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">EmailFrom</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl70$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l70_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>

<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>
</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l71" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l71_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl71$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">EmailTo</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl71$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l71_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l72" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l72_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl72$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">EmailCC</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl72$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l72_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l73" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l73_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl73$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">EmailSubject</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl73$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l73_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l74" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l74_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl74$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">EmailReplyTo</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl74$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l74_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l75" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l75_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl75$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">EmailBody</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl75$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l75_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l76" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l76_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl76$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">Objectives</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl76$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l76_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l77" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l77_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl77$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">Achievements</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl77$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l77_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l78" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l78_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl78$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">References</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl78$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l78_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l79" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l79_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl79$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">AttachFile</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl79$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l79_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l80" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l80_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl80$CheckBox1" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">FileName</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl80$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l80_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>
</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l81" style="color:#284775;background-color:White;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l81_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl81$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">DetailResume</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl81$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l81_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>
</select>
</td>
</tr><tr id="ctl00_ContentPlaceHolder1_grd_ct_l82" style="color:#333333;background-color:#F7F6F3;">
<td align="right">
<span onfocus="AssignNot(this.id)"><input id="ctl00_ContentPlaceHolder1_grd_ct_l82_CheckBox1" type="checkbox" name="ctl00$ContentPlaceHolder1$grd$ctl82$CheckBox1" checked="checked" onclick="return checkChanged(this.id,this);" /></span>
</td><td align="left">Status</td><td align="right">
<select name="ctl00$ContentPlaceHolder1$grd$ctl82$DropDownList1" id="ctl00_ContentPlaceHolder1_grd_ct_l82_DropDownList1" onchange="return CheckUnCheckGrid(this.id);" onfocus="AssignNot(this.id)" style="width:230px;">
<option value="---------------------Select-------------------">---------------------Select-------------------</option>
<?php
$lead_struct="DESCRIBE leads";
		 $lead_result=$thisSugarBean->db->query($lead_struct,true);
		 $row = $lead_result->fetch_assoc();
		 $option_list="";
$i=1;
while($row3 = $lead_result->fetch_assoc())
		  {
			echo "<option value=".$row3['Field'].">".$row3['Field']."</option>";
			$i++;
		  }
?>

</select>
</td>
</tr>
</table>