<?php
/*********************************************************************************
 * ParseMyResume is helping SugarCRM customers to insert Resumes into ATS. 
 * ParseMyResume Copyright (C) 2011  - 2013 ParseMyResume.
 * 
 * This program is free/Subscription based  software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY ParseMyResume, ParseMyResume DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact ParseMyResume. headquarters at Suite 13, C-134, Phase 8
 * Industrial Area, Mohali, Punjab, 160062 India. or at email address support@parsemyresume.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 ********************************************************************************/
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

 echo "<br><br>";
 echo "<center><table border=2 style=\"border-color:'red';border-style:'solid';\"><tr><td><h2><font color='green'>Zip has been uploaded successfully and will be processed via cron job.<br><br><br></h2></font><font color=\"red\"><p> *Please ensure your admin has set the cron job right.<br> If not follow given steps.<br><ol type=\"a\"><li>Navigate to Admin > Schedulers>Create Scheduler</li><li>From Job DropDown Select ParseMyResume_Zip_Process.</li></ol>Note: To send zip success mailer notifications, an SMTP server must be configured in <a href=\"index.php?module=EmailMan&action=config\">Email Settings </a>.</center></td></tr></h3>";
 echo "<br><br><br><br>";
?>