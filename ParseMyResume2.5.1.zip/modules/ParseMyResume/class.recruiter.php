<?php
/*********************************************************************************
 * ParseMyResume is helping SugarCRM customers to insert Resumes into ATS. 
 * ParseMyResume Copyright (C) 2011  - 2013 ParseMyResume.
 * 
 * This program is free/Subscription based  software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY ParseMyResume, ParseMyResume DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact ParseMyResume. headquarters at Suite 13, C-134, Phase 8
 * Industrial Area, Mohali, Punjab, 160062 India. or at email address support@parsemyresume.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 ********************************************************************************/
class Recruiter {
	/**
	* function for saving the uploaded file on server
	*/
	function SaveUplodedFile()
	{	
		if($_FILES["resumecontent"]["tmp_name"] ){		
		//file should be upto 1 MB
			if($_FILES["resumecontent"]["size"] < 1048576){
				$explodemainfilename = explode(".",basename($_FILES["resumecontent"]["name"]));
				$countmainexplode = count($explodemainfilename);
				$filterfile = $explodemainfilename[$countmainexplode-1] ;
				
				if($filterfile == "rtf" || $filterfile == "doc" || $filterfile == "docx" || $filterfile== "pdf" || $filterfile == "txt" || $filterfile == "html"){
					if ($_FILES["resumecontent"]["error"] > 0){
						$this->_uploaderror.= "<span align='center' class='msg'>Return Code: ".$_FILES["resumecontent"]["error"]."</span><br />";
					}
					else{		
						//explode the name ad append the timestamp
						@$stream=fopen($_FILES["resumecontent"]["tmp_name"],'r');
						$content = stream_get_contents($stream);
						$this->_resumeuploadsucess = "yes";
						$this->_filterfile = $filterfile;
						$filename = basename($_FILES["resumecontent"]["name"]);
						if($filterfile == "rtf" || $filterfile == "doc" || $filterfile == "docx" || $filterfile == "txt" || $filterfile == "html" || $filterfile== "pdf"){
						
							$parsedxml = $this->GetXML($content,$filename);
							return $parsedxml;
						}
						else{
							echo "<span style='color:#FF0000; font-size:12px padding-left:20px;'>There is some problem in parsing resume</span>";
							$upload_result['errorcode'] = 1017;
				
							return $upload_result;
						}
					}
				}
				else{
					echo "<span style='color:#FF0000; font-size:14px; padding-left:20px; padding-top:10px;' >Invalid file format. Support .doc, .docx, .rtf, .html or .pdf formats</span>";
					$this->_uploaderror.= "<span align='center' class='msg'>Invalid file format. Support .doc, .docx, .rtf, .html or .pdf formats</span>";				 
					$upload_result['errorcode'] = 1016;
				
					return $upload_result;
				}
			}
			else{
				$this->_uploaderror.= "<span align='center' class='msg'>Invalid file.Please upload file upto 1 MB size</span>";	
				
				$upload_result['errorcode'] = 1015;
				
				return $upload_result;
			}
		}
	
		//return true;
	} 
	
	function parseActualValue($item,$defaultVal = '',$val = 0) {
			$output = "";	
			
			if(is_object($item)) {
			   $output = 'Array';
			} else {
			   $output = $item;
			}
				
			if(empty($item)) {
				$output = $defaultVal;
			}	
			
			return $output;
	}
	
	function GetXML($content='',$type)
	{
		$salesforce_data = array();
		$starttime = microtime();
		$ds = new ParseMyResumeService();
		$hrxml = $ds->getHRXMLBinary($content,$type);
		
		$xml=stripslashes($hrxml);	
		
		ob_start();
		var_dump($xml);
		$resultXML = ob_get_clean();
		$resultXML = explode(') "',substr($resultXML,0,-2));
		$xmlArray = simplexml_load_string($resultXML[1],'SimpleXMLElement', LIBXML_NOCDATA);
		
		foreach($xmlArray as $key=>$item) {
		    $VatItem = (string) $xmlArray->$key; 
			$VatItem = trim($VatItem);
			if($key=="ResumeFileName") {
				$salesforce_data['ResumeFileName'] = $this->parseActualValue($VatItem,$type);
			} else if($key=="CurrentEmployer")	{
				$salesforce_data['Company'] = $this->parseActualValue($VatItem,'fresher');
			} else if($key == "SegregatedQualification") {
				$i = 1;
				foreach($xmlArray->$key->EducationSplit as $Eduitem) {
					foreach($Eduitem as $keyEdu=>$valEdu) {
						$VatItem = (string) $Eduitem->$keyEdu; 
						$VatItem = trim($VatItem);
						$salesforce_data[$keyEdu.$i] = $this->parseActualValue($VatItem,'');
					}
					$i++;
				}
			} else if($key == "SegregatedExperience") {
				$i = 1;
				foreach($xmlArray->$key->WorkHistory as $Expitem) {
					foreach($Expitem as $keyExp=>$valExp) {
						$VatItem = (string) $Expitem->$keyExp; 
						$VatItem = trim($VatItem);
						if($keyExp=="StartDate" || $keyExp=="EndDate") {
							if(empty($VatItem)) {
								$VatItem = "00/00/0000";
							}
							$VatItemArr = explode("/",$VatItem);
							$VatItem = $VatItemArr[2]."-".$VatItemArr[1]."-".$VatItemArr[0]; 
							$salesforce_data[$keyExp.$i] = $this->parseActualValue($VatItem,'');
						} else if($keyExp == "Projects") {
							foreach($valExp as $keyExpPro=>$valExpPro) {
								$VatItem = (string) $valExpPro; 
								$VatItem = trim($VatItem);
								$salesforce_data[$keyExpPro.$i] = $this->parseActualValue($VatItem,'');
							}
						} else {
							$salesforce_data[$keyExp.$i] = $this->parseActualValue($VatItem,'');
						}
					}
					$i++;
				}
			} else if($key == "SkillsSegregation") {
				$i = 1;
				foreach($xmlArray->$key->SkillsKeywords as $SKitem) {
					foreach($SKitem as $keySK=>$valSK) {
						$VatItem = (string) $SKitem->$keySK; 
						$VatItem = trim($VatItem);
						$salesforce_data[$keySK.$i] = $this->parseActualValue($VatItem,'');
					}
					$i++;
				}
			} else if($key == "Recommendations") {
				$i = 1;
				foreach($xmlArray->$key->Recommendations as $keyRecomend=>$valRecomend) {
						$VatItem = (string) $Recommenditem->$keyRecomend; 
						$VatItem = trim($VatItem);
						$salesforce_data[$keyRecomend.$i] = $this->parseActualValue($VatItem,'');
					$i++;
			    } 
			} else if($key == "SocialRecruit") {  
				
				$facebook_array = array("link"=>"FacebookLink","image_url"=>"FacebookImageURL","name"=>"FacebookName","birthday"=>"FacebookBirthday","gender"=>"FacebookGender","email"=>"FacebookEmail", "timezone" => "FacebookTimezone", "userid"=>"FacebookUserid");
				
				$twitter_array = array("link"=>"TwitterLink","image_url"=>"TwitterImageURL","name"=>"TwitterName","userid"=>"TwitterUserid","Total_Friends"=>"TwitterTotalFriend","followers_count"=>"TwitterFollowers", "location"=>"TwitterLocation", "created_at"=>"TwitterCreatedDate");
				
				$google_array = array("link"=>"GoogleLink","image_url"=>"GoogleImageURL","gender"=>"GoogleGender","userid"=>"GoogleUserid","name"=>"GoogleName","kind"=>"GoogleKind");
				
				$linkedin_array = array("link"=>"LinkedInLink","image_url"=>"LinkedInImageURL","designation"=>"LinkedInDesignation","company"=>"LinkedInCompamy","location"=>"LinkedInLocation","membership"=>"LinkedInMembership");
				
				$i = 1;
				foreach($xmlArray->$key->SocialProfile as $Socialitem) {
					foreach($Socialitem as $keySocial=>$valSocial) {
					    foreach($valSocial as $keySocialsub=>$valSocialsub) {
							$VatItem = (string) $valSocialsub; 
							$VatItem = trim($VatItem);
							if($keySocial == "linkedIn") {
								$salesforce_data[$linkedin_array[$keySocialsub]] = $this->parseActualValue($VatItem,'');
							} else if($keySocial == "facebook") {
								$salesforce_data[$facebook_array[$keySocialsub]] = $this->parseActualValue($VatItem,'');
							} else if($keySocial == "twitter") {
								$salesforce_data[$twitter_array[$keySocialsub]] = $this->parseActualValue($VatItem,'');
							} else if($keySocial == "google") {
								$salesforce_data[$google_array[$keySocialsub]] = $this->parseActualValue($VatItem,'');
							} 
						}
					}
					$i++;
				}
			} else {
				$salesforce_data[$key] = $this->parseActualValue($VatItem,'');
			}
		}
		
		foreach($xmlArray->CurrentEmployer as $CurrentEmp) {
			$salesforce_data["CurrentEmployer"] = (string) $CurrentEmp;
		}
		
		foreach($xmlArray->JobProfile as $JobProfile) {
			$salesforce_data["JobProfile"] =(string) $JobProfile;
		}
		
		foreach($xmlArray->WorkedPeriod->TotalExperienceInYear as $TotalExperienceInYear) {
			$salesforce_data["TotalExperienceInYear"] =(string) $TotalExperienceInYear;
		}
		
		foreach($xmlArray->WorkedPeriod->TotalExperienceInMonths as $TotalExperienceInMonths) {
			$salesforce_data["TotalExperienceInMonths"] =(string) $TotalExperienceInMonths;
		}
		
		foreach($xmlArray->WorkedPeriod->TotalExperienceRange as $TotalExperienceRange) {
			$salesforce_data["TotalExperienceRange"] =(string) $TotalExperienceRange;
		}
		
		foreach($xmlArray->GapPeriod as $GapPeriod) {
			$salesforce_data["GapPeriod"] = (string) $GapPeriod;
		}
		
		foreach($xmlArray->NumberofJobChanged as $NumberofJobChanged) {
			$salesforce_data["NumberofJobChanged"] =(string) $NumberofJobChanged;
		}
		
		foreach($xmlArray->AverageStay as $AverageStay) {
			$salesforce_data["AverageStay"] =(string) $AverageStay;
		}
		
		foreach($xmlArray->Availability as $Availability) {
			$salesforce_data["Availability"] =(string) $Availability;
		}
		
		foreach($xmlArray->Hobbies as $Hobbies) {
			$salesforce_data["Hobbies"] = (string) $Hobbies;
		}
		
		foreach($xmlArray->Objectives as $Objectives) {
			$salesforce_data["Objectives"] = (string) $Objectives;
		}
		
		foreach($xmlArray->Achievements as $Achievements) {
			$salesforce_data["Achievements"] = $Achievements;
		}
		
		return $salesforce_data; 
	}




}



?>