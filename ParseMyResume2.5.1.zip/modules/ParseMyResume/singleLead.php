<?php
/*********************************************************************************
 * ParseMyResume is helping SugarCRM customers to insert Resumes into ATS. 
 * ParseMyResume Copyright (C) 2011  - 2013 ParseMyResume.
 * 
 * This program is free/Subscription based  software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY ParseMyResume, ParseMyResume DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact ParseMyResume. headquarters at Suite 13, C-134, Phase 8
 * Industrial Area, Mohali, Punjab, 160062 India. or at email address support@parsemyresume.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 ********************************************************************************/

function savelead($upload_result)
{ 
	global  $current_user;
    //echo "<pre>";print_r($upload_result);echo "</pre>";
	if(isset($upload_result['errorcode']))
	{
		return $upload_result['errorcode'];
	}
	else if(empty($upload_result['Email']))
	{
		return 112;  //Email id blank  Error Code 112
	}
	else
	{
		require_once('data/SugarBean.php');
		require_once('modules/Notes/Note.php');
		$thisSugarBean = new SugarBean();
	 
		$emailAdd=$upload_result['Email'];
		if(!empty($emailAdd))
		{
			 $emailAddress="select leads.id from email_addresses e
			 INNER JOIN email_addr_bean_rel er ON(e.id=er.email_address_id AND er.bean_module='Leads')
			 INNER JOIN leads ON(leads.id=er.bean_id)
			 where leads.deleted =0 AND  e.email_address='{$emailAdd}';";
			   
			 $result=$thisSugarBean->db->query($emailAddress,true);
			 $Result =$result->fetch_row();
			 if(empty($Result))
			 {
			 	 $text_data_len['tinytext'] = '85';
				 $text_data_len['text'] = '15845';
				 $text_data_len['mediumtext'] = '5592405';
				 $text_data_len['longtext'] = '1431655765';
				 $ParseMyResumeType_len = array();
				 
				 $uuidQuery="select UUID()";
				 $uuid=$thisSugarBean->db->query($uuidQuery,true);
				 $uuidResult = $uuid->fetch_row(); 
				 $id=$uuidResult[0];
				 $date=date("Y-m-d H:i:s");
				 $sugarQuery="select * from ParseMyResume_field_mapping";
				 $sugarRes=$thisSugarBean->db->query($sugarQuery,true);
				 $queryUpdate = "INSERT INTO `leads` (`id`,`date_entered`, `date_modified`,`status`,";
	
				while ($sugar = $sugarRes->fetch_assoc())
				{
					if(strlen(trim($sugar['sugar_field'])) >0)
					{ 
						$str=strlen($sugar['sugar_field']);
						$customfiled=substr($sugar['sugar_field'],$str-2,2);
						$customfiled=strstr($customfiled,"_c");
						if(empty($customfiled))
						{ 
							 $ParseMyResumeData[]=$sugar['ParseMyResume_field'];
							 $varchar=strstr($sugar['sugar_field_size'],"varchar");
							 $char=strstr($sugar['sugar_field_size'],"char");
							 $dateType=strstr($sugar['sugar_field_size'],"date");
							 
							 if($sugar['sugar_field_size']=='tinytext' || $sugar['sugar_field_size']=='text' || $sugar['sugar_field_size']=='mediumtext' || $sugar['sugar_field_size']=='longtext'){
								$ParseMyResumeType_len[] = $sugar['sugar_field_size'];
							}else if(substr($sugar['sugar_field_size'],0,7) == 'varchar'){
								$str_var = str_replace("varchar(","",$sugar['sugar_field_size']);
								$str_var = str_replace(")","",$str_var);
								if($sugar['ParseMyResume_field'] = 'Email')
								$ParseMyResumeType_len[] = '';
								else
								$ParseMyResumeType_len[] = $str_var;
							}else{
								$ParseMyResumeType_len[] = '';
							}
							 
							if(!empty($varchar))
							{
								$size=explode("(",$varchar);
								$ParseMyResumeDataSize[$sugar['ParseMyResume_field']]=$size[1];
							}
							else if(!empty($char))
							{
								$size=explode("(",$char);
								$ParseMyResumeDataSize[$sugar['ParseMyResume_field']]=$size[1];	
							}
							else if(!empty($dateType))
							{
								$ParseMyResumeDate[$sugar['ParseMyResume_field']]="date";	
							}
							
											
						$queryUpdate.="`".$sugar['sugar_field']."`,";
						} 
					}
			
				} 
				
				$queryUpdate=rtrim($queryUpdate,",").")VALUES ('{$id}','{$date}','{$date}','New',";
				$num=count($ParseMyResumeData);
				$sugarQuery2="select * from ParseMyResume_field_mapping";
				$sugarRes2=$thisSugarBean->db->query($sugarQuery2,true);
				for($i=0;$i<$num;$i++)
				{
					foreach($ParseMyResumeDataSize as $key=>$value)
					{
						if($ParseMyResumeData[$i]==$key)
							{
								$upload_result[$ParseMyResumeData[$i]]=substr($upload_result[$ParseMyResumeData[$i]],0,$value); 
							}
					}
					if(!empty($ParseMyResumeDate))
					{
						foreach($ParseMyResumeDate as $field=>$fvalue)
						{	
							if($ParseMyResumeData[$i]==$field)
							{
								$originalDate=explode("/",$upload_result[$ParseMyResumeData[$i]]);
								
								if($originalDate[1]<10)
								{
									$originalDate[1]="0".$originalDate[1];
								}
								if($originalDate[0]<10)
								{
									$originalDate[0]="0".$originalDate[0];
								}
								$upload_result[$ParseMyResumeData[$i]]=$originalDate[2].":".$originalDate[1].":".$originalDate[0];
									
							}									
						}
					}
					if($ParseMyResumeType_len[$i]=='tinytext' || $ParseMyResumeType_len[$i]=='text' || $ParseMyResumeType_len[$i]=='mediumtext' || $ParseMyResumeType_len[$i]=='longtext'){
						$output = preg_replace('/[^(\x20-\x7F)]*/','', $upload_result[$ParseMyResumeData[$i]]);
						$queryUpdate.="'".addslashes(htmlspecialchars(substr($output,0,$text_data_len[$ParseMyResumeType_len[$i]])))."',";
					}else if(strlen($ParseMyResumeType_len[$i])>0){
						$output = preg_replace('/[^(\x20-\x7F)]*/','', $upload_result[$ParseMyResumeData[$i]]);
						$queryUpdate.="'".addslashes(substr(trim($output),0,$ParseMyResumeType_len[$i]))."',";
					}else{
						$queryUpdate.="'".addslashes($upload_result[$ParseMyResumeData[$i]])."',";
					}
				} 
		
				$queryUpdate=rtrim($queryUpdate,",").");";
				$thisSugarBean->db->query($queryUpdate,true); 
									
					
				/**..............................................Custom Lead Table......................................**/
				$sugarQuery_c="select * from ParseMyResume_field_mapping";
				$sugarRes_c=$thisSugarBean->db->query($sugarQuery_c,true);
				$queryUpdate_c = "INSERT INTO `leads_cstm` (`id_c`,";
				$ParseMyResumeType_len = array();
					
				while ($sugar_c = $sugarRes_c->fetch_assoc())
				{ 
					if(!empty($sugar_c['sugar_field']))
					{
						$str=strlen($sugar_c['sugar_field']);
						$customfiled_c=substr($sugar_c['sugar_field'],$str-2,2);
						$customfiled_c=strstr($customfiled_c,"_c");
						
						if(!empty($customfiled_c))
						{
						   	$ParseMyResumeData_c[]=$sugar_c['ParseMyResume_field'];
							$varchar_c=strstr($sugar_c['sugar_field_size'],"varchar");
							$char_c=strstr($sugar_c['sugar_field_size'],"char");
							if($sugar_c['sugar_field_size']=='tinytext' || $sugar_c['sugar_field_size']=='text' || $sugar_c['sugar_field_size']=='mediumtext' || $sugar_c['sugar_field_size']=='longtext'){
								$ParseMyResumeType_len[] = $sugar_c['sugar_field_size'];
							}else if(substr($sugar_c['sugar_field_size'],0,7) == 'varchar'){
								$str_var = str_replace("varchar(","",$sugar_c['sugar_field_size']);
								$str_var = str_replace(")","",$str_var);
								$ParseMyResumeType_len[] = $str_var;
							}else{
								$ParseMyResumeType_len[] = '';
							}
								
							if(!empty($varchar_c))
							{
								$size_c=explode("(",$varchar_c);
								$ParseMyResumeDataSize_c[$sugar_c['ParseMyResume_field']]=$size_c[1];
							}
							else if(!empty($char_c))
							{
								$size_c=explode("(",$char_c);
								$ParseMyResumeDataSize_c[$sugar_c['ParseMyResume_field']]=$size_c[1];	
							}
							else if(!empty($dateType_c))
							{
								$ParseMyResumeDate_c[$sugar_c['ParseMyResume_field']]="date";	
							}		
											
							$queryUpdate_c.="`".$sugar_c['sugar_field']."`,";
						}
					}
		
				} 
				$queryUpdate_c=rtrim($queryUpdate_c,",").")VALUES ('{$id}',";
				$num_c=count($ParseMyResumeData_c);
				for($i_c=0;$i_c<$num_c;$i_c++)
				{
					foreach($ParseMyResumeDataSize_c as $key_c=>$value_c)
					{  
						if($ParseMyResumeData_c[$i_c]==$key_c && $ParseMyResumeData_c[$i_c]!=='CandidateImageData')
						{  
							$upload_result[$ParseMyResumeData_c[$i_c]]=substr($upload_result[$ParseMyResumeData_c[$i_c]], 0,$value_c); 
							
						}
					}
					foreach($ParseMyResumeDate_c as $field_c=>$fvalue_c)
					{	
						if($ParseMyResumeData_c[$i]==$field_c)
						{
							$originalDate=explode("/",$upload_result[$ParseMyResumeData[$i]]);
							if($originalDate[1]<10)
							{
								$originalDate[1]="0".$originalDate[1];
							}
							if($originalDate[0]<10)
							{
								$originalDate[0]="0".$originalDate[0];
							}
							$upload_result[$ParseMyResumeData[$i]]=$originalDate[2].":".$originalDate[1].":".$originalDate[0];
						}									
					}
					//CandidateImageFormat
				   if($ParseMyResumeData_c[$i_c]=='CandidateImageData')
				   {
				       	$img_type = $upload_result['CandidateImageFormat'];
					  	$im = $upload_result['CandidateImageData'];
					    if(strlen($im)>20)
						{
							$img = str_replace('data:image/jpeg;base64,', '', $im);
							$img = str_replace(' ', '+', $img);
							$data = base64_decode($img);
							$file = "custom/OffshorePhoto/phpThumb/images/Leads_{$id}.".$img_type;
							$success = file_put_contents($file, $data);
							$upload_result[$ParseMyResumeData_c[$i_c]] = "Leads_{$id}.".$img_type;
						}else{
							$upload_result[$ParseMyResumeData_c[$i_c]] = '';
						}
				   }
				   
					if($ParseMyResumeType_len[$i_c]=='tinytext' || $ParseMyResumeType_len[$i_c]=='text' || $ParseMyResumeType_len[$i_c]=='mediumtext' || $ParseMyResumeType_len[$i_c]=='longtext'){
						$output = preg_replace('/[^(\x20-\x7F)]*/','', $upload_result[$ParseMyResumeData_c[$i_c]]);	
						$queryUpdate_c.="'".addslashes(htmlspecialchars(substr($output,0,$text_data_len[$ParseMyResumeType_len[$i_c]])))."',";
					}else if(strlen($ParseMyResumeType_len[$i_c])>0){
						$output = preg_replace('/[^(\x20-\x7F)]*/','', $upload_result[$ParseMyResumeData_c[$i_c]]);
						$queryUpdate_c.="'".addslashes(substr(trim($output),0,$ParseMyResumeType_len[$i_c]))."',";
					}else{
			 			$queryUpdate_c.="'".addslashes($upload_result[$ParseMyResumeData_c[$i_c]])."',";
					}
				} 
				$queryUpdate_c=rtrim($queryUpdate_c,",").");";
				//echo $queryUpdate_c;	exit;
				$thisSugarBean->db->query($queryUpdate_c,true);

				/****************************************Email Store"*******************************/
				 $email=$upload_result['Email'];
				 $capEmail=strtoupper($email);
				 $emailQuery="INSERT INTO `email_addresses` (`id`, `email_address`, `email_address_caps`, `invalid_email`, `opt_out`, `date_created`, `date_modified`, `deleted`) VALUES ('{$id}', '{$email}', '{$capEmail}','0','0','{$date}','{$date}', '0');";
				 $thisSugarBean->db->query($emailQuery,true); 
				 $emailbeanQuery="INSERT INTO `email_addr_bean_rel` (`id`, `email_address_id`, `bean_id`, `bean_module`, `primary_address`, `reply_to_address`, `date_created`, `date_modified`, `deleted`) VALUES ('{$id}','{$id}', '{$id}', 'Leads', '0', '0','{$date}','{$date}', '0');";

				$thisSugarBean->db->query($emailbeanQuery,true); 
				/** code  to add attachment with note **/				 
				$note = new Note();
				$note->modified_user_id = $current_user->id;
				$note->created_by = $current_user->id;
				$note->assigned_user_id = $current_user->id;
				$note->name = $_FILES["resumecontent"]["name"];
				$note->parent_type = "Leads";
				$note->parent_id = $id;
				$note->filename =  $_FILES["resumecontent"]["name"]; //your file name goes here
			
				$note->file_mime_type = $_FILES["resumecontent"]["type"];  // your file's mime type goes here
				
				$note->save();
				
				$dest = $GLOBALS['sugar_config']['upload_dir'].$note->id; 
				if (!is_file($dest)) {
					move_uploaded_file($_FILES["resumecontent"]["tmp_name"], $dest);
				} 
				
				/** end code to save attachment **/	
				return $id;	
			}
			else
			{
			$data['linkID']=$Result[0];
			$data['id']=1000;
			 return $data;
			}
		}
	}
 }
 
  
function saveleadZipEmail($upload_result)
{ 
	global  $current_user;
    //echo "<pre>";print_r($upload_result);echo "</pre>";
	if(isset($upload_result['errorcode']))
	{
		return $upload_result['errorcode'];
	}
	else if(empty($upload_result['Email']))
	{
		return 112;  //Email id blank  Error Code 112
	}
	else
	{
		require_once('data/SugarBean.php');
		require_once('modules/Notes/Note.php');
		$thisSugarBean = new SugarBean();
	 
		$emailAdd=$upload_result['Email'];
		if(!empty($emailAdd))
		{
			 $emailAddress="select leads.id from email_addresses e
			 INNER JOIN email_addr_bean_rel er ON(e.id=er.email_address_id AND er.bean_module='Leads')
			 INNER JOIN leads ON(leads.id=er.bean_id)
			 where leads.deleted =0 AND  e.email_address='{$emailAdd}';";
			   
			 $result=$thisSugarBean->db->query($emailAddress,true);
			 $Result =$result->fetch_row();
			 if(empty($Result))
			 {
			 	 $text_data_len['tinytext'] = '85';
				 $text_data_len['text'] = '15845';
				 $text_data_len['mediumtext'] = '5592405';
				 $text_data_len['longtext'] = '1431655765';
				 $ParseMyResumeType_len = array();
				 
				 $uuidQuery="select UUID()";
				 $uuid=$thisSugarBean->db->query($uuidQuery,true);
				 $uuidResult = $uuid->fetch_row(); 
				 $id=$uuidResult[0];
				 $date=date("Y-m-d H:i:s");
				 $sugarQuery="select * from ParseMyResume_field_mapping";
				 $sugarRes=$thisSugarBean->db->query($sugarQuery,true);
				 $queryUpdate = "INSERT INTO `leads` (`id`,`date_entered`, `date_modified`,`status`,";
	
				while ($sugar = $sugarRes->fetch_assoc())
				{
					if(strlen(trim($sugar['sugar_field'])) >0)
					{ 
						$str=strlen($sugar['sugar_field']);
						$customfiled=substr($sugar['sugar_field'],$str-2,2);
						$customfiled=strstr($customfiled,"_c");
						if(empty($customfiled))
						{ 
							 $ParseMyResumeData[]=$sugar['ParseMyResume_field'];
							 $varchar=strstr($sugar['sugar_field_size'],"varchar");
							 $char=strstr($sugar['sugar_field_size'],"char");
							 $dateType=strstr($sugar['sugar_field_size'],"date");
							 
							 if($sugar['sugar_field_size']=='tinytext' || $sugar['sugar_field_size']=='text' || $sugar['sugar_field_size']=='mediumtext' || $sugar['sugar_field_size']=='longtext'){
								$ParseMyResumeType_len[] = $sugar['sugar_field_size'];
							}else if(substr($sugar['sugar_field_size'],0,7) == 'varchar'){
								$str_var = str_replace("varchar(","",$sugar['sugar_field_size']);
								$str_var = str_replace(")","",$str_var);
								if($sugar['ParseMyResume_field'] = 'Email')
								$ParseMyResumeType_len[] = '';
								else
								$ParseMyResumeType_len[] = $str_var;
							}else{
								$ParseMyResumeType_len[] = '';
							}
							 
							if(!empty($varchar))
							{
								$size=explode("(",$varchar);
								$ParseMyResumeDataSize[$sugar['ParseMyResume_field']]=$size[1];
							}
							else if(!empty($char))
							{
								$size=explode("(",$char);
								$ParseMyResumeDataSize[$sugar['ParseMyResume_field']]=$size[1];	
							}
							else if(!empty($dateType))
							{
								$ParseMyResumeDate[$sugar['ParseMyResume_field']]="date";	
							}
							
											
						$queryUpdate.="`".$sugar['sugar_field']."`,";
						} 
					}
			
				} 
				
				$queryUpdate=rtrim($queryUpdate,",").")VALUES ('{$id}','{$date}','{$date}','New',";
				$num=count($ParseMyResumeData);
				$sugarQuery2="select * from ParseMyResume_field_mapping";
				$sugarRes2=$thisSugarBean->db->query($sugarQuery2,true);
				for($i=0;$i<$num;$i++)
				{
					foreach($ParseMyResumeDataSize as $key=>$value)
					{
						if($ParseMyResumeData[$i]==$key)
							{
								$upload_result[$ParseMyResumeData[$i]]=substr($upload_result[$ParseMyResumeData[$i]],0,$value); 
							}
					}
					if(!empty($ParseMyResumeDate))
					{
						foreach($ParseMyResumeDate as $field=>$fvalue)
						{	
							if($ParseMyResumeData[$i]==$field)
							{
								$originalDate=explode("/",$upload_result[$ParseMyResumeData[$i]]);
								
								if($originalDate[1]<10)
								{
									$originalDate[1]="0".$originalDate[1];
								}
								if($originalDate[0]<10)
								{
									$originalDate[0]="0".$originalDate[0];
								}
								$upload_result[$ParseMyResumeData[$i]]=$originalDate[2].":".$originalDate[1].":".$originalDate[0];
									
							}									
						}
					}
					if($ParseMyResumeType_len[$i]=='tinytext' || $ParseMyResumeType_len[$i]=='text' || $ParseMyResumeType_len[$i]=='mediumtext' || $ParseMyResumeType_len[$i]=='longtext'){
						$output = preg_replace('/[^(\x20-\x7F)]*/','', $upload_result[$ParseMyResumeData[$i]]);
						$queryUpdate.="'".addslashes(htmlspecialchars(substr($output,0,$text_data_len[$ParseMyResumeType_len[$i]])))."',";
					}else if(strlen($ParseMyResumeType_len[$i])>0){
						$output = preg_replace('/[^(\x20-\x7F)]*/','', $upload_result[$ParseMyResumeData[$i]]);
						$queryUpdate.="'".addslashes(substr(trim($output),0,$ParseMyResumeType_len[$i]))."',";
					}else{
						$queryUpdate.="'".addslashes($upload_result[$ParseMyResumeData[$i]])."',";
					}
				} 
		
				$queryUpdate=rtrim($queryUpdate,",").");";
				$thisSugarBean->db->query($queryUpdate,true); 
									
					
				/**..............................................Custom Lead Table......................................**/
				$sugarQuery_c="select * from ParseMyResume_field_mapping";
				$sugarRes_c=$thisSugarBean->db->query($sugarQuery_c,true);
				$queryUpdate_c = "INSERT INTO `leads_cstm` (`id_c`,";
				$ParseMyResumeType_len = array();
					
				while ($sugar_c = $sugarRes_c->fetch_assoc())
				{ 
					if(!empty($sugar_c['sugar_field']))
					{
						$str=strlen($sugar_c['sugar_field']);
						$customfiled_c=substr($sugar_c['sugar_field'],$str-2,2);
						$customfiled_c=strstr($customfiled_c,"_c");
						
						if(!empty($customfiled_c))
						{
						   	$ParseMyResumeData_c[]=$sugar_c['ParseMyResume_field'];
							$varchar_c=strstr($sugar_c['sugar_field_size'],"varchar");
							$char_c=strstr($sugar_c['sugar_field_size'],"char");
							if($sugar_c['sugar_field_size']=='tinytext' || $sugar_c['sugar_field_size']=='text' || $sugar_c['sugar_field_size']=='mediumtext' || $sugar_c['sugar_field_size']=='longtext'){
								$ParseMyResumeType_len[] = $sugar_c['sugar_field_size'];
							}else if(substr($sugar_c['sugar_field_size'],0,7) == 'varchar'){
								$str_var = str_replace("varchar(","",$sugar_c['sugar_field_size']);
								$str_var = str_replace(")","",$str_var);
								$ParseMyResumeType_len[] = $str_var;
							}else{
								$ParseMyResumeType_len[] = '';
							}
								
							if(!empty($varchar_c))
							{
								$size_c=explode("(",$varchar_c);
								$ParseMyResumeDataSize_c[$sugar_c['ParseMyResume_field']]=$size_c[1];
							}
							else if(!empty($char_c))
							{
								$size_c=explode("(",$char_c);
								$ParseMyResumeDataSize_c[$sugar_c['ParseMyResume_field']]=$size_c[1];	
							}
							else if(!empty($dateType_c))
							{
								$ParseMyResumeDate_c[$sugar_c['ParseMyResume_field']]="date";	
							}		
											
							$queryUpdate_c.="`".$sugar_c['sugar_field']."`,";
						}
					}
		
				} 
				$queryUpdate_c=rtrim($queryUpdate_c,",").")VALUES ('{$id}',";
				$num_c=count($ParseMyResumeData_c);
				for($i_c=0;$i_c<$num_c;$i_c++)
				{
					foreach($ParseMyResumeDataSize_c as $key_c=>$value_c)
					{  
						if($ParseMyResumeData_c[$i_c]==$key_c && $ParseMyResumeData_c[$i_c]!=='CandidateImageData')
						{  
							$upload_result[$ParseMyResumeData_c[$i_c]]=substr($upload_result[$ParseMyResumeData_c[$i_c]], 0,$value_c); 
							
						}
					}
					foreach($ParseMyResumeDate_c as $field_c=>$fvalue_c)
					{	
						if($ParseMyResumeData_c[$i]==$field_c)
						{
							$originalDate=explode("/",$upload_result[$ParseMyResumeData[$i]]);
							if($originalDate[1]<10)
							{
								$originalDate[1]="0".$originalDate[1];
							}
							if($originalDate[0]<10)
							{
								$originalDate[0]="0".$originalDate[0];
							}
							$upload_result[$ParseMyResumeData[$i]]=$originalDate[2].":".$originalDate[1].":".$originalDate[0];
						}									
					}
					//CandidateImageFormat
				   if($ParseMyResumeData_c[$i_c]=='CandidateImageData')
				   {
				       	$img_type = $upload_result['CandidateImageFormat'];
					  	$im = $upload_result['CandidateImageData'];
					    if(strlen($im)>20)
						{
							$img = str_replace('data:image/jpeg;base64,', '', $im);
							$img = str_replace(' ', '+', $img);
							$data = base64_decode($img);
							$file = "custom/OffshorePhoto/phpThumb/images/Leads_{$id}.".$img_type;
							$success = file_put_contents($file, $data);
							$upload_result[$ParseMyResumeData_c[$i_c]] = "Leads_{$id}.".$img_type;
						}else{
							$upload_result[$ParseMyResumeData_c[$i_c]] = '';
						}
				   }
				   
					if($ParseMyResumeType_len[$i_c]=='tinytext' || $ParseMyResumeType_len[$i_c]=='text' || $ParseMyResumeType_len[$i_c]=='mediumtext' || $ParseMyResumeType_len[$i_c]=='longtext'){
						$output = preg_replace('/[^(\x20-\x7F)]*/','', $upload_result[$ParseMyResumeData_c[$i_c]]);	
						$queryUpdate_c.="'".addslashes(htmlspecialchars(substr($output,0,$text_data_len[$ParseMyResumeType_len[$i_c]])))."',";
					}else if(strlen($ParseMyResumeType_len[$i_c])>0){
						$output = preg_replace('/[^(\x20-\x7F)]*/','', $upload_result[$ParseMyResumeData_c[$i_c]]);
						$queryUpdate_c.="'".addslashes(substr(trim($output),0,$ParseMyResumeType_len[$i_c]))."',";
					}else{
			 			$queryUpdate_c.="'".addslashes($upload_result[$ParseMyResumeData_c[$i_c]])."',";
					}
				} 
				$queryUpdate_c=rtrim($queryUpdate_c,",").");";
				//echo $queryUpdate_c;	exit;
				$thisSugarBean->db->query($queryUpdate_c,true);

				/****************************************Email Store"*******************************/
				 $email=$upload_result['Email'];
				 $capEmail=strtoupper($email);
				 $emailQuery="INSERT INTO `email_addresses` (`id`, `email_address`, `email_address_caps`, `invalid_email`, `opt_out`, `date_created`, `date_modified`, `deleted`) VALUES ('{$id}', '{$email}', '{$capEmail}','0','0','{$date}','{$date}', '0');";
				 $thisSugarBean->db->query($emailQuery,true); 
				 $emailbeanQuery="INSERT INTO `email_addr_bean_rel` (`id`, `email_address_id`, `bean_id`, `bean_module`, `primary_address`, `reply_to_address`, `date_created`, `date_modified`, `deleted`) VALUES ('{$id}','{$id}', '{$id}', 'Leads', '0', '0','{$date}','{$date}', '0');";

				$thisSugarBean->db->query($emailbeanQuery,true); 
				/** code  to add attachment with note **/				 
				$note = new Note();
				$note->modified_user_id = $current_user->id;
				$note->created_by = $current_user->id;
				$note->assigned_user_id = $current_user->id;
				$note->name = $upload_result["filename"];
				$note->parent_type = "Leads";
				$note->parent_id = $id;
				$note->filename = $upload_result["filename"]; //your file name goes here
			
				$note->file_mime_type = $upload_result["filetype"];  // your file's mime type goes here
				
				$note->save();
				
				$dest = $GLOBALS['sugar_config']['upload_dir'].$note->id; 
				if (!is_file($dest)) {
					@rename($upload_result["filepath"],$dest);
				} 
				
				/** end code to save attachment **/	
				return $id;	
			}
			else
			{
			$data['linkID']=$Result[0];
			$data['id']=1000;
			 return $data;
			}
		}
	}
 }

?>