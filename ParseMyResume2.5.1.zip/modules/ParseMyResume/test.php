<?php
/*********************************************************************************
 * ParseMyResume is helping SugarCRM customers to insert Resumes into ATS. 
 * ParseMyResume Copyright (C) 2011  - 2013 ParseMyResume.
 * 
 * This program is free/Subscription based  software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY ParseMyResume, ParseMyResume DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact ParseMyResume. headquarters at Suite 13, C-134, Phase 8
 * Industrial Area, Mohali, Punjab, 160062 India. or at email address support@parsemyresume.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 ********************************************************************************/

//function to make cURL request
function call($method, $data, $url)
{
    ob_start();
    $ch = curl_init();

				$headers = (function_exists('getallheaders'))?getallheaders(): array();

				$_headers = array();

				foreach($headers as $k=>$v){

				$_headers[strtolower($k)] = $v;

				}

				// set URL and other appropriate options

				curl_setopt($ch, CURLOPT_URL, $url);

				curl_setopt ($ch, CURLOPT_POST, 1);

				curl_setopt($ch, CURLOPT_HTTPHEADER, $_headers);

				curl_setopt($ch, CURLOPT_HEADER, 1);

				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

				curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);

				curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0 );

				$post_data = 'method=' . $method . '&input_type=json&response_type=json';

				$json = getJSONobj();

				$jsonEncodedData = $json->encode($data, false);

				$post_data = $post_data . "&rest_data=" . $jsonEncodedData;

				curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);

				$result = curl_exec($ch);

				curl_close($ch);

				$result = explode("\r\n\r\n", $result, 2);

				print_r($result[1]);

				$response_data = $json->decode($result[1]);

				echo "<pre>";
				return($response_data);
		//print_r($response_data);
}

function call2($method, $parameters, $url)
{
    ob_start();
    $curl_request = curl_init();

    curl_setopt($curl_request, CURLOPT_URL, $url);
    curl_setopt($curl_request, CURLOPT_POST, 1);
    curl_setopt($curl_request, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
    curl_setopt($curl_request, CURLOPT_HEADER, 1);
    curl_setopt($curl_request, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($curl_request, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl_request, CURLOPT_FOLLOWLOCATION, 0);

    $jsonEncodedData = json_encode($parameters);

    $post = array(
         "method" => $method,
         "input_type" => "JSON",
         "response_type" => "JSON",
         "rest_data" => $jsonEncodedData
    );

    curl_setopt($curl_request, CURLOPT_POSTFIELDS, $post);
    $result = curl_exec($curl_request);
    curl_close($curl_request);

    $result = explode("\r\n\r\n", $result, 2);
    $response = json_decode($result[1]);
    ob_end_flush();

    return $response;
}
?>
