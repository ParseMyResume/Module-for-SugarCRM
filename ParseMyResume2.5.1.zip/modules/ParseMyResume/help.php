<?php
/*********************************************************************************
 * ParseMyResume is helping SugarCRM customers to insert Resumes into ATS. 
 * ParseMyResume Copyright (C) 2011  - 2013 ParseMyResume.
 * 
 * This program is free/Subscription based  software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY ParseMyResume, ParseMyResume DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact ParseMyResume. headquarters at Suite 13, C-134, Phase 8
 * Industrial Area, Mohali, Punjab, 160062 India. or at email address support@parsemyresume.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 ********************************************************************************/
 if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
 require_once('data/SugarBean.php');
 $thisSugarBean = new SugarBean();
 try
 {
	$query1="select * from ParseMyResume_info";
	$run_query2=$thisSugarBean->db->query($query1,true);
	$res=$run_query2->fetch_assoc();
	$userkey=$res['userkey'];
	$email=$res['res_email'];
	$username=$res['username'];
 }
 catch(Exception $e)
{
	$GLOBALS['log']->fatal("Caught exception in RepairFieldCasing script: ".$e->getMessage());
   
}
?>
 
<title>Help us improve Provide Support for you</title>

		<style>
			body {
				font-family: Verdana, sans-serif;
				background-image: url(body-bg.gif);
				background-position: top;
				background-repeat: repeat-x;
				margin: 0px 0px 0px 0px;
			}

			td {
				font-size: 12px;
				font-family: Verdana, Sans-Serif;
			}

			.header-table-td-right {
				background-image: url(header-bg-right.gif);
				background-position: left;
				background-repeat: no-repeat;
				width: 155px;
			}

			.note {
				font-size: 10px;
				font-family: Verdana, Sans-Serif;
			}

			.additional-info-textarea {
				font-size: 12px;
				font-family: Verdana, Sans-Serif;
				background-color: #eff1fb;
				border: #00435d 1px solid;
				margin-top: 3px;
				width: 800px;
				height: 96px;
			}

			.log-textarea {
				font-size: 9px;
				font-family: Verdana, Sans-Serif;
				background-color: #eff1fb;
				border: #00435d 1px solid;
				margin-top: 3px;
				width: 800px;
				height: 320px;
			}
		</style>
	</head>
	<body>
		<table border="0" width="100%" cellpadding="0" cellspacing="0">
			<tbody><tr>
				<td width="625"></td>
				<td>&nbsp;</td>
				<td class="header-table-td-right">&nbsp;</td>
			</tr>
		</tbody></table>
		<center>
		<img src="modules/ParseMyResume/images/ParseMyResume.png">
			<form action="http://parsemyresume.com/parsemyresumehelp.php" target="_blank" method="post" name="helpForm" id="helpform" enctype="multipart/form-data" >
				<table border="0" cellspacing="6" cellpadding="0" style="width:60%;">
					<tbody><tr>
						<td colspan="2" style="padding: 10px 0px 10px 0px; font-size:16px;">Here you can:</td>
					</tr>
					<tr>
						<td><img src="modules/ParseMyResume/images/li.png"></td>
						<td>Tell us about the problem you encountered with the Provide Support products</td>
					</tr>
					<tr>
						<td><img src="modules/ParseMyResume/images/li.png"></td>
						<td>Suggest new features or services</td>
					</tr>
					<tr>
						<td><img src="modules/ParseMyResume/images/li.png"></td>
						<td>Suggest improvements to existing features or services</td>
					</tr>
					<tr>
						<td><img src="modules/ParseMyResume/images/li.png"></td>
						<td>Submit any kind of feedback about Provide Support team, services etc.</td>
					</tr>
				</tbody></table>
				<table border="0" cellspacing="6" cellpadding="0" style="width:60%;">
				<tr>
				<td><h3>User Name</td><td><input type="text" name="uname" id="uname" value="<?php if(!empty($username))echo $username;?>" size=40></td>	
				<td><h3>Email </td><td><input type="text" name="uemail" id="uemail" value="<?php if(!empty($email))echo $email;?>" size=40></td></tr>
                <tr><td><h3>User Key:</h3></td><td><input type="text" name="userkey" id="userkey" value="<?php if(!empty($userkey))echo $userkey;?>" size=40></td></tr>
				</table>
				<table cellpadding="0" cellspacing="0">
					<tbody><tr>
						<td>We will treat all information you send to Provide Support as confidential</td>
					</tr>
					<tr>
						<td>
							<br>
							<b>Please enter your comments, suggestions or additional information:</b><br>
							<div class="note">* if possible, provide us with instructions on how we can reproduce the problem in order to fix it</div>
							<textarea class="additional-info-textarea" name="msg" wrap="off"></textarea>
						</td>
					</tr>
					<tr>
						<td>
							<br>
							<b>Additional information phpinfo() that will be sent to Provide Support:</b><br>
							<div class="note">* leave this field blank if you don't want to send this information to us</div>
							<textarea class="log-textarea" name="phpinfo" wrap="off"><?php phpinfo();?></textarea>
						</td>
					</tr>
					<tr>
						<td align="right"><br>
							<input type="submit" value="Submit Information to Provide Support" style="padding:6px 15px; border-radius:5px;">
						</td>
					</tr>
				</tbody></table>
			</form>
		</center>
	


</body>