<script src="http://ds.ParseMyResume.com/js/jquery.js"></script>
<script language="javascript">
function getContentFromIframe(obj)
{
//alert(obj.src);
    $.ajax({
	 type:"POST",
	 url:"index.php?module=ParseMyResume&action=userkey",
	 data:{src:obj.src},
	 success:function(data)
	 {
		//alert(data);
	 }
	});
    //Do whatever you need with the content    

}
</script>

<body onLoad="getContentFromIframe(document.getElementById('myframe'))">
<div id ="ksrc"></div>
<?php 
$key = '12#$fd$8f';
		require_once('data/SugarBean.php');
		$thisSugarBean = new SugarBean();
		$query1="select * from ParseMyResume_info";
		$run_query1=$thisSugarBean->db->query($query1,true);
		$res=$run_query1->fetch_assoc();
		if(!empty($res['macid']))
		{
			$searchArray = array(":", "-");
			$replaceArray = array("", "");
			$macid = str_replace($searchArray ,$replaceArray,$res['macid']);
			$section=file_get_contents("http://ds.ParseMyResume.com/testParseMyResumeEnCrypt_131348phase.aspx?q=".$macid) ;
			$data=urldecode($section);
			$pos = strrpos($data, "Hiddenfield1");
			//echo $pos;
			if(!empty($pos))
				{
					$id = substr($data,$pos+13);
					$macid=explode("\"",$id);
					//echo $macid[1]; 
				}
		}
	echo "<center><Iframe id=\"myframe\" src=\"http://ds.ParseMyResume.com/Registration.aspx?q=".urlencode($macid[1])."\" width=\"1024\" height=\"720\" onLoad=\"getContentFromIframe(document.getElementById('myframe'))\"></Iframe></center>";
	?>
	</body>
	