<?php
/*********************************************************************************
 * ParseMyResume is helping SugarCRM customers to insert Resumes into ATS. 
 * ParseMyResume Copyright (C) 2011  - 2013 ParseMyResume.
 * 
 * This program is free/Subscription based  software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY ParseMyResume, ParseMyResume DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact ParseMyResume. headquarters at Suite 13, C-134, Phase 8
 * Industrial Area, Mohali, Punjab, 160062 India. or at email address support@parsemyresume.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 ********************************************************************************/
$dictionary['ParseMyResume'] = array(
	'table'=>'ParseMyResume',
	'audited'=>true,
	'fields'=>array(
	 'user_name' => array(
            'name' => 'user_name',
            'vname' => 'LBL_USER_NAME',
            'dbType' => 'varchar',
            'type' => 'name',
            'len' => '30',
        ) ,
        'password' => array(
            'name' => 'password',
            'vname' => 'LBL_PASSWORD',
            'dbType' => 'varchar',
            'type' => 'name',
            'len' => '30',
            'importable' => 'required',
        	'required' => true,
        ) ,
		'host' => array(
            'name' => 'host',
            'vname' => 'LBL_HOST',
            'dbType' => 'varchar',
            'type' => 'name',
            'len' => '30',
            'importable' => 'required',
        	'required' => true,
        ) ,
		'port' => array(
            'name' => 'port',
            'vname' => 'LBL_PORT',
            'dbType' => 'varchar',
            'type' => 'name',
            'len' => '30',
            'importable' => 'required',
        	'required' => true,
        ) ,
		'mac' => array(
            'name' => 'mac',
            'vname' => 'LBL_MAC',
            'dbType' => 'varchar',
            'type' => 'name',
            'len' => '30',
            'importable' => 'required',
        	'required' => true,
        ) ,
		'userkey' => array(
            'name' => 'userkey',
            'vname' => 'LBL_USERKEY',
            'dbType' => 'varchar',
            'type' => 'name',
            'len' => '30',
            'importable' => 'required',
        	'required' => true,
        ) ,
		'is_register' => array(
            'name' => 'is_register',
            'vname' => 'LBL_IS_REGISTER',
            'type' => 'bool',
            'default' => '0',
        ) ,
),
	'relationships'=>array (
),
	'optimistic_lock'=>true,
);
require_once('include/SugarObjects/VardefManager.php');
VardefManager::createVardef('ParseMyResume','ParseMyResume', array('basic','assignable'));