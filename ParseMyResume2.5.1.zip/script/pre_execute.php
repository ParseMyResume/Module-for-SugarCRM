<?php
/*------------------Script to get Linux system Mac ID --------------------*/

require_once('data/SugarBean.php'); 
$thisSugarBean = new SugarBean();
$msg="";
$extentions=array('soap','imap','curl','mysql','mysqli');
foreach ($extentions as $i => $ext)
{  
	if (!extension_loaded($ext)) 
	{
		$msg.="<b>".$ext .' : Extention of PHP Required</b><br/>';
	}
}
if(!empty($msg))
{
	echo "<script> alert('PHP Extentions are missing. Kindly Check Display Log');</script>";
	die($msg);
}
else
{	
	ob_start();
	$dm=shell_exec('/sbin/ifconfig eth0');	
	preg_match("/[0-9a-f][0-9a-f][:-][0-9a-f][0-9a-f][:-][0-9a-f][0-9a-f][:-][0-9a-f][0-9a-f][:-]"."[0-9a-f][0-9a-f][:-][0-9a-f][0-9a-f]/i",$dm,$mac); 
	if(isset($mac[0]) && $mac[0]=='')
	{
		$mac_address = $mac[0];  
	}
	elseif($_SERVER["SERVER_NAME"]!='')
	{
	      $mac_address = $_SERVER["SERVER_NAME"]; 
	}
	else
	{
	$email_query="select email_address from email_addresses e , email_addr_bean_rel er where e.id=er.email_address_id and bean_id='1' AND er.deleted='0'";
		 $ex_query1=$thisSugarBean->db->query($email_query,true);
         $row=$ex_query1->fetch_assoc();
         $mac_address =  $row['email_address'];	
	}

/* If Not Linux will check for another system platform (windows) */

		if(empty($mac_address))
			{
				ob_start(); // Turn on output buffering
				system("ipconfig /all"); //Execute external program to display output
				$mycom=ob_get_contents(); // Capture the output into a variable
				ob_clean(); // Clean (erase) the output buffer
				$pmac = strpos($mycom,"Physical"); // Find the position of Physical text
				$mac_address=substr($mycom,($pmac+36),17); // Get Physical Address*/
			}
			
/* ----------Create Table IN Database--------------*/

	$query1 = "CREATE TABLE `ParseMyResume_info` (
	`id` varchar(36) NOT NULL default '',
	`email` varchar(36) ,
	`password` varchar(36) ,
	`host` varchar(45) default NULL,
	`port` varchar(36) default NULL,
	`ssl`  varchar(36) default NULL,
	`map`  varchar(36) default NULL,
	`countrykey`  varchar(40) default NULL,
	`userkey` varchar(36) default NULL,
	`macid` varchar(100) default NULL,
	`username` varchar(100) default NULL,
	`credits` varchar(100) default NULL,
	`date_of_expire` varchar(100) default NULL,
	`planType` varchar(100) default NULL,
	`res_email` varchar(100) default NULL,
	`map_field` varchar(2) default '0',
	PRIMARY KEY  (`id`)
	)";


			
$query2="INSERT INTO `ParseMyResume_info` (`id`,`macid`) VALUES ('01','{$mac_address}')";


$query3="CREATE TABLE  `ParseMyResume_field_mapping` (
`id` INT( 10 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`ParseMyResume_field` VARCHAR( 289 ) NULL ,
`sugar_field` VARCHAR( 289 ) NULL ,
`sugar_field_size` VARCHAR( 289 ) NULL
) ";
$ParseMyResumeData=array("FirstName","Middlename","LastName","DateOfBirth","Gender","PassportNo","LicenseNo","Nationality","MaritalStatus","FatherName","MotherName","LanguageKnown","Hobbies","Address","City","State","ZipCode","Email","Phone","Mobile","FaxNo","Qualification","University1","Degree1","Year1","University2","Degree2","Year2","University3","Degree3","Year3","Category","SubCategory","Skills","Experience","CurrentEmployer","JobProfile","CurrentSalary","ExpectedSalary","Employer1","JobProfile1","JobPeriod1","JobLocation1","StartDate1","EndDate1","JobDescription1","Employer2","JobProfile2","JobPeriod2","JobLocation2","StartDate2","EndDate2","JobDescription2","Employer3","JobProfile3","JobPeriod3","JobLocation3","StartDate3","EndDate3","JobDescription3","Experience_Year","Experience_Months","GapPeriod","EmailFrom","EmailTo","EmailCC","EmailSubject","EmailReplyTo","EmailBody","Objectives","Achievements","References","AttachFile","FileName","DetailResume","htmlresume");
$num=count($ParseMyResumeData);
$run_query1=$thisSugarBean->db->query($query1,true);// To Create Rchill_info Table in Database
$run_query2=$thisSugarBean->db->query($query2,true);// To Insert Mac Id in Rchill_info Table
$run_query3=$thisSugarBean->db->query($query3,true);// To Create ParseMyResume field Mapping Table
	$num=count($ParseMyResumeData);
	for($i=0;$i<$num;$i++)
	{
		if($ParseMyResumeData[$i]=='FirstName')
		{
			$query4="INSERT INTO `ParseMyResume_field_mapping` (`id`,`ParseMyResume_field`,`sugar_field`,`sugar_field_size`) VALUES ('NULL','{$ParseMyResumeData[$i]}','first_name','varchar(100)')";
			$run_query4=$thisSugarBean->db->query($query4,true);

		}
		else if($ParseMyResumeData[$i]=='LastName')
		{
			$query4="INSERT INTO `ParseMyResume_field_mapping` (`id`,`ParseMyResume_field`,`sugar_field`,`sugar_field_size`) VALUES ('NULL','{$ParseMyResumeData[$i]}','last_name','varchar(100)')";
			$run_query4=$thisSugarBean->db->query($query4,true);
		}
		else if($ParseMyResumeData[$i]=='DetailResume')
		{
			$query4="INSERT INTO `ParseMyResume_field_mapping` (`id`,`ParseMyResume_field`,`sugar_field`,`sugar_field_size`) VALUES ('NULL','{$ParseMyResumeData[$i]}','description','text')";
			$run_query4=$thisSugarBean->db->query($query4,true);
		}
		else if($ParseMyResumeData[$i]=='Address')
		{
			$query4="INSERT INTO `ParseMyResume_field_mapping` (`id`,`ParseMyResume_field`,`sugar_field`,`sugar_field_size`) VALUES ('NULL','{$ParseMyResumeData[$i]}','primary_address_street','varchar(150)')";
			$run_query4=$thisSugarBean->db->query($query4,true);
		}
		else if($ParseMyResumeData[$i]=='City')
		{
			$query4="INSERT INTO `ParseMyResume_field_mapping` (`id`,`ParseMyResume_field`,`sugar_field`,`sugar_field_size`) VALUES ('NULL','{$ParseMyResumeData[$i]}','primary_address_city','varchar(100)')";
			$run_query4=$thisSugarBean->db->query($query4,true);
		}
		else if($ParseMyResumeData[$i]=='State')
		{
			$query4="INSERT INTO `ParseMyResume_field_mapping` (`id`,`ParseMyResume_field`,`sugar_field`,`sugar_field_size`) VALUES ('NULL','{$ParseMyResumeData[$i]}','primary_address_state','varchar(100)')";
			$run_query4=$thisSugarBean->db->query($query4,true);
		}
		else
		{
			$query4="INSERT INTO `ParseMyResume_field_mapping` (`id`,`ParseMyResume_field`) VALUES ('NULL','{$ParseMyResumeData[$i]}')";
			$run_query4=$thisSugarBean->db->query($query4,true);
		}
	}
  $new="CREATE TABLE IF NOT EXISTS leads_cstm
					( id_c char(36) NOT NULL )";
					$thisSugarBean->db->query($new,true); 	
	include("modules/ACL/install_actions.php");
	sugar_cache_reset();
} 

?>