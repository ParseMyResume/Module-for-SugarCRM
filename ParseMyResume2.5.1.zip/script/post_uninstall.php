<?php

	require_once('data/SugarBean.php');
		
	$focus = new SugarBean();

	//ParseMyResume_info 
	$query = "SHOW TABLES LIKE 'ParseMyResume_info'";
	$results = $focus->db->query($query, true);
	while($row = $focus->db->fetchByAssoc($results))
		{
		$query = "drop table ParseMyResume_info";
		$focus->db->query($query, true);
		}

	//ParseMyResume_field_mapping_table
	$query = "SHOW TABLES LIKE 'ParseMyResume_field_mapping'";
	$results = $focus->db->query($query, true);
	while($row = $focus->db->fetchByAssoc($results))
		{
		$query = "drop table ParseMyResume_field_mapping";
		$focus->db->query($query, true);
		}
			

?>