<?php 
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$offshore_plugins_installed = 0;
foreach($admin_group_header as $k => $v){
    if(!empty($v) && is_array($v)){
        if($v[0] == 'LBL_OFFSHOREEVOLUTION'){
            $offshore_plugins_installed = $k;
        }
    }
}
if( empty($offshore_plugins_installed) ){
    $admin_option_defs = array ();
    $admin_option_defs[] = array (
       'offshore',
      'LBL_OFFSHOREFIELDPHOTO_TITLE',
      'LBL_OFFSHOREFIELDPHOTO_INFOS',
      './index.php?module=Administration&action=offshorephoto_manage'
    );    
    $admin_group_header[] = array (
        'LBL_OFFSHOREEVOLUTION',
        '',
        false,
        array("Administration" => $admin_option_defs),
        'LBL_OFFSHOREEVOLUTION_ADMIN_DESC'
    );
}
else{
    $admin_group_header[$offshore_plugins_installed][3]['Administration'][] = array (
        'offshore',
        'LBL_OFFSHOREFIELDPHOTO_TITLE',
        'LBL_OFFSHOREFIELDPHOTO_INFOS',
        './index.php?module=Administration&action=offshorephoto_manage'
    );
}
