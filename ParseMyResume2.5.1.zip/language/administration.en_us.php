<?php
$mod_strings['LBL_OFFSHOREEVOLUTION'] = 'OFFSHOREEVOLUTION';
$mod_strings['LBL_OFFSHOREEVOLUTION_ADMIN_DESC'] = 'OFFSHOREEVOLUTION Plugins configuration';
$mod_strings['LBL_OFFSHOREFIELDPHOTO_TITLE'] = 'OffshorePhoto';
$mod_strings['LBL_OFFSHOREFIELDPHOTO_INFOS'] = 'Photo integration by OFFSHOREEVOLUTION';
$mod_strings['LBL_MAX_SIZE_PICTURE'] = 'Max upload size';
?>