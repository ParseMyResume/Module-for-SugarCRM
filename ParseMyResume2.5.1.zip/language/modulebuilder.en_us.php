<?php
$mod_strings['fieldTypes']['photo'] = 'Photo';
?>