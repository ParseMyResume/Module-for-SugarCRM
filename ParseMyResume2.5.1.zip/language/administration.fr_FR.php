<?php
$mod_strings['LBL_OFFSHOREEVOLUTION'] = 'OFFSHOREEVOLUTION';
$mod_strings['LBL_OFFSHOREEVOLUTION_ADMIN_DESC'] = 'Configuration des Plugins OFFSHOREEVOLUTION';
$mod_strings['LBL_OFFSHOREFIELDPHOTO_TITLE'] = 'OffshorePhoto';
$mod_strings['LBL_OFFSHOREFIELDPHOTO_INFOS'] = 'Intégration des Photos par OFFSHOREEVOLUTION';

$mod_strings['LBL_MAX_SIZE_PICTURE'] = 'Taille maximale autorisée à l&#39;upload';
?>