<?php
$app_strings['ONLY_EXISTING_RECORD'] = 'Sólo puede asociar Imágenes a registros existentes.';
$app_strings['NO_PICTURE_AVAILABLE'] = 'No dispone de Imagen';
$app_strings['LBL_SEARCH_WITHOUT_PICTURE'] = 'Sin Imagen';
$app_strings['LBL_SEARCH_WITH_PICTURE'] = 'Con Imagen';
?>
