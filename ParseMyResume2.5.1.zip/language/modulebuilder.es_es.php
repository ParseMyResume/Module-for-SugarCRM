<?php
$mod_strings['fieldTypes']['photo'] = 'Imagen';
?>
