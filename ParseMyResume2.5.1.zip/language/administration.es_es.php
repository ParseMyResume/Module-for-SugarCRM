<?php
$mod_strings['LBL_OFFSHOREEVOLUTION'] = 'OFFSHOREEVOLUTION';
$mod_strings['LBL_OFFSHOREEVOLUTION_ADMIN_DESC'] = 'OFFSHOREEVOLUTION Plugins configuracion';
$mod_strings['LBL_OFFSHOREFIELDPHOTO_TITLE'] = 'OffshorePhoto';
$mod_strings['LBL_OFFSHOREFIELDPHOTO_INFOS'] = 'Fotos por OFFSHOREEVOLUTION';
$mod_strings['LBL_MAX_SIZE_PICTURE'] = 'Tamaño máximo permitido para el upload';
?>