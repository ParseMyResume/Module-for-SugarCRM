<?php
$mod_strings['HEIGHT'] = 'Alt. Máx.';
$mod_strings['WIDTH'] = 'Ancho Máx.';
$mod_strings['STYLE'] = 'Estilo CSS';
$mod_strings['PHOTO_IS_BY_DEFAULT'] = 'Si desea contar con una imagen Por Omisión, cárguela en custom/OffshorePhoto/phpThumb/images/defaults/. El nombre del archivo de la imagen deberá ser NombreDelModuloNombreDelCampo_c.jpg';
$mod_strings['PHOTO_IS_NOT_REPORTABLE'] = 'Los campos de imágenes no están disponibles en Informes';
$mod_strings['PHOTO_IS_NOT_IMPORTABLE'] = 'Los campos de imágenes no son importables';
$mod_strings['PHOTO_IS_NOT_MERGEABLE'] = 'Los campos de imágenes no pueden ser combinados';
?>
