<?php
require_once('include/SugarFields/Fields/Base/SugarFieldBase.php');

class SugarFieldPhoto extends SugarFieldBase {
   
    var $style;
    
	function getDetailViewSmarty($parentFieldArray, $vardef, $displayParams, $tabindex) {
	    global $app_strings;
	    
	    //Max Width
		if(empty($displayParams['max_width'])) {
		    $displayParams['max_width'] = $vardef['max_width'];
		}
		
		//Max Height 
		if(empty($displayParams['max_height'])) {
		    $displayParams['max_height'] = $vardef['max_height'];
		}
		
		//Style
		if(empty($displayParams['style'])) {
		    $displayParams['style'] = $vardef['style'];
		}
		
		$displayParams['t'] = time();
		
    	if(empty($displayParams['default_picture'])) {
		    if ( file_exists('custom/OffshorePhoto/phpThumb/images/defaults/' . $vardef['id'].'.jpg') ){
		        $displayParams['default_picture'] = 'defaults/' . $vardef['id'].'.jpg';
		    }
		}
		$this->setup($parentFieldArray, $vardef, $displayParams, $tabindex);
		
        return $this->fetch('include/SugarFields/Fields/Photo/DetailView.tpl');
    }
    
    function getEditViewSmarty($parentFieldArray, $vardef, $displayParams, $tabindex) {
    	
    	$this->setup($parentFieldArray, $vardef, $displayParams, $tabindex);        
        return $this->fetch('include/SugarFields/Fields/Photo/EditView.tpl');
    }
    
	function getSearchViewSmarty($parentFieldArray, $vardef, $displayParams, $tabindex) {
		$this->setup($parentFieldArray, $vardef, $displayParams, $tabindex);
		return $this->fetch('include/SugarFields/Fields/Photo/SearchView.tpl');
	}
}
?>
