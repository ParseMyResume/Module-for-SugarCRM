<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

global $current_user;
if( empty($_GET['id']) ){
    echo 'id required';
}
elseif( empty($_GET['module']) ){
    echo 'module required';
}
elseif( empty($_GET['field']) ){
    echo 'field required';
}
else{
    $module_name = $_GET['module'];
    $field_name = $_GET['field'];
    
    global $beanList, $beanFiles, $sugar_config;
    $class_name = $beanList[$module_name];
	require_once($beanFiles[$class_name]);
	$seed = new $class_name();
        
    $seed->retrieve($_GET['id']);
    
    $max_size_picture = $sugar_config['max_size_picture'];
    if(empty($max_size_picture)){
        $max_size_picture = 1000000;
    }
    
    if($seed->ACLAccess('edit')){
             
        $new_name = $module_name.'_'.$field_name.'_'.$seed->id.'.jpg';
        $target_path = 'custom/OffshorePhoto/phpThumb/images/new_'.$new_name;
        if (    
            (
                    ($_FILES["file"]["type"] == "image/gif") 
                ||  ($_FILES["file"]["type"] == "image/jpeg") 
                ||  ($_FILES["file"]["type"] == "image/jpg") 
                ||  ($_FILES["file"]["type"] == "image/pjpeg") 
            )
            &&  
            (
                $_FILES["file"]["size"] < $max_size_picture
            )
        ){
            if ($_FILES["file"]["error"] > 0){
                echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
            }
            else{
                
        	    if (file_exists("phpThumb/images/" . $new_name)){
                    echo '<img src="custom/OffshorePhoto/phpThumb/phpThumb.php?src=images/' . $new_name . '&h=80&w=80&t='.time().'">';
                }
                else if(move_uploaded_file($_FILES['file']['tmp_name'], $target_path)){
        		    chmod($target_path, 0644);
        		    echo '<img src="custom/OffshorePhoto/phpThumb/phpThumb.php?src=images/new_' . $new_name . '&h=80&w=80&t='.time().'">';
        	    }
            }
        }
        elseif($_FILES["file"]["size"] >= $max_size_picture){
            echo "Error: File too big " . formatSize($_FILES["file"]["size"]) . ": ". formatSize($max_size_picture) ." Max <br />";
        }
        else{
            echo "Error: " . $_FILES["file"]["type"] . " not allowded <br />";
        }
        
    }
    else{
        echo 'Not allowed to Edit this '.$class_name;
    }
}

function formatSize($size){
    switch (true){
    case ($size > 1099511627776):
        $size /= 1099511627776;
        $suffix = 'To';
    break;
    case ($size > 1073741824):
        $size /= 1073741824;
        $suffix = 'Go';
    break;
    case ($size > 1048576):
        $size /= 1048576;
        $suffix = 'Mo';   
    break;
    case ($size > 1024):
        $size /= 1024;
        $suffix = 'Ko';
        break;
    default:
        $suffix = 'o';
    }
    return round($size, 0).$suffix;
}

?>

