<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('include/generic/SugarWidgets/SugarWidgetField.php');

class SugarWidgetSubPanelDetailViewOffshorePhoto extends SugarWidgetField
{
	function displayList(&$layout_def)
	{
		global $focus;
        
		$module = '';
		$record = '';

		if(isset($layout_def['varname']))
		{
			$key = strtoupper($layout_def['varname']);
		}
		else
		{
			$key = $this->_get_column_alias($layout_def);
			$key = strtoupper($key);
		}
		if (empty($layout_def['fields'][$key])) {
			return "";
		} else {
			$value = $layout_def['fields'][$key];
		}
		
		if(!empty($value)){
		    return '<img src="custom/OffshorePhoto/phpThumb/phpThumb.php?src=images/'.$value.'&h=60" />';
		}
		else{
			return '';
		}
		
	}
}

?>
