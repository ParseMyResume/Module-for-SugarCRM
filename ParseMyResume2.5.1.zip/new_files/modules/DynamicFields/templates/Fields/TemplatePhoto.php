<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('modules/DynamicFields/templates/Fields/TemplateText.php');

class Templatephoto extends TemplateText{
    
    var $type='photo';
    
    function get_field_def(){
		$def = parent::get_field_def();
		
		$def['dbType'] = 'varchar';
		$def['massupdate'] = 0;
		$def['importable'] = 0;
		$def['duplicate_merge'] = 0;
		$def['reportable'] = 0;
		$def['len'] = 255;
        $def['studio'] = 'visible';
        
        //Max Width
        $def['max_width'] = !empty($this->max_width) ? $this->max_width : $this->ext2;
        
        //Max Height
        $def['max_height'] = !empty($this->max_height) ? $this->max_height : $this->ext3;
        
        //Style CSS
        $def['style'] = !empty($this->style) ? $this->style : $this->ext4;
		return $def;	
	}
}


?>
