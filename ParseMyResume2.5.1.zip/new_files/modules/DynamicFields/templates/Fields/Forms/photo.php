<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

function get_body(&$ss, $vardef){
	$vars = $ss->get_template_vars();
	$fields = $vars['module']->mbvardefs->vardefs['fields'];
	$fieldOptions = array();
	foreach($fields as $id=>$def) {
		$fieldOptions[$id] = $def['name'];
	}
	$ss->assign('fieldOpts', $fieldOptions);
	
    //Default Values in Studio
    if(empty($vardef['max_width'])) { //Max Width
        $vardef['max_width'] = 85;
    }
    $ss->assign('DEFAULT_MAX_WIDTH', $vardef['max_width']);
    
    if(empty($vardef['max_height'])) { //Max Height
        $vardef['max_height'] = 85;
    }
    $ss->assign('DEFAULT_MAX_HEIGHT', $vardef['max_height']);
    
    if(empty($vardef['style'])) { //Style CSS
        $vardef['style'] = '';
    }
    $ss->assign('DEFAULT_STYLE', $vardef['style']);
    
    $ss->assign('hideReportable', true);
	return $ss->fetch('modules/DynamicFields/templates/Fields/Forms/photo.tpl');
 }
