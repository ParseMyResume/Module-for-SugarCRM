<?php
// KEY should be LBL_<JOB_NAME>
$mod_strings['LBL_PARSEMYRESUME_ZIP_PROCESS'] = 'ParseMyResume_Zip_Process';
$mod_strings['LBL_PARSEMYRESUME_MAILBOX_PARSING'] = 'ParseMyResume_Mailbox_Parsing';
?>
