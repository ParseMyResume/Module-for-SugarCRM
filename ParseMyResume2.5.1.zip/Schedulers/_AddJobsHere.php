<?php
$job_strings[102] = 'ParseMyResume_Zip_Process';
$job_strings[103] = 'ParseMyResume_Mailbox_Parsing';
		
function ParseMyResume_Zip_Process() 
{		
					include("modules/ParseMyResume/class.zipProcess.php");
					$zipData=new ZipProcess();
					$result=$zipData->extract();
					return true;
}
function ParseMyResume_Mailbox_Parsing()
{
					include("modules/ParseMyResume/readEmail.php");
					$getData=new readEmail();
					$getRsesult=$getData->getAttachment();
					return true;
}
?>
